import { _ as _export_sfc, H as resolveComponent, c as createElementBlock, k as createBaseVNode, L as createVNode, w as withCtx, a as createTextVNode, V as createStaticVNode, o as openBlock } from "./chunks/framework.2dcfa116.js";
const __pageData = JSON.parse('{"title":"JAVASCRIPT","description":"","frontmatter":{},"headers":[],"relativePath":"js/main.md","filePath":"js/main.md"}');
const _sfc_main = { name: "js/main.md" };
const _hoisted_1 = /* @__PURE__ */ createBaseVNode("h1", {
  id: "javascript",
  tabindex: "-1"
}, [
  /* @__PURE__ */ createTextVNode("JAVASCRIPT "),
  /* @__PURE__ */ createBaseVNode("a", {
    class: "header-anchor",
    href: "#javascript",
    "aria-label": 'Permalink to "JAVASCRIPT"'
  }, "​")
], -1);
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("h2", {
  id: "起源",
  tabindex: "-1"
}, [
  /* @__PURE__ */ createTextVNode("起源 "),
  /* @__PURE__ */ createBaseVNode("a", {
    class: "header-anchor",
    href: "#起源",
    "aria-label": 'Permalink to "起源"'
  }, "​")
], -1);
const _hoisted_3 = /* @__PURE__ */ createBaseVNode("span", { class: "cor-wa" }, "1994 年", -1);
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("em", null, "网景 (Netscape Communication Corperation)", -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("code", null, "网景浏览器 (Netscape Navigator)", -1);
const _hoisted_6 = /* @__PURE__ */ createStaticVNode('<p><span class="cor-wa">1995 年</span> 网景公司决定在浏览器中加入一门语言, 可以作交互效果, 提高用户体验。</p><p>后聘请 <span class="cor-da">Brendan Eich</span>, 10 天后, 新的语言诞生。</p><blockquote><p>Netscape 公司的这种浏览器脚本语言, 最初名字叫做 Mocha, 1995 年 9 月改为 LiveScript。12 月, Netscape 公司与 Sun 公司(Java 语言的发明者和所有者)达成协议, 后者允许将这种语言叫做 JavaScript。</p></blockquote><p><span class="cor-wa">1996 年 8 月</span> 微软模仿 <code>JavaScript</code> 开发了一种相近的语言, 取名为 <code>JScript</code>(JavaScript 是 Netscape 的注册商标, 微软不能用)</p><p>首先内置于 <code>IE 3.0</code>。Netscape 公司面临丧失浏览器脚本语言的主导权的局面。</p><p><span class="cor-wa">1996 年 11 月</span> Netscape 公司决定将 JavaScript 提交给国际标准化组织 <code>ECMA</code> <code>(European Computer Manufacturers Association)</code>, 希望 <code>JavaScript</code> 能够成为国际标准, 以此抵抗微软。</p><p><strong>ECMA 的 39 号技术委员会</strong> <code>Technical Committee 39</code> 负责制定和审核这个标准</p><p><span class="cor-wa">1997 年 7 月</span> ECMA 组织发布 262 号标准文件 <code>ECMA-262</code> 的第一版, 规定了浏览器脚本语言的标准, 并将这种语言称为 <strong>ECMAScript。</strong></p><blockquote><p>ECMA-262 标准后来也被另一个国际标准化组织 <code>ISO</code>(International Organization for Standardization)批准, 标准号是 <strong>ISO-16262</strong></p></blockquote><h2 id="ecmascript" tabindex="-1">ECMAScript <a class="header-anchor" href="#ecmascript" aria-label="Permalink to &quot;ECMAScript&quot;">​</a></h2><p><span class="cor-wa">1997 年 7 月</span> <strong>ECMAScript 1.0</strong> 发布。</p><p><span class="cor-wa">1998 年 6 月</span> <strong>ECMAScript 2.0</strong> 版发布。</p><p><span class="cor-wa">1999 年 12 月</span> <strong>ECMAScript 3.0</strong> 版发布, 成为 <code>JavaScript</code> 的通行标准, 得到了广泛支持。</p><p><span class="cor-wa">2007 年 10 月</span> <strong>ECMAScript 4.0</strong> 版草案发布, 对 3.0 版做了大幅升级, 预计次年 8 月发布正式版本。草案发布后, 由于 4.0 版的目标过于激进, 各方对于是否通过这个标准, 发生了严重分歧。以 Yahoo、Microsoft、Google 为首的大公司, 反对 JavaScript 的大幅升级, 主张小幅改动；以 JavaScript 创造者 Brendan Eich 为首的 Mozilla 公司, 则坚持当前的草案。</p><p><span class="cor-wa">2008 年 7 月</span>, 由于对于下一个版本应该包括哪些功能, 各方分歧太大, 争论过于激进, ECMA 开会决定, <span class="cor-da">中止 ECMAScript 4.0 的开发</span>( <em>即废除了这个版本</em> ), 将其中涉及现有功能改善的一小部分, 发布为 <strong>ECMAScript 3.1</strong>, 而将其他激进的设想扩大范围, 放入以后的版本, 由于会议的气氛, 该版本的项目代号起名为 <em>Harmony(和谐)</em>。会后不久, <strong>ECMAScript 3.1</strong> 就改名为 <strong>ECMAScript 5</strong>。</p><p><span class="cor-wa">2009 年 12 月</span> <strong>ECMAScript 5.0</strong> 版 正式发布。<code>Harmony</code> 项目则一分为二, 一些较为可行的设想定名为 <em>JavaScript.next</em> 继续开发, 后来演变成 ECMAScript 6；一些不是很成熟的设想, 则被视为 <em>JavaScript.next.next</em>, 在更远的将来再考虑推出。<code>TC39</code> 的总体考虑是, <code>ECMAScript 5</code> 与 <code>ECMAScript 3</code> 基本保持兼容, 较大的语法修正和新功能加入, 将由 <em>JavaScript.next</em> 完成。当时, <em>JavaScript.next</em> 指的是 <strong>ECMAScript 6</strong>。第六版发布以后, 将指 <strong>ECMAScript 7</strong>。TC39 预计, <strong>ECMAScript 5</strong> 会在 <em>2013</em> 年的年中成为 <code>JavaScript</code> 开发的主流标准, 并在此后 <span class="cor-tip">五年</span> 中一直保持这个位置。</p><p><span class="cor-wa">2011 年 6 月</span> <strong>ECMAScript 5.1 版发布</strong>, 并且成为 ISO 国际标准(ISO/IEC 16262:2011)。到了 2012 年底, 所有主要浏览器都支持 <strong>ECMAScript 5.1</strong> 版的全部功能。</p><p><span class="cor-wa">2013 年 3 月</span> <strong>ECMAScript 6 草案冻结</strong>, 不添加新功能。新的功能设想将被放到 <strong>ECMAScript 7</strong>。</p><p><span class="cor-wa">2013 年 12 月</span> <strong>ECMAScript 6 草案发布</strong>。然后是 12 个月的讨论期, 听取各方反馈。</p><p><span class="cor-wa">2015 年 6 月</span> <strong>ECMAScript 6 正式发布</strong>, 并且更名为“<strong>ECMAScript 2015</strong>”。</p><blockquote><p>这是因为 <code>TC39</code> 委员会计划, 以后每年发布一个 <code>ECMAScript</code> 的版本, 下一个版本在 <em>2016</em> 年发布, 称为“<strong>ECMAScript 2016</strong>”, <em>2017</em> 年发布“<strong>ECMAScript 2017</strong>”, 以此类推。</p></blockquote><h3 id="现在是-2023-年-ecmascript-已经发布到-es13-ecmascript-2022" tabindex="-1">现在是 <span class="cor-wa">2023</span> 年 <code>ECMAScript</code> 已经发布到 <strong>ES13</strong> <em>ECMAScript 2022</em> <a class="header-anchor" href="#现在是-2023-年-ecmascript-已经发布到-es13-ecmascript-2022" aria-label="Permalink to &quot;现在是 &lt;span class=&quot;cor-wa&quot;&gt;2023&lt;/span&gt; 年 `ECMAScript` 已经发布到 **ES13** _ECMAScript 2022_&quot;">​</a></h3><p><em>JS 语言之父</em> -&gt; <span class="cor-da">Brendan Eich</span> -&gt; <a href="https://github.com/BrendanEich" target="_blank" rel="noreferrer">to github</a></p>', 23);
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_Badge = resolveComponent("Badge");
  return openBlock(), createElementBlock("div", null, [
    _hoisted_1,
    _hoisted_2,
    createBaseVNode("p", null, [
      _hoisted_3,
      createVNode(_component_Badge, { type: "tip" }, {
        default: withCtx(() => [
          createTextVNode("跟我一样大")
        ]),
        _: 1
      }),
      createTextVNode(),
      _hoisted_4,
      createTextVNode(" 推出第一款商用浏览器, "),
      _hoisted_5
    ]),
    _hoisted_6
  ]);
}
const main = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  main as default
};
