import { _ as _export_sfc, c as createElementBlock, o as openBlock, V as createStaticVNode } from "./chunks/framework.2dcfa116.js";
const bhk_md_vue_type_style_index_0_lang = "";
const bhk_md_vue_type_style_index_1_lang = "";
const bhk_md_vue_type_style_index_2_lang = "";
const __pageData = JSON.parse('{"title":"包含块","description":"","frontmatter":{},"headers":[],"relativePath":"css/terminology/bhk.md","filePath":"css/terminology/bhk.md"}');
const _sfc_main = { name: "css/terminology/bhk.md" };
const _hoisted_1 = /* @__PURE__ */ createStaticVNode("", 64);
const _hoisted_65 = [
  _hoisted_1
];
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, _hoisted_65);
}
const bhk = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  bhk as default
};
