import { d as defineComponent, o as openBlock, c as createElementBlock, _ as _export_sfc, L as createVNode, k as createBaseVNode, a as createTextVNode } from "./chunks/framework.2dcfa116.js";
const _hoisted_1$1 = { class: "xxxxx" };
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "index",
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$1);
    };
  }
});
const index_vue_vue_type_style_index_0_scoped_f4d21059_lang = "";
const demo = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-f4d21059"]]);
const _hoisted_1 = /* @__PURE__ */ createBaseVNode("h1", {
  id: "xxxxx",
  tabindex: "-1"
}, [
  /* @__PURE__ */ createTextVNode("xxxxx "),
  /* @__PURE__ */ createBaseVNode("a", {
    class: "header-anchor",
    href: "#xxxxx",
    "aria-label": 'Permalink to "xxxxx"'
  }, "​")
], -1);
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("h2", {
  id: "展示",
  tabindex: "-1"
}, [
  /* @__PURE__ */ createTextVNode("展示 "),
  /* @__PURE__ */ createBaseVNode("a", {
    class: "header-anchor",
    href: "#展示",
    "aria-label": 'Permalink to "展示"'
  }, "​")
], -1);
const _hoisted_3 = /* @__PURE__ */ createBaseVNode("h2", {
  id: "代码实现",
  tabindex: "-1"
}, [
  /* @__PURE__ */ createTextVNode("代码实现 "),
  /* @__PURE__ */ createBaseVNode("a", {
    class: "header-anchor",
    href: "#代码实现",
    "aria-label": 'Permalink to "代码实现"'
  }, "​")
], -1);
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("details", { class: "details custom-block" }, [
  /* @__PURE__ */ createBaseVNode("summary", null, "点击展开")
], -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("a", {
    href: "https://www.douyin.com/video/xxxxx",
    target: "_blank",
    rel: "noreferrer"
  }, "视频讲解")
], -1);
const __pageData = JSON.parse('{"title":"xxxxx","description":"","frontmatter":{},"headers":[],"relativePath":"demo/copyTemplate/main.md","filePath":"demo/copyTemplate/main.md"}');
const __default__ = { name: "demo/copyTemplate/main.md" };
const _sfc_main = /* @__PURE__ */ Object.assign(__default__, {
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", null, [
        _hoisted_1,
        _hoisted_2,
        createVNode(demo),
        _hoisted_3,
        _hoisted_4,
        _hoisted_5
      ]);
    };
  }
});
export {
  __pageData,
  _sfc_main as default
};
