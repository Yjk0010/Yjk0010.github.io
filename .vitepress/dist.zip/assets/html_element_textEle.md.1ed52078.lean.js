import { _ as _export_sfc, c as createElementBlock, o as openBlock, V as createStaticVNode } from "./chunks/framework.2dcfa116.js";
const __pageData = JSON.parse('{"title":"文本元素","description":"","frontmatter":{},"headers":[],"relativePath":"html/element/textEle.md","filePath":"html/element/textEle.md"}');
const _sfc_main = { name: "html/element/textEle.md" };
const _hoisted_1 = /* @__PURE__ */ createStaticVNode("", 21);
const _hoisted_22 = [
  _hoisted_1
];
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, _hoisted_22);
}
const textEle = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  textEle as default
};
