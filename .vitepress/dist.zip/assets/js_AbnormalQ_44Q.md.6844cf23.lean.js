import { _ as _export_sfc, H as resolveComponent, c as createElementBlock, k as createBaseVNode, I as Fragment, J as renderList, L as createVNode, V as createStaticVNode, o as openBlock, t as toDisplayString } from "./chunks/framework.2dcfa116.js";
const __pageData = JSON.parse('{"title":"44 变态题","description":"","frontmatter":{},"headers":[],"relativePath":"js/AbnormalQ/44Q.md","filePath":"js/AbnormalQ/44Q.md"}');
const _sfc_main = { name: "js/AbnormalQ/44Q.md" };
const _hoisted_1 = /* @__PURE__ */ createStaticVNode("", 63);
const _hoisted_64 = { class: "details custom-block" };
const _hoisted_65 = /* @__PURE__ */ createBaseVNode("summary", null, "前 17 个小数位", -1);
const _hoisted_66 = /* @__PURE__ */ createStaticVNode("", 65);
const _hoisted_131 = /* @__PURE__ */ createStaticVNode("", 210);
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_PicViewer = resolveComponent("PicViewer");
  return openBlock(), createElementBlock("div", null, [
    _hoisted_1,
    createBaseVNode("details", _hoisted_64, [
      _hoisted_65,
      (openBlock(), createElementBlock(Fragment, null, renderList(17, (item, index) => {
        return createBaseVNode("div", null, [
          createBaseVNode("span", null, "(" + toDisplayString(index / 10) + ").toPrecision(24) = ", 1),
          createBaseVNode("span", null, toDisplayString((index / 10).toPrecision(24)), 1)
        ]);
      }), 64))
    ]),
    _hoisted_66,
    createVNode(_component_PicViewer, {
      title: "双等号判断",
      src: "/assets/js/44Q-1.jpg",
      alt: ""
    }),
    _hoisted_131
  ]);
}
const _44Q = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  _44Q as default
};
