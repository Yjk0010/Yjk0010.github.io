import { _ as _export_sfc, c as createElementBlock, o as openBlock, V as createStaticVNode } from "./chunks/framework.2dcfa116.js";
const __pageData = JSON.parse('{"title":"数据类型","description":"","frontmatter":{},"headers":[],"relativePath":"js/base/dataType.md","filePath":"js/base/dataType.md"}');
const _sfc_main = { name: "js/base/dataType.md" };
const _hoisted_1 = /* @__PURE__ */ createStaticVNode("", 33);
const _hoisted_34 = [
  _hoisted_1
];
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, _hoisted_34);
}
const dataType = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  dataType as default
};
