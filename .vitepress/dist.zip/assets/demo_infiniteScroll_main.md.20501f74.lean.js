import { d as defineComponent, h as ref, j as onMounted, o as openBlock, c as createElementBlock, _ as _export_sfc, L as createVNode, V as createStaticVNode } from "./chunks/framework.2dcfa116.js";
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "index",
  setup(__props) {
    const scrollContainer = ref();
    const images = [
      "/assets/demo/scenery-1.jpg",
      "/assets/demo/scenery-2.jpg",
      "/assets/demo/scenery-3.jpg",
      "/assets/demo/scenery-4.jpg",
      "/assets/demo/scenery-5.jpg",
      "/assets/demo/scenery-6.jpg",
      "/assets/demo/scenery-7.jpg",
      "/assets/demo/scenery-8.jpg"
    ];
    let currentIndex = 0;
    const createImg = (index) => {
      var _a;
      const imgUrl = images[index];
      const item = document.createElement("div");
      item.classList.add("item");
      item.innerHTML = `<img src="${imgUrl}" />`;
      (_a = scrollContainer.value) == null ? void 0 : _a.appendChild(item);
      return item;
    };
    const resetElements = () => {
      if (!scrollContainer.value)
        return;
      scrollContainer.value.innerHTML = "";
      const prevIndex = currentIndex - 1 < 0 ? images.length - 1 : currentIndex - 1;
      const nextIndex = currentIndex + 1 > images.length - 1 ? 0 : currentIndex + 1;
      createImg(prevIndex).classList.add("prev");
      createImg(currentIndex).classList.add("current");
      createImg(nextIndex).classList.add("next");
    };
    onMounted(() => {
      var _a, _b;
      resetElements();
      let isAnimation = false;
      (_a = scrollContainer.value) == null ? void 0 : _a.addEventListener("wheel", (event) => {
        var _a2, _b2;
        console.log(event);
        event.preventDefault();
        if (!event.deltaY)
          return;
        if (isAnimation)
          return;
        isAnimation = true;
        if (event.deltaY > 0) {
          (_a2 = scrollContainer.value) == null ? void 0 : _a2.classList.add("scroll-down");
          currentIndex = currentIndex + 1 > images.length - 1 ? 0 : currentIndex + 1;
        } else {
          (_b2 = scrollContainer.value) == null ? void 0 : _b2.classList.add("scroll-up");
          currentIndex = currentIndex - 1 < 0 ? images.length - 1 : currentIndex - 1;
        }
      });
      (_b = scrollContainer.value) == null ? void 0 : _b.addEventListener("transitionend", () => {
        var _a2, _b2;
        isAnimation = false;
        (_a2 = scrollContainer.value) == null ? void 0 : _a2.classList.remove("scroll-down");
        (_b2 = scrollContainer.value) == null ? void 0 : _b2.classList.remove("scroll-up");
        resetElements();
      });
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        ref_key: "scrollContainer",
        ref: scrollContainer,
        class: "scroll-container"
      }, null, 512);
    };
  }
});
const index_vue_vue_type_style_index_0_scoped_9fab4ca6_lang = "";
const demo = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-9fab4ca6"]]);
const _hoisted_1 = /* @__PURE__ */ createStaticVNode("", 3);
const _hoisted_4 = /* @__PURE__ */ createStaticVNode("", 3);
const __pageData = JSON.parse('{"title":"无限视差滚动","description":"","frontmatter":{},"headers":[],"relativePath":"demo/infiniteScroll/main.md","filePath":"demo/infiniteScroll/main.md"}');
const __default__ = { name: "demo/infiniteScroll/main.md" };
const _sfc_main = /* @__PURE__ */ Object.assign(__default__, {
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", null, [
        _hoisted_1,
        createVNode(demo),
        _hoisted_4
      ]);
    };
  }
});
export {
  __pageData,
  _sfc_main as default
};
