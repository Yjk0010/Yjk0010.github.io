import { _ as _export_sfc, c as createElementBlock, o as openBlock, V as createStaticVNode } from "./chunks/framework.2dcfa116.js";
const __pageData = JSON.parse('{"title":"Vue 中使用 jsx 写法","description":"","frontmatter":{},"headers":[],"relativePath":"vue/vue3/vueJsx.md","filePath":"vue/vue3/vueJsx.md"}');
const _sfc_main = { name: "vue/vue3/vueJsx.md" };
const _hoisted_1 = /* @__PURE__ */ createStaticVNode("", 77);
const _hoisted_78 = [
  _hoisted_1
];
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, _hoisted_78);
}
const vueJsx = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  vueJsx as default
};
