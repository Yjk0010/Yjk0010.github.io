import { _ as _export_sfc, c as createElementBlock, o as openBlock, V as createStaticVNode } from "./chunks/framework.2dcfa116.js";
const __pageData = JSON.parse('{"title":"多媒体元素","description":"","frontmatter":{},"headers":[],"relativePath":"html/element/eleVideo.md","filePath":"html/element/eleVideo.md"}');
const _sfc_main = { name: "html/element/eleVideo.md" };
const _hoisted_1 = /* @__PURE__ */ createStaticVNode("", 10);
const _hoisted_11 = [
  _hoisted_1
];
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, _hoisted_11);
}
const eleVideo = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  eleVideo as default
};
