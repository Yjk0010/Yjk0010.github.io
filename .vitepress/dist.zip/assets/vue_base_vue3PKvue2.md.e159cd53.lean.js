import { o as openBlock, c as createElementBlock, H as resolveComponent, k as createBaseVNode, a as createTextVNode, L as createVNode, w as withCtx, V as createStaticVNode } from "./chunks/framework.2dcfa116.js";
const _hoisted_1$1 = { class: "cor-tip" };
const _sfc_main$1 = {
  __name: "vue3PKvue2",
  setup(__props) {
    function isObject(obj) {
      return Object.prototype.toString.call(obj) === "[object Object]";
    }
    console.log("\n--------------代码块1--------------\n");
    var obj1 = {
      a: 1
    };
    obj1.a = 4;
    console.log("输出 a = ", obj1.a);
    console.log("\n--------------代码块2--------------\n");
    var obj1 = {
      a: 1
    };
    let v = obj1.a;
    Object.defineProperty(obj1, "a", {
      // 读取a属性的值
      get() {
        console.log("读取 a = ", v);
        return v;
      },
      // 设置a属性的值
      set(value) {
        if (value !== v) {
          console.log("设置 a = ", value);
          v = value;
        }
      }
    });
    obj1.a = 5;
    console.log("打印 a =", obj1.a);
    console.log("\n--------------代码块3--------------\n");
    var obj2 = {
      a: 1,
      b: {
        c: 3
      }
    };
    function observe_defineProperty(obj) {
      for (const key in obj) {
        if (Object.hasOwnProperty.call(obj, key)) {
          let element = obj[key];
          if (isObject(element)) {
            observe_defineProperty(element);
          }
          Object.defineProperty(obj, key, {
            get() {
              console.log("读取", key, "=", JSON.stringify(element));
              return element;
            },
            set(value) {
              if (value !== element) {
                console.log("设置", key, "=", value);
                element = value;
              }
            }
          });
        }
      }
    }
    observe_defineProperty(obj2);
    obj2.a = 4;
    console.log("打印 a =", obj2.a);
    console.log("\n------------\n");
    obj2.b.c = 5;
    console.log("打印 b.c =", obj2.b.c);
    console.log("\n--------------代码块4--------------\n");
    var obj3 = {
      a: 1,
      b: {
        c: 3
      }
    };
    function observe_proxy(obj) {
      const proxy2 = new Proxy(obj, {
        get(target, key) {
          let value = Reflect.get(target, key);
          if (isObject(value)) {
            value = observe_proxy(value);
          }
          console.log("读取", key, "=", value);
          return value;
        },
        set(target, key, value) {
          if (value !== target[key]) {
            console.log("设置", key, "=", value);
            Reflect.set(target, key, value);
            return value;
          }
        }
      });
      return proxy2;
    }
    const proxy = observe_proxy(obj3);
    proxy.a = 4;
    console.log("打印 a =", proxy.a);
    console.log("\n------------\n");
    proxy.b.c = 5;
    console.log("打印 b.c =", proxy.b.c);
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$1, "全部代码位置");
    };
  }
};
const _hoisted_1 = /* @__PURE__ */ createBaseVNode("h1", {
  id: "数据响应式原理的比较",
  tabindex: "-1"
}, [
  /* @__PURE__ */ createTextVNode("数据响应式原理的比较 "),
  /* @__PURE__ */ createBaseVNode("a", {
    class: "header-anchor",
    href: "#数据响应式原理的比较",
    "aria-label": 'Permalink to "数据响应式原理的比较"'
  }, "​")
], -1);
const _hoisted_2 = {
  id: "核心-object-defineproperty-vue2-proxy-vue3",
  tabindex: "-1"
};
const _hoisted_3 = /* @__PURE__ */ createBaseVNode("span", { class: "cor-da" }, "核心", -1);
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("a", {
  class: "header-anchor",
  href: "#核心-object-defineproperty-vue2-proxy-vue3",
  "aria-label": 'Permalink to "<span class="cor-da">核心</span> Object.defineProperty <Badge type="tip">vue2</Badge> Proxy <Badge type="tip">vue3</Badge>"'
}, "​", -1);
const _hoisted_5 = /* @__PURE__ */ createStaticVNode("", 31);
const __pageData = JSON.parse('{"title":"数据响应式原理的比较","description":"","frontmatter":{},"headers":[],"relativePath":"vue/base/vue3PKvue2.md","filePath":"vue/base/vue3PKvue2.md"}');
const __default__ = { name: "vue/base/vue3PKvue2.md" };
const _sfc_main = /* @__PURE__ */ Object.assign(__default__, {
  setup(__props) {
    return (_ctx, _cache) => {
      const _component_Badge = resolveComponent("Badge");
      return openBlock(), createElementBlock("div", null, [
        _hoisted_1,
        createBaseVNode("h2", _hoisted_2, [
          _hoisted_3,
          createTextVNode(" Object.defineProperty "),
          createVNode(_component_Badge, { type: "tip" }, {
            default: withCtx(() => [
              createTextVNode("vue2")
            ]),
            _: 1
          }),
          createTextVNode(" Proxy "),
          createVNode(_component_Badge, { type: "tip" }, {
            default: withCtx(() => [
              createTextVNode("vue3")
            ]),
            _: 1
          }),
          createTextVNode(),
          _hoisted_4
        ]),
        _hoisted_5,
        createVNode(_sfc_main$1)
      ]);
    };
  }
});
export {
  __pageData,
  _sfc_main as default
};
