import { _ as _export_sfc, H as resolveComponent, c as createElementBlock, k as createBaseVNode, L as createVNode, V as createStaticVNode, o as openBlock } from "./chunks/framework.2dcfa116.js";
const __pageData = JSON.parse('{"title":"变量声明","description":"","frontmatter":{},"headers":[],"relativePath":"js/base/variable.md","filePath":"js/base/variable.md"}');
const _sfc_main = { name: "js/base/variable.md" };
const _hoisted_1 = /* @__PURE__ */ createStaticVNode("", 26);
const _hoisted_27 = { class: "details custom-block" };
const _hoisted_28 = /* @__PURE__ */ createBaseVNode("summary", null, "为什么不使用 var 声明的变量可以删除?", -1);
const _hoisted_29 = /* @__PURE__ */ createBaseVNode("p", null, "通过 var 声明的变量 和不用 var 声明的变量 window 上面 有一个不同的地方 。 最主要的体现就是 不使用 var 声明的变量可以通过 delete 删除", -1);
const _hoisted_30 = /* @__PURE__ */ createBaseVNode("p", null, "下面是原因", -1);
const _hoisted_31 = /* @__PURE__ */ createStaticVNode("", 48);
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_PicViewer = resolveComponent("PicViewer");
  return openBlock(), createElementBlock("div", null, [
    _hoisted_1,
    createBaseVNode("details", _hoisted_27, [
      _hoisted_28,
      _hoisted_29,
      createVNode(_component_PicViewer, {
        title: "var 声明变量 的删除",
        src: "/assets/js/variable-0.jpg",
        alt: ""
      }),
      _hoisted_30,
      createVNode(_component_PicViewer, {
        title: "var 声明变量 的不同之处",
        src: "/assets/js/variable-1.jpg",
        alt: ""
      })
    ]),
    _hoisted_31
  ]);
}
const variable = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  variable as default
};
