import { _ as _export_sfc, c as createElementBlock, o as openBlock, V as createStaticVNode } from "./chunks/framework.2dcfa116.js";
const __pageData = JSON.parse('{"title":"JS 语言特性","description":"","frontmatter":{},"headers":[],"relativePath":"js/base/feature.md","filePath":"js/base/feature.md"}');
const _sfc_main = { name: "js/base/feature.md" };
const _hoisted_1 = /* @__PURE__ */ createStaticVNode('<h1 id="js-语言特性" tabindex="-1">JS 语言特性 <a class="header-anchor" href="#js-语言特性" aria-label="Permalink to &quot;JS 语言特性&quot;">​</a></h1><h2 id="解释型语言" tabindex="-1">解释型语言 <a class="header-anchor" href="#解释型语言" aria-label="Permalink to &quot;解释型语言&quot;">​</a></h2><p>编译型语言：<strong>C 语言、C++、java 语言、C#语言</strong></p><blockquote><p>编译型语言会经过一个翻译的过程, 负责翻译的叫做编译器, 翻译的结果, 叫做编译结果。</p></blockquote><p><span class="cor-tip">优点：执行速度快</span></p><p><span class="cor-da">缺点：某个编译结果, 难以适用于各种环境(跨平台障碍)；部署繁琐；</span></p><p>解释型语言：<strong>js、php</strong></p><blockquote><p>解释型语言没有编译结果</p></blockquote><p><span class="cor-tip">优点：跨平台；部署简单</span></p><p><span class="cor-da">缺点：执行速度稍慢</span></p><h2 id="弱类型语言" tabindex="-1">弱类型语言 <a class="header-anchor" href="#弱类型语言" aria-label="Permalink to &quot;弱类型语言&quot;">​</a></h2><p>弱类型：<strong>存放的数据类型可变。</strong></p><p><span class="cor-tip">优点：灵活、易上手</span></p><p><span class="cor-da">缺点：不严谨</span></p><p>强类型：<strong>存放的数据类型不可变。</strong></p><p><span class="cor-tip">优点：严谨</span></p><p><span class="cor-da">缺点：不灵活、不易上手</span></p><blockquote><p>通常, 将弱类型的解释型语言, 称为脚本语言</p></blockquote><h2 id="单线程" tabindex="-1">单线程 <a class="header-anchor" href="#单线程" aria-label="Permalink to &quot;单线程&quot;">​</a></h2><p>同步现象</p><blockquote><p>上一件事情没有做完, 下一件事情必须等待。</p></blockquote><p>异步</p><blockquote><p>提高单线程的执行效率。</p></blockquote>', 23);
const _hoisted_24 = [
  _hoisted_1
];
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, _hoisted_24);
}
const feature = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  feature as default
};
