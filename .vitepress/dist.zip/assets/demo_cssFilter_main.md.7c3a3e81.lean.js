import { l as lib } from "./chunks/base.36303bf0.js";
import "./chunks/input-number.bfa998db.js";
import { d as defineComponent, u as useData, g as computed, h as ref, o as openBlock, c as createElementBlock, k as createBaseVNode, U as normalizeStyle, L as createVNode, p as pushScopeId, m as popScopeId, _ as _export_sfc, a as createTextVNode, V as createStaticVNode } from "./chunks/framework.2dcfa116.js";
const _imports_0 = "/assets/firefox.6ce8d871.svg";
const _withScopeId = (n) => (pushScopeId("data-v-68d6c278"), n = n(), popScopeId(), n);
const _hoisted_1$1 = { class: "card one" };
const _hoisted_2$1 = /* @__PURE__ */ _withScopeId(() => /* @__PURE__ */ createBaseVNode("div", { class: "title" }, "不规则图形上阴影 - drop-shadow", -1));
const _hoisted_3$1 = /* @__PURE__ */ _withScopeId(() => /* @__PURE__ */ createBaseVNode("img", {
  class: "no-img",
  src: _imports_0
}, null, -1));
const _hoisted_4 = [
  _hoisted_3$1
];
const _hoisted_5 = { class: "card" };
const _hoisted_6 = /* @__PURE__ */ _withScopeId(() => /* @__PURE__ */ createBaseVNode("div", { class: "title" }, "增加高斯模糊 - blur", -1));
const _hoisted_7 = { class: "card" };
const _hoisted_8 = /* @__PURE__ */ _withScopeId(() => /* @__PURE__ */ createBaseVNode("div", { class: "title" }, "明暗调节 - brightness", -1));
const _hoisted_9 = { class: "card" };
const _hoisted_10 = /* @__PURE__ */ _withScopeId(() => /* @__PURE__ */ createBaseVNode("div", { class: "title" }, "对比度调节 - contrast", -1));
const _hoisted_11 = { class: "card" };
const _hoisted_12 = /* @__PURE__ */ _withScopeId(() => /* @__PURE__ */ createBaseVNode("div", { class: "title" }, "灰度调节 - grayscale", -1));
const _hoisted_13 = { class: "card" };
const _hoisted_14 = /* @__PURE__ */ _withScopeId(() => /* @__PURE__ */ createBaseVNode("div", { class: "title" }, "色调调节 - hue-rotate", -1));
const _hoisted_15 = { class: "card" };
const _hoisted_16 = /* @__PURE__ */ _withScopeId(() => /* @__PURE__ */ createBaseVNode("div", { class: "title" }, "反色调调节 - invert", -1));
const _hoisted_17 = { class: "card" };
const _hoisted_18 = /* @__PURE__ */ _withScopeId(() => /* @__PURE__ */ createBaseVNode("div", { class: "title" }, "透明度调节 - opacity", -1));
const _hoisted_19 = { class: "card" };
const _hoisted_20 = /* @__PURE__ */ _withScopeId(() => /* @__PURE__ */ createBaseVNode("div", { class: "title" }, "图像饱和度 - saturate", -1));
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "index",
  setup(__props) {
    const { isDark } = useData();
    const styleDropShadow = computed(() => {
      return {
        filter: `drop-shadow(0 0 10px ${isDark.value ? "white" : "black"})`
      };
    });
    const blurNumber = ref(0);
    const styleBlur = computed(() => {
      return {
        filter: `blur(${blurNumber.value}px)`
      };
    });
    const brightnessNumber = ref(100);
    const styleBrightness = computed(() => {
      return {
        filter: `brightness(${brightnessNumber.value}%)`
      };
    });
    const contrastNumber = ref(100);
    const styleContrast = computed(() => {
      return {
        filter: `contrast(${contrastNumber.value}%)`
      };
    });
    const grayscaleNumber = ref(0);
    const styleGrayscale = computed(() => {
      return {
        filter: `grayscale(${grayscaleNumber.value}%)`
      };
    });
    const hueRotateNumber = ref(0);
    const styleHueRotate = computed(() => {
      return {
        filter: `hue-rotate(${hueRotateNumber.value}deg)`
      };
    });
    const invertNumber = ref(0);
    const styleInvert = computed(() => {
      return {
        filter: `invert(${invertNumber.value}%)`
      };
    });
    const opacityNumber = ref(100);
    const styleOpacity = computed(() => {
      return {
        filter: `opacity(${opacityNumber.value}%)`
      };
    });
    const saturateNumber = ref(100);
    const styleSaturate = computed(() => {
      return {
        filter: `saturate(${saturateNumber.value}%)`
      };
    });
    const containerStyle = computed(() => {
      return {
        "--cardShadowColor": isDark.value ? "rgba(255,255,255,.3)" : "rgba(0,0,0,.3)"
      };
    });
    return (_ctx, _cache) => {
      const _component_el_input_number = lib.ElInputNumber;
      return openBlock(), createElementBlock("div", {
        class: "container",
        style: normalizeStyle(containerStyle.value)
      }, [
        createBaseVNode("div", _hoisted_1$1, [
          _hoisted_2$1,
          createBaseVNode("img", {
            class: "logo image",
            src: _imports_0,
            style: normalizeStyle(styleDropShadow.value)
          }, null, 4),
          createBaseVNode("div", {
            class: "no-img-container image",
            style: normalizeStyle(styleDropShadow.value)
          }, _hoisted_4, 4)
        ]),
        createBaseVNode("div", _hoisted_5, [
          _hoisted_6,
          createVNode(_component_el_input_number, {
            modelValue: blurNumber.value,
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => blurNumber.value = $event),
            min: 0,
            max: Infinity
          }, null, 8, ["modelValue"]),
          createBaseVNode("img", {
            class: "logo",
            src: _imports_0,
            style: normalizeStyle(styleBlur.value)
          }, null, 4)
        ]),
        createBaseVNode("div", _hoisted_7, [
          _hoisted_8,
          createVNode(_component_el_input_number, {
            modelValue: brightnessNumber.value,
            "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => brightnessNumber.value = $event),
            step: 10,
            min: 0,
            max: Infinity
          }, null, 8, ["modelValue"]),
          createBaseVNode("img", {
            class: "logo",
            src: _imports_0,
            style: normalizeStyle(styleBrightness.value)
          }, null, 4)
        ]),
        createBaseVNode("div", _hoisted_9, [
          _hoisted_10,
          createVNode(_component_el_input_number, {
            modelValue: contrastNumber.value,
            "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => contrastNumber.value = $event),
            step: 10,
            min: 0,
            max: Infinity
          }, null, 8, ["modelValue"]),
          createBaseVNode("img", {
            class: "logo",
            src: _imports_0,
            style: normalizeStyle(styleContrast.value)
          }, null, 4)
        ]),
        createBaseVNode("div", _hoisted_11, [
          _hoisted_12,
          createVNode(_component_el_input_number, {
            modelValue: grayscaleNumber.value,
            "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => grayscaleNumber.value = $event),
            step: 10,
            min: 0,
            max: 100
          }, null, 8, ["modelValue"]),
          createBaseVNode("img", {
            class: "logo",
            src: _imports_0,
            style: normalizeStyle(styleGrayscale.value)
          }, null, 4)
        ]),
        createBaseVNode("div", _hoisted_13, [
          _hoisted_14,
          createVNode(_component_el_input_number, {
            modelValue: hueRotateNumber.value,
            "onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => hueRotateNumber.value = $event),
            step: 10,
            min: 0,
            max: 360
          }, null, 8, ["modelValue"]),
          createBaseVNode("img", {
            class: "logo",
            src: _imports_0,
            style: normalizeStyle(styleHueRotate.value)
          }, null, 4)
        ]),
        createBaseVNode("div", _hoisted_15, [
          _hoisted_16,
          createVNode(_component_el_input_number, {
            modelValue: invertNumber.value,
            "onUpdate:modelValue": _cache[5] || (_cache[5] = ($event) => invertNumber.value = $event),
            step: 10,
            min: 0,
            max: 100
          }, null, 8, ["modelValue"]),
          createBaseVNode("img", {
            class: "logo",
            src: _imports_0,
            style: normalizeStyle(styleInvert.value)
          }, null, 4)
        ]),
        createBaseVNode("div", _hoisted_17, [
          _hoisted_18,
          createVNode(_component_el_input_number, {
            modelValue: opacityNumber.value,
            "onUpdate:modelValue": _cache[6] || (_cache[6] = ($event) => opacityNumber.value = $event),
            step: 10,
            min: 0,
            max: 100
          }, null, 8, ["modelValue"]),
          createBaseVNode("img", {
            class: "logo",
            src: _imports_0,
            style: normalizeStyle(styleOpacity.value)
          }, null, 4)
        ]),
        createBaseVNode("div", _hoisted_19, [
          _hoisted_20,
          createVNode(_component_el_input_number, {
            modelValue: saturateNumber.value,
            "onUpdate:modelValue": _cache[7] || (_cache[7] = ($event) => saturateNumber.value = $event),
            step: 10,
            min: 0,
            max: Infinity
          }, null, 8, ["modelValue"]),
          createBaseVNode("img", {
            class: "logo",
            src: _imports_0,
            style: normalizeStyle(styleSaturate.value)
          }, null, 4)
        ])
      ], 4);
    };
  }
});
const index_vue_vue_type_style_index_0_scoped_68d6c278_lang = "";
const demo = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-68d6c278"]]);
const _hoisted_1 = /* @__PURE__ */ createBaseVNode("h1", {
  id: "css-滤镜",
  tabindex: "-1"
}, [
  /* @__PURE__ */ createTextVNode("css 滤镜 "),
  /* @__PURE__ */ createBaseVNode("a", {
    class: "header-anchor",
    href: "#css-滤镜",
    "aria-label": 'Permalink to "css 滤镜"'
  }, "​")
], -1);
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("h2", {
  id: "展示-filter-属性",
  tabindex: "-1"
}, [
  /* @__PURE__ */ createTextVNode("展示 filter 属性 "),
  /* @__PURE__ */ createBaseVNode("a", {
    class: "header-anchor",
    href: "#展示-filter-属性",
    "aria-label": 'Permalink to "展示 filter 属性"'
  }, "​")
], -1);
const _hoisted_3 = /* @__PURE__ */ createStaticVNode("", 2);
const __pageData = JSON.parse('{"title":"css 滤镜","description":"","frontmatter":{},"headers":[],"relativePath":"demo/cssFilter/main.md","filePath":"demo/cssFilter/main.md"}');
const __default__ = { name: "demo/cssFilter/main.md" };
const _sfc_main = /* @__PURE__ */ Object.assign(__default__, {
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", null, [
        _hoisted_1,
        _hoisted_2,
        createVNode(demo),
        _hoisted_3
      ]);
    };
  }
});
export {
  __pageData,
  _sfc_main as default
};
