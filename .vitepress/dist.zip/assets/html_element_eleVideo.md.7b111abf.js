import { _ as _export_sfc, c as createElementBlock, o as openBlock, V as createStaticVNode } from "./chunks/framework.2dcfa116.js";
const __pageData = JSON.parse('{"title":"多媒体元素","description":"","frontmatter":{},"headers":[],"relativePath":"html/element/eleVideo.md","filePath":"html/element/eleVideo.md"}');
const _sfc_main = { name: "html/element/eleVideo.md" };
const _hoisted_1 = /* @__PURE__ */ createStaticVNode('<h1 id="多媒体元素" tabindex="-1">多媒体元素 <a class="header-anchor" href="#多媒体元素" aria-label="Permalink to &quot;多媒体元素&quot;">​</a></h1><p>video 视频</p><p>audio 音频</p><h2 id="video" tabindex="-1">video <a class="header-anchor" href="#video" aria-label="Permalink to &quot;video&quot;">​</a></h2><p>controls: 控制控件的显示，取值只能为 controls</p><p>autoplay: 布尔属性，自动播放。</p><p>muted: 布尔属性，静音播放。</p><p>loop: 布尔属性，循环播放</p><h2 id="audio" tabindex="-1">audio <a class="header-anchor" href="#audio" aria-label="Permalink to &quot;audio&quot;">​</a></h2><p>和视频完全一致</p>', 10);
const _hoisted_11 = [
  _hoisted_1
];
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, _hoisted_11);
}
const eleVideo = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  eleVideo as default
};
