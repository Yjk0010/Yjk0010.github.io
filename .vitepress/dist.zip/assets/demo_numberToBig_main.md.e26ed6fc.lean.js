import { l as lib } from "./chunks/base.36303bf0.js";
import "./chunks/input-number.bfa998db.js";
import { d as defineComponent, h as ref, g as computed, o as openBlock, c as createElementBlock, k as createBaseVNode, L as createVNode, t as toDisplayString, p as pushScopeId, m as popScopeId, _ as _export_sfc, a as createTextVNode, V as createStaticVNode } from "./chunks/framework.2dcfa116.js";
const _withScopeId = (n) => (pushScopeId("data-v-7e00848a"), n = n(), popScopeId(), n);
const _hoisted_1$1 = { class: "container" };
const _hoisted_2$1 = { class: "input" };
const _hoisted_3$1 = /* @__PURE__ */ _withScopeId(() => /* @__PURE__ */ createBaseVNode("span", null, "你现在有多少钱", -1));
const _hoisted_4 = { class: "view" };
const _hoisted_5 = { class: "cor-tip" };
const _hoisted_6 = /* @__PURE__ */ _withScopeId(() => /* @__PURE__ */ createBaseVNode("span", null, "假如一度电是1块钱，你", -1));
const _hoisted_7 = { class: "cor-wa" };
const _hoisted_8 = /* @__PURE__ */ _withScopeId(() => /* @__PURE__ */ createBaseVNode("span", null, "能购买", -1));
const _hoisted_9 = { class: "cor-da" };
const _hoisted_10 = /* @__PURE__ */ _withScopeId(() => /* @__PURE__ */ createBaseVNode("span", null, "的电", -1));
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "index",
  setup(__props) {
    const number = ref(1994041373e-2);
    const bigStringMoney = computed(() => {
      return numberToBigChineseString(number.value);
    });
    const bigStringKWh = computed(() => {
      return numberToBigChineseString(number.value, {
        isMoney: false,
        def: "数字超限",
        suffix: "千瓦时"
      });
    });
    const formatMoney = computed(() => {
      return number.value.toLocaleString("zh", {
        maximumFractionDigits: 3,
        minimumFractionDigits: 3,
        style: "currency",
        currency: "CNY"
      });
    });
    const configData = {
      chars: ["零", "壹", "贰", "叁", "肆", "伍", "陆", "柒", "捌", "玖"],
      bigUnits: ["", "万", "亿", "兆"],
      units: ["", "拾", "佰", "仟"],
      smallUnits: ["角", "分", "厘"],
      suffixIntMoney: "元",
      suffixIntMoneySuffix: "整",
      point: "点",
      zero: "零"
    };
    const configDefault = {
      isMoney: true,
      def: "--",
      suffix: ""
    };
    const isDecimal = (num) => {
      return Number.isInteger(num);
    };
    const isSafeNumber = (num) => {
      if (isDecimal(num)) {
        return Number.isSafeInteger(num);
      } else {
        return Number.isFinite(num);
      }
    };
    const convertDigitsToChinese = (numStr) => {
      let resultStr = "";
      for (let i = 0; i < numStr.length; i++) {
        const digit = +numStr[i];
        const c = configData.chars[digit];
        const u = configData.units[numStr.length - 1 - i];
        if (digit === 0) {
          if (resultStr[resultStr.length - 1] !== configData.zero) {
            resultStr += c;
          }
        } else {
          resultStr += c + u;
        }
      }
      if (resultStr[resultStr.length - 1] === configData.zero) {
        resultStr = resultStr.slice(0, -1);
      }
      return resultStr;
    };
    const numberToBigChineseString = (num, obj = {}) => {
      const configDef = { ...configDefault, ...obj };
      if (!isSafeNumber(num))
        return `${configDef.def}`;
      const str = num.toString();
      const [intStr, decimalStr] = str.split(".");
      const intStrArr = intStr.replace(/(?=(\d{4})+$)/g, ",").split(",").filter(Boolean);
      let result = intStrArr.reduce((pre, cur, index) => {
        const c = convertDigitsToChinese(cur);
        return pre + c + (c ? configData.bigUnits[intStrArr.length - 1 - index] : "");
      }, "");
      if (result) {
        result += configDef.isMoney ? configData.suffixIntMoney : "";
      } else {
        result = configDef.isMoney ? `` : `${configData.zero}`;
      }
      if (decimalStr) {
        result = configData.smallUnits.reduce((pre, cur, index) => {
          const value = +decimalStr[index];
          return pre + (Number.isNaN(value) ? "" : value ? `${configData.chars[value]}${configDef.isMoney ? cur : ""}` : configDef.isMoney ? "" : configData.zero);
        }, result + (configDef.isMoney ? `` : configData.point));
      } else {
        result += result ? configDef.isMoney ? configData.suffixIntMoneySuffix : `` : ``;
      }
      result += configDef.isMoney ? "" : configDef.suffix;
      return result || configData.zero;
    };
    return (_ctx, _cache) => {
      const _component_el_input_number = lib.ElInputNumber;
      return openBlock(), createElementBlock("div", _hoisted_1$1, [
        createBaseVNode("div", _hoisted_2$1, [
          _hoisted_3$1,
          createVNode(_component_el_input_number, {
            step: 1e-3,
            "step-strictly": "",
            style: { "width": "240px" },
            modelValue: number.value,
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => number.value = $event)
          }, null, 8, ["modelValue"])
        ]),
        createBaseVNode("div", _hoisted_4, [
          createBaseVNode("div", _hoisted_5, toDisplayString(formatMoney.value), 1),
          _hoisted_6,
          createBaseVNode("div", _hoisted_7, toDisplayString(bigStringMoney.value), 1),
          _hoisted_8,
          createBaseVNode("div", _hoisted_9, toDisplayString(bigStringKWh.value), 1),
          _hoisted_10
        ])
      ]);
    };
  }
});
const index_vue_vue_type_style_index_0_scoped_7e00848a_lang = "";
const demo = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-7e00848a"]]);
const _hoisted_1 = /* @__PURE__ */ createBaseVNode("h1", {
  id: "数字转大写",
  tabindex: "-1"
}, [
  /* @__PURE__ */ createTextVNode("数字转大写 "),
  /* @__PURE__ */ createBaseVNode("a", {
    class: "header-anchor",
    href: "#数字转大写",
    "aria-label": 'Permalink to "数字转大写"'
  }, "​")
], -1);
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("h2", {
  id: "展示",
  tabindex: "-1"
}, [
  /* @__PURE__ */ createTextVNode("展示 "),
  /* @__PURE__ */ createBaseVNode("a", {
    class: "header-anchor",
    href: "#展示",
    "aria-label": 'Permalink to "展示"'
  }, "​")
], -1);
const _hoisted_3 = /* @__PURE__ */ createStaticVNode("", 3);
const __pageData = JSON.parse('{"title":"数字转大写","description":"","frontmatter":{},"headers":[],"relativePath":"demo/numberToBig/main.md","filePath":"demo/numberToBig/main.md"}');
const __default__ = { name: "demo/numberToBig/main.md" };
const _sfc_main = /* @__PURE__ */ Object.assign(__default__, {
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", null, [
        _hoisted_1,
        _hoisted_2,
        createVNode(demo),
        _hoisted_3
      ]);
    };
  }
});
export {
  __pageData,
  _sfc_main as default
};
