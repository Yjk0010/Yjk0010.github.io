import { l as lib } from "./chunks/base.36303bf0.js";
import "./chunks/button.fdf0e29d.js";
import { d as defineComponent, u as useData, h as ref, j as onMounted, o as openBlock, c as createElementBlock, k as createBaseVNode, n as normalizeClass, U as normalizeStyle, l as unref, L as createVNode, w as withCtx, a as createTextVNode, V as createStaticVNode, _ as _export_sfc } from "./chunks/framework.2dcfa116.js";
const _hoisted_1$1 = { class: "svgStroke" };
const _hoisted_2$1 = /* @__PURE__ */ createStaticVNode('<ellipse ry="70" rx="70" cy="147.5" cx="137" class="p" data-v-e344185e></ellipse><ellipse ry="42" rx="42" cy="49" cx="48.5" class="p" data-v-e344185e></ellipse><ellipse ry="35" rx="35" cy="148" cx="252.5" class="p" data-v-e344185e></ellipse><ellipse ry="15" rx="15" cy="89" cx="278" class="p" data-v-e344185e></ellipse><ellipse ry="32" rx="32" cy="260.5" cx="131" class="p" data-v-e344185e></ellipse><ellipse ry="18" rx="18" cy="118" cx="45" class="p" data-v-e344185e></ellipse><path d="m14.17988,126c-9.96402,57.47692 15.13462,113.88462 74.82012,131" class="p" data-v-e344185e></path><path d="m103,35c59.02702,-19 116.24324,10 136,53" class="p" data-v-e344185e></path><path d="m166,263" class="p" data-v-e344185e></path><path d="m173,262c36.81579,-7 55.31579,-20 71,-61" class="p" data-v-e344185e></path><path d="m93,178c0.47945,10.86931 11.0274,23.41081 35,21.32056" class="p" data-v-e344185e></path>', 11);
const _hoisted_13 = [
  _hoisted_2$1
];
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "index",
  setup(__props) {
    const { isDark } = useData();
    const isTrue = ref(false);
    const svgStroke = ref();
    onMounted(() => {
      var _a;
      if (svgStroke.value) {
        const paths = Array.from(
          ((_a = svgStroke.value) == null ? void 0 : _a.children) || []
        );
        for (const path of paths) {
          const totalLength = Math.ceil(path.getTotalLength());
          path.style.setProperty("--svgStroke-l", `${totalLength}`);
        }
      }
    });
    return (_ctx, _cache) => {
      const _component_el_button = lib.ElButton;
      return openBlock(), createElementBlock("div", _hoisted_1$1, [
        createBaseVNode("div", {
          class: normalizeClass(["container", { active: isTrue.value }]),
          style: normalizeStyle({ "--svgStroke-color": unref(isDark) ? "#d7ecb1" : "#666" })
        }, [
          (openBlock(), createElementBlock("svg", {
            width: "200",
            height: "200",
            viewBox: "0 0 300 300",
            ref_key: "svgStroke",
            ref: svgStroke
          }, _hoisted_13, 512))
        ], 6),
        createVNode(_component_el_button, {
          onClick: _cache[0] || (_cache[0] = ($event) => isTrue.value = true)
        }, {
          default: withCtx(() => [
            createTextVNode("启动动画")
          ]),
          _: 1
        }),
        createVNode(_component_el_button, {
          onClick: _cache[1] || (_cache[1] = ($event) => isTrue.value = false)
        }, {
          default: withCtx(() => [
            createTextVNode("隐藏")
          ]),
          _: 1
        })
      ]);
    };
  }
});
const index_vue_vue_type_style_index_0_scoped_e344185e_lang = "";
const demo = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-e344185e"]]);
const _hoisted_1 = /* @__PURE__ */ createBaseVNode("h1", {
  id: "svg-描边动画",
  tabindex: "-1"
}, [
  /* @__PURE__ */ createTextVNode("Svg 描边动画 "),
  /* @__PURE__ */ createBaseVNode("a", {
    class: "header-anchor",
    href: "#svg-描边动画",
    "aria-label": 'Permalink to "Svg 描边动画"'
  }, "​")
], -1);
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("h2", {
  id: "展示",
  tabindex: "-1"
}, [
  /* @__PURE__ */ createTextVNode("展示 "),
  /* @__PURE__ */ createBaseVNode("a", {
    class: "header-anchor",
    href: "#展示",
    "aria-label": 'Permalink to "展示"'
  }, "​")
], -1);
const _hoisted_3 = /* @__PURE__ */ createBaseVNode("p", null, "请点击启动按钮", -1);
const _hoisted_4 = /* @__PURE__ */ createStaticVNode("", 3);
const __pageData = JSON.parse('{"title":"Svg 描边动画","description":"","frontmatter":{},"headers":[],"relativePath":"demo/svgStroke/main.md","filePath":"demo/svgStroke/main.md"}');
const __default__ = { name: "demo/svgStroke/main.md" };
const _sfc_main = /* @__PURE__ */ Object.assign(__default__, {
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", null, [
        _hoisted_1,
        _hoisted_2,
        _hoisted_3,
        createVNode(demo),
        _hoisted_4
      ]);
    };
  }
});
export {
  __pageData,
  _sfc_main as default
};
