import { _ as _export_sfc, c as createElementBlock, o as openBlock, V as createStaticVNode, k as createBaseVNode } from "./chunks/framework.2dcfa116.js";
const __pageData = JSON.parse('{"title":"iframe 元素","description":"","frontmatter":{},"headers":[],"relativePath":"html/element/eleIframe.md","filePath":"html/element/eleIframe.md"}');
const _sfc_main = { name: "html/element/eleIframe.md" };
const _hoisted_1 = /* @__PURE__ */ createStaticVNode('<h1 id="iframe-元素" tabindex="-1">iframe 元素 <a class="header-anchor" href="#iframe-元素" aria-label="Permalink to &quot;iframe 元素&quot;">​</a></h1><p>框架页</p><blockquote><p>通常用于在网页中嵌入另一个页面</p></blockquote><ol><li>通常行盒</li><li>通常显示的内容取决于元素的属性</li><li>CSS 不能完全控制其中的样式</li><li>具有行快盒的特点</li></ol><blockquote><p>拿小破站举个例子</p></blockquote>', 5);
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("iframe", {
  src: "//player.bilibili.com/player.html?aid=2871480&bvid=BV1Ts411U7wt&cid=4486145&page=1",
  scrolling: "no",
  border: "0",
  frameborder: "no",
  framespacing: "0",
  allowfullscreen: "true"
}, null, -1);
const _hoisted_7 = /* @__PURE__ */ createStaticVNode('<div class="language-html"><button title="Copy Code" class="copy"></button><span class="lang">html</span><pre class="shiki material-theme-palenight"><code><span class="line"><span style="color:#89DDFF;">&lt;</span><span style="color:#F07178;">iframe</span></span>\n<span class="line"><span style="color:#89DDFF;">  </span><span style="color:#C792EA;">src</span><span style="color:#89DDFF;">=</span><span style="color:#89DDFF;">&quot;</span><span style="color:#C3E88D;">//player.bilibili.com/player.html?aid=2871480&amp;bvid=BV1Ts411U7wt&amp;cid=4486145&amp;page=1</span><span style="color:#89DDFF;">&quot;</span></span>\n<span class="line"><span style="color:#89DDFF;">  </span><span style="color:#C792EA;">scrolling</span><span style="color:#89DDFF;">=</span><span style="color:#89DDFF;">&quot;</span><span style="color:#C3E88D;">no</span><span style="color:#89DDFF;">&quot;</span></span>\n<span class="line"><span style="color:#89DDFF;">  border=</span><span style="color:#89DDFF;">&quot;</span><span style="color:#C3E88D;">0</span><span style="color:#89DDFF;">&quot;</span></span>\n<span class="line"><span style="color:#89DDFF;">  </span><span style="color:#C792EA;">frameborder</span><span style="color:#89DDFF;">=</span><span style="color:#89DDFF;">&quot;</span><span style="color:#C3E88D;">no</span><span style="color:#89DDFF;">&quot;</span></span>\n<span class="line"><span style="color:#89DDFF;">  </span><span style="color:#C792EA;">framespacing</span><span style="color:#89DDFF;">=</span><span style="color:#89DDFF;">&quot;</span><span style="color:#C3E88D;">0</span><span style="color:#89DDFF;">&quot;</span></span>\n<span class="line"><span style="color:#89DDFF;">  </span><span style="color:#C792EA;">allowfullscreen</span><span style="color:#89DDFF;">=</span><span style="color:#89DDFF;">&quot;</span><span style="color:#C3E88D;">true</span><span style="color:#89DDFF;">&quot;</span></span>\n<span class="line"><span style="color:#89DDFF;">&gt;&lt;/</span><span style="color:#F07178;">iframe</span><span style="color:#89DDFF;">&gt;</span></span></code></pre></div>', 1);
const _hoisted_8 = [
  _hoisted_1,
  _hoisted_6,
  _hoisted_7
];
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, _hoisted_8);
}
const eleIframe = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  eleIframe as default
};
