import { _ as _export_sfc, H as resolveComponent, c as createElementBlock, L as createVNode, k as createBaseVNode, a as createTextVNode, V as createStaticVNode, o as openBlock } from "./chunks/framework.2dcfa116.js";
const __pageData = JSON.parse('{"title":"CSS 属性计算过程","description":"","frontmatter":{},"headers":[],"relativePath":"css/attr/attrCalcProcess.md","filePath":"css/attr/attrCalcProcess.md"}');
const _sfc_main = { name: "css/attr/attrCalcProcess.md" };
const _hoisted_1 = /* @__PURE__ */ createBaseVNode("h1", {
  id: "css-属性计算过程",
  tabindex: "-1"
}, [
  /* @__PURE__ */ createTextVNode("CSS 属性计算过程 "),
  /* @__PURE__ */ createBaseVNode("a", {
    class: "header-anchor",
    href: "#css-属性计算过程",
    "aria-label": 'Permalink to "CSS 属性计算过程"'
  }, "​")
], -1);
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("blockquote", null, [
  /* @__PURE__ */ createBaseVNode("p", null, "我们所书写的任何一个 HTML 元素，实际上都有完整的一整套 CSS 样式"),
  /* @__PURE__ */ createBaseVNode("p", null, [
    /* @__PURE__ */ createTextVNode("这个可以从这边 chrome 控制台 element 随便选中一个元素 标签右边点击 "),
    /* @__PURE__ */ createBaseVNode("span", { class: "cor-tip" }, "computed")
  ]),
  /* @__PURE__ */ createBaseVNode("p", null, [
    /* @__PURE__ */ createTextVNode("选中 "),
    /* @__PURE__ */ createBaseVNode("code", null, "show all"),
    /* @__PURE__ */ createTextVNode(" 可以看到所有的计算好的属性")
  ])
], -1);
const _hoisted_3 = /* @__PURE__ */ createStaticVNode('<blockquote><p>所以就是 <span class="cor-wa">我们所书写的任何一个 HTML 元素，实际上都有完整的一整套 CSS 样式</span></p></blockquote><h2 id="属性的计算过程" tabindex="-1">属性的计算过程 <a class="header-anchor" href="#属性的计算过程" aria-label="Permalink to &quot;属性的计算过程&quot;">​</a></h2><blockquote><p>既然有这么多属性 这些属性怎么出来的 如下</p><p>这边先上个代码例子</p></blockquote><div class="language-html"><button title="Copy Code" class="copy"></button><span class="lang">html</span><pre class="shiki material-theme-palenight"><code><span class="line"><span style="color:#89DDFF;">&lt;</span><span style="color:#F07178;">div</span><span style="color:#89DDFF;">&gt;</span></span>\n<span class="line"><span style="color:#A6ACCD;">  </span><span style="color:#89DDFF;">&lt;</span><span style="color:#F07178;">h1</span><span style="color:#89DDFF;">&gt;</span><span style="color:#A6ACCD;">这是个H1</span><span style="color:#89DDFF;">&lt;/</span><span style="color:#F07178;">h1</span><span style="color:#89DDFF;">&gt;</span></span>\n<span class="line"><span style="color:#A6ACCD;">  </span><span style="color:#89DDFF;">&lt;</span><span style="color:#F07178;">p</span><span style="color:#89DDFF;"> </span><span style="color:#C792EA;">style</span><span style="color:#89DDFF;">=</span><span style="color:#89DDFF;">&quot;</span><span style="color:#C3E88D;">color:red</span><span style="color:#89DDFF;">&quot;</span><span style="color:#89DDFF;">&gt;</span><span style="color:#A6ACCD;">这是个段落</span><span style="color:#89DDFF;">&lt;/</span><span style="color:#F07178;">p</span><span style="color:#89DDFF;">&gt;</span></span>\n<span class="line"><span style="color:#89DDFF;">&lt;/</span><span style="color:#F07178;">div</span><span style="color:#89DDFF;">&gt;</span></span></code></pre></div><h2 id="确定声明值" tabindex="-1">确定声明值 <a class="header-anchor" href="#确定声明值" aria-label="Permalink to &quot;确定声明值&quot;">​</a></h2><blockquote><p>首先第一步，是确定声明值。所谓声明值就是作者自己所书写的 CSS 样式。</p></blockquote><p>这里我们声明了 p 元素为红色，那么就会应用此属性设置。 当然，除了作者样式表，一般浏览器还会存在“用户代理样式表”，简单来讲就是浏览器内置了一套样式表。</p>', 7);
const _hoisted_10 = /* @__PURE__ */ createStaticVNode('<p>在上面的示例中，作者样式表中设置了 color 属性，而用户代理样式表（浏览器提供的样式表）中设置了诸如 display、margin-block-start、margin-block-end、margin-inline-start、margin-inline-end 等属性对应的值。 这些值目前来讲也没有什么冲突，因此最终就会应用这些属性值。</p><h2 id="层叠冲突" tabindex="-1">层叠冲突 <a class="header-anchor" href="#层叠冲突" aria-label="Permalink to &quot;层叠冲突&quot;">​</a></h2><blockquote><p>在确定声明值时，可能出现一种情况，那就是声明的样式规则发生了冲突。 此时会进入解决层叠冲突的流程。而这一步又可以细分为下面这三个步骤： 比较源的重要性比较优先级比较次序 来来来，我们一步一步来看。</p></blockquote><h3 id="比较源的重要性" tabindex="-1">比较源的重要性 <a class="header-anchor" href="#比较源的重要性" aria-label="Permalink to &quot;比较源的重要性&quot;">​</a></h3><blockquote><p>当不同的 CSS 样式来源拥有相同的声明时，此时就会根据样式表来源的重要性来确定应用哪一条样式规则。 那么问题来了，咱们的样式表的源究竟有几种呢？</p></blockquote><p>整体来讲有三种来源：<br> 浏览器会有一个基本的样式表来给任何网页设置默认样式。这些样式统称<code>用户代理样式</code>。<br> 网页的作者可以定义文档的样式，这是最常见的样式表，称之为<code>页面作者样式</code>。<br> 浏览器的用户，可以使用自定义样式表定制使用体验，称之为<code>用户样式</code>。 对应的重要性顺序依次为：页面作者样式 &gt; 用户样式 &gt; 用户代理样式<br> 更详细的来源重要性比较，可以参阅 <a href="https://developer.mozilla.org/zh-CN/docs/Web/CSS/Cascade" target="_blank" rel="noreferrer">MDN Cascade</a><br> 我们来看一个示例。 例如现在有<code>页面作者样式表</code>和<code>用户代理样式表</code>中存在属性的冲突，那么会以<code>作者样式表</code>优先。</p>', 6);
const _hoisted_16 = /* @__PURE__ */ createStaticVNode('<p>可以明显的看到，<code>作者样式表</code>和<code>用户代理样式表</code>中同时存在的 display 属性的设置，最终<code>作者样式表</code>干掉了<code>用户代理样式表</code>中冲突的属性。<br> 这就是第一步，根据不同源的重要性来决定应用哪一个源的样式。</p><h3 id="比较优先级" tabindex="-1">比较优先级 <a class="header-anchor" href="#比较优先级" aria-label="Permalink to &quot;比较优先级&quot;">​</a></h3><blockquote><p>那么接下来，如果是在在同一个源中有样式声明冲突怎么办呢？此时就会进行样式声明的优先级比较。</p></blockquote><p>在上面的代码中，同属于<strong>页面作者样式</strong>，源的重要性是相同的，此时会以选择器的权重来比较重要性。 很明显，上面的选择器的权重要大于下面的选择器，因此最终标题呈现为 <code>50px</code> 。</p>', 4);
const _hoisted_20 = /* @__PURE__ */ createStaticVNode('<p>可以看到，落败的作者样式在 <em>Elements&gt;Styles</em> 中会被划掉。 有关选择器权重的计算方式，不清楚的同学，可以进入此传送门：<a href="https://developer.mozilla.org/en-US/docs/Web/CSS/Specificity" target="_blank" rel="noreferrer">MDN Specificity</a></p><h3 id="比较次序" tabindex="-1">比较次序 <a class="header-anchor" href="#比较次序" aria-label="Permalink to &quot;比较次序&quot;">​</a></h3><blockquote><p>经历了上面两个步骤，大多数的样式声明能够被确定下来。但是还剩下最后一种情况，那就是样式声明既是同源，权重也相同。 此时就会进入第三个步骤，比较样式声明的次序。</p></blockquote><p>这里的代码中，同样都是<code>页面作者样式</code>，<code>选择器的权重也相同</code>，此时位于下面的样式声明会层叠掉上面的那一条样式声明，最终会应用 <code>40px</code> 这一条属性值。</p>', 4);
const _hoisted_24 = /* @__PURE__ */ createBaseVNode("p", null, "至此，样式声明中存在冲突的所有情况，就全部被解决了。", -1);
const _hoisted_25 = /* @__PURE__ */ createBaseVNode("h2", {
  id: "使用继承",
  tabindex: "-1"
}, [
  /* @__PURE__ */ createTextVNode("使用继承 "),
  /* @__PURE__ */ createBaseVNode("a", {
    class: "header-anchor",
    href: "#使用继承",
    "aria-label": 'Permalink to "使用继承"'
  }, "​")
], -1);
const _hoisted_26 = /* @__PURE__ */ createBaseVNode("blockquote", null, [
  /* @__PURE__ */ createBaseVNode("p", null, [
    /* @__PURE__ */ createTextVNode("层叠冲突这一步完成后，解决了相同元素被声明了多条样式规则究竟应用哪一条样式规则的问题。 那么如果没有声明的属性呢？此时就使用默认值么？ "),
    /* @__PURE__ */ createBaseVNode("em", null, "No、No、No"),
    /* @__PURE__ */ createTextVNode("，别急，此时还有第三个步骤，那就是使用继承而来的值。")
  ])
], -1);
const _hoisted_27 = /* @__PURE__ */ createBaseVNode("p", null, "在上面的代码中，我们针对 div 设置了 color 属性值为红色，而针对 p 元素我们没有声明任何的属性，但是由于 color 是可以继承的，因此 p 元素从最近的 div 身上继承到了 color 属性的值。", -1);
const _hoisted_28 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("这里有两个点需要注意一下。 首先第一个是我强调了是 "),
  /* @__PURE__ */ createBaseVNode("code", null, "最近的"),
  /* @__PURE__ */ createTextVNode(" div 元素，看下面的例子：")
], -1);
const _hoisted_29 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("因为这里并不涉及到选中 p 元素声明 color 值，而是从父元素上面继承到 color 对应的值，因此这里是 "),
  /* @__PURE__ */ createBaseVNode("span", { class: "cor-wa" }, "谁近就听谁"),
  /* @__PURE__ */ createTextVNode(" 的，初学者往往会产生混淆，又去比较权重，但是这里根本不会涉及到权重比较，因为压根儿就没有选中到 p 元素。 第二个就是哪些属性能够继承？ 关于这一点的话，大家可以在 MDN 上面很轻松的查阅到。例如我们以 text-align 为例，如下图所示：")
], -1);
const _hoisted_30 = /* @__PURE__ */ createStaticVNode('<h2 id="使用默认值" tabindex="-1">使用默认值 <a class="header-anchor" href="#使用默认值" aria-label="Permalink to &quot;使用默认值&quot;">​</a></h2><blockquote><p>好了，目前走到这一步，如果属性值都还不能确定下来，那么就只能是使用默认值了。</p></blockquote><p>前面我们也说过，一个 HTML 元素要在浏览器中渲染出来，必须具备所有的 CSS 属性值，但是绝大部分我们是不会去设置的，用户代理样式表里面也不会去设置，也无法从继承拿到，因此最终都是用默认值。 好了，这就是关于 CSS 属性计算过程的所有知识了。</p><h2 id="一道面试题" tabindex="-1">一道面试题 <a class="header-anchor" href="#一道面试题" aria-label="Permalink to &quot;一道面试题&quot;">​</a></h2><blockquote><p>好了，学习了今天的内容，让我来用一道面试题测试测试大家的理解程度。 下面的代码，最终渲染出来的效果，a 元素是什么颜色？p 元素又是什么颜色？</p></blockquote><div class="language-html"><button title="Copy Code" class="copy"></button><span class="lang">html</span><pre class="shiki material-theme-palenight"><code><span class="line"><span style="color:#89DDFF;">&lt;</span><span style="color:#F07178;">style</span><span style="color:#89DDFF;">&gt;</span></span>\n<span class="line"><span style="color:#A6ACCD;">  </span><span style="color:#89DDFF;">.</span><span style="color:#FFCB6B;">test</span><span style="color:#A6ACCD;"> </span><span style="color:#89DDFF;">{</span></span>\n<span class="line"><span style="color:#A6ACCD;">    </span><span style="color:#B2CCD6;">color</span><span style="color:#89DDFF;">:</span><span style="color:#A6ACCD;"> skyblue</span><span style="color:#89DDFF;">;</span></span>\n<span class="line"><span style="color:#A6ACCD;">  </span><span style="color:#89DDFF;">}</span></span>\n<span class="line"><span style="color:#89DDFF;">&lt;/</span><span style="color:#F07178;">style</span><span style="color:#89DDFF;">&gt;</span></span>\n<span class="line"></span>\n<span class="line"><span style="color:#89DDFF;">&lt;</span><span style="color:#F07178;">body</span><span style="color:#89DDFF;">&gt;</span></span>\n<span class="line"><span style="color:#A6ACCD;">  </span><span style="color:#89DDFF;">&lt;</span><span style="color:#F07178;">div</span><span style="color:#89DDFF;"> </span><span style="color:#C792EA;">class</span><span style="color:#89DDFF;">=</span><span style="color:#89DDFF;">&quot;</span><span style="color:#C3E88D;">test</span><span style="color:#89DDFF;">&quot;</span><span style="color:#89DDFF;">&gt;</span></span>\n<span class="line"><span style="color:#A6ACCD;">    </span><span style="color:#89DDFF;">&lt;</span><span style="color:#F07178;">a</span><span style="color:#89DDFF;"> </span><span style="color:#C792EA;">href</span><span style="color:#89DDFF;">=</span><span style="color:#89DDFF;">&quot;</span><span style="color:#C3E88D;">baidu.com</span><span style="color:#89DDFF;">&quot;</span><span style="color:#89DDFF;">&gt;</span><span style="color:#A6ACCD;">这是个A</span><span style="color:#89DDFF;">&lt;/</span><span style="color:#F07178;">a</span><span style="color:#89DDFF;">&gt;</span></span>\n<span class="line"><span style="color:#A6ACCD;">    </span><span style="color:#89DDFF;">&lt;</span><span style="color:#F07178;">p</span><span style="color:#89DDFF;">&gt;</span><span style="color:#A6ACCD;">这是个P</span><span style="color:#89DDFF;">&lt;/</span><span style="color:#F07178;">p</span><span style="color:#89DDFF;">&gt;</span></span>\n<span class="line"><span style="color:#A6ACCD;">  </span><span style="color:#89DDFF;">&lt;/</span><span style="color:#F07178;">div</span><span style="color:#89DDFF;">&gt;</span></span>\n<span class="line"><span style="color:#89DDFF;">&lt;/</span><span style="color:#F07178;">body</span><span style="color:#89DDFF;">&gt;</span></span></code></pre></div><p>大家能说出为什么会呈现这样的结果么？</p><p>解答如下：</p>', 8);
const _hoisted_38 = /* @__PURE__ */ createBaseVNode("div", { class: "warning custom-block" }, [
  /* @__PURE__ */ createBaseVNode("p", { class: "custom-block-title" }, "答案解释"),
  /* @__PURE__ */ createBaseVNode("p", null, "实际上原因很简单，因为 a 元素在用户代理样式表中已经设置了 color 属性对应的值，因此会应用此声明值。而在 p 元素中无论是作者样式表还是用户代理样式表，都没有对此属性进行声明，然而由于 color 属性是可以继承的，因此最终 p 元素的 color 属性值通过继承来自于父元素。 你答对了么？-）")
], -1);
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_PicViewer = resolveComponent("PicViewer");
  return openBlock(), createElementBlock("div", null, [
    _hoisted_1,
    _hoisted_2,
    createVNode(_component_PicViewer, {
      title: "元素的所有属性",
      src: "/assets/css/computedStyle.jpg",
      alt: ""
    }),
    _hoisted_3,
    createVNode(_component_PicViewer, {
      title: "内置样式",
      src: "/assets/css/computedStyle-2.jpg",
      alt: ""
    }),
    _hoisted_10,
    createVNode(_component_PicViewer, {
      title: "作者样式表",
      src: "/assets/css/computedStyle-3.jpg",
      alt: ""
    }),
    _hoisted_16,
    createVNode(_component_PicViewer, {
      title: "比较优先级",
      src: "/assets/css/computedStyle-4.jpg",
      alt: ""
    }),
    _hoisted_20,
    createVNode(_component_PicViewer, {
      title: "比较次序",
      src: "/assets/css/computedStyle-5.jpg",
      alt: ""
    }),
    _hoisted_24,
    _hoisted_25,
    _hoisted_26,
    _hoisted_27,
    createVNode(_component_PicViewer, {
      title: "属性继承",
      src: "/assets/css/computedStyle-6.jpg",
      alt: ""
    }),
    _hoisted_28,
    createVNode(_component_PicViewer, {
      title: "最近的",
      src: "/assets/css/computedStyle-7.jpg",
      alt: ""
    }),
    _hoisted_29,
    createVNode(_component_PicViewer, {
      title: "是不是继承的",
      src: "/assets/css/computedStyle-8.jpg",
      alt: ""
    }),
    _hoisted_30,
    createVNode(_component_PicViewer, {
      title: "答案",
      src: "/assets/css/computedStyle-9.jpg",
      alt: ""
    }),
    _hoisted_38
  ]);
}
const attrCalcProcess = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  attrCalcProcess as default
};
