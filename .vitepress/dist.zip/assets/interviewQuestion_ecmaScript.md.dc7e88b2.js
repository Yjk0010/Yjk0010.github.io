import { _ as _export_sfc, c as createElementBlock, o as openBlock, V as createStaticVNode } from "./chunks/framework.2dcfa116.js";
const __pageData = JSON.parse('{"title":"ECMASCRIPT 面试题","description":"","frontmatter":{},"headers":[],"relativePath":"interviewQuestion/ecmaScript.md","filePath":"interviewQuestion/ecmaScript.md"}');
const _sfc_main = { name: "interviewQuestion/ecmaScript.md" };
const _hoisted_1 = /* @__PURE__ */ createStaticVNode('<h1 id="ecmascript-面试题" tabindex="-1">ECMASCRIPT 面试题 <a class="header-anchor" href="#ecmascript-面试题" aria-label="Permalink to &quot;ECMASCRIPT 面试题&quot;">​</a></h1><h1 id="传送门" tabindex="-1">传送门 <a class="header-anchor" href="#传送门" aria-label="Permalink to &quot;传送门&quot;">​</a></h1><h3 id="js-的数据类型" tabindex="-1"><a href="/js/base/dataType.html">JS 的数据类型</a> <a class="header-anchor" href="#js-的数据类型" aria-label="Permalink to &quot;[JS 的数据类型](/js/base/dataType)&quot;">​</a></h3><h3 id="null-和-undefined-区别" tabindex="-1"><a href="/js/base/littleCase.html#null-和-undefined-区别">null 和 undefined 区别</a> <a class="header-anchor" href="#null-和-undefined-区别" aria-label="Permalink to &quot;[null 和 undefined 区别](/js/base/littleCase#null-和-undefined-区别)&quot;">​</a></h3><h3 id="tofixed-不准-解决方案" tabindex="-1"><a href="/js/advancedWay/toFixed.html">toFixed 不准 解决方案</a> <a class="header-anchor" href="#tofixed-不准-解决方案" aria-label="Permalink to &quot;[toFixed 不准 解决方案](/js/advancedWay/toFixed)&quot;">​</a></h3><h3 id="防抖节流" tabindex="-1"><a href="/js/advancedWay/debAndThr.html">防抖节流</a> <a class="header-anchor" href="#防抖节流" aria-label="Permalink to &quot;[防抖节流](/js/advancedWay/debAndThr)&quot;">​</a></h3>', 6);
const _hoisted_7 = [
  _hoisted_1
];
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, _hoisted_7);
}
const ecmaScript = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  ecmaScript as default
};
