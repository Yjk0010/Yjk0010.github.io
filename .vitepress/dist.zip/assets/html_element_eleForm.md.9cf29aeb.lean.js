import { _ as _export_sfc, c as createElementBlock, o as openBlock, V as createStaticVNode } from "./chunks/framework.2dcfa116.js";
const eleForm_md_vue_type_style_index_0_lang = "";
const __pageData = JSON.parse('{"title":"表单元素","description":"","frontmatter":{},"headers":[],"relativePath":"html/element/eleForm.md","filePath":"html/element/eleForm.md"}');
const _sfc_main = { name: "html/element/eleForm.md" };
const _hoisted_1 = /* @__PURE__ */ createStaticVNode("", 53);
const _hoisted_54 = [
  _hoisted_1
];
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, _hoisted_54);
}
const eleForm = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  eleForm as default
};
