import { _ as _export_sfc, c as createElementBlock, o as openBlock, V as createStaticVNode, k as createBaseVNode } from "./chunks/framework.2dcfa116.js";
const __pageData = JSON.parse('{"title":"iframe 元素","description":"","frontmatter":{},"headers":[],"relativePath":"html/element/eleIframe.md","filePath":"html/element/eleIframe.md"}');
const _sfc_main = { name: "html/element/eleIframe.md" };
const _hoisted_1 = /* @__PURE__ */ createStaticVNode("", 5);
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("iframe", {
  src: "//player.bilibili.com/player.html?aid=2871480&bvid=BV1Ts411U7wt&cid=4486145&page=1",
  scrolling: "no",
  border: "0",
  frameborder: "no",
  framespacing: "0",
  allowfullscreen: "true"
}, null, -1);
const _hoisted_7 = /* @__PURE__ */ createStaticVNode("", 1);
const _hoisted_8 = [
  _hoisted_1,
  _hoisted_6,
  _hoisted_7
];
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, _hoisted_8);
}
const eleIframe = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  eleIframe as default
};
