var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => {
  __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
  return value;
};
import { g as getRandomNum, d as diffDate } from "./chunks/index.a789eca0.js";
import { d as defineComponent, h as ref, j as onMounted, o as openBlock, c as createElementBlock, k as createBaseVNode, _ as _export_sfc, u as useData, g as computed, I as Fragment, J as renderList, n as normalizeClass, t as toDisplayString, l as unref, p as pushScopeId, m as popScopeId, L as createVNode, w as withCtx, a as createTextVNode, G as onUnmounted, e as createCommentVNode, a7 as withDirectives, V as createStaticVNode } from "./chunks/framework.2dcfa116.js";
import { l as lib } from "./chunks/base.36303bf0.js";
import "./chunks/button.fdf0e29d.js";
import "./chunks/loading.369786e8.js";
const _hoisted_1$4 = { class: "content" };
const _sfc_main$4 = /* @__PURE__ */ defineComponent({
  __name: "index",
  setup(__props) {
    const canvasRef = ref();
    onMounted(() => {
      if (!canvasRef.value) {
        return;
      }
      const getText = () => {
        return (/* @__PURE__ */ new Date()).toTimeString().substring(0, 8);
      };
      const canvas = canvasRef.value;
      const ctx = canvas.getContext("2d", {
        // 频繁访问像素点优化配置
        willReadFrequently: true
      });
      const initCanvasSize = () => {
        canvas.width = 650 * devicePixelRatio;
        canvas.height = 650 * devicePixelRatio;
      };
      class Particle {
        constructor() {
          __publicField(this, "x");
          __publicField(this, "y");
          __publicField(this, "size");
          __publicField(this, "duration");
          const r = Math.min(canvas.width, canvas.height) / 2 - 10;
          const cx = canvas.width / 2;
          const cy = canvas.height / 2;
          const rad = getRandomNum(0, 360) * Math.PI / 180;
          this.x = cx + r * Math.cos(rad);
          this.y = cy + r * Math.sin(rad);
          this.size = getRandomNum(2 * devicePixelRatio, 7 * devicePixelRatio);
          this.duration = 500;
        }
        // 画粒子
        draw() {
          if (ctx) {
            ctx.beginPath();
            ctx.fillStyle = "rgba(200, 200, 200, .3)";
            ctx.arc(this.x, this.y, this.size, 0, 2 * Math.PI);
            ctx.fill();
          }
        }
        // 移动粒子
        moveTo(tx, ty) {
          const sx = this.x;
          const sy = this.y;
          const xSpeed = (tx - sx) / this.duration;
          const ySpeed = (ty - sy) / this.duration;
          const startTime = Date.now();
          const _move = () => {
            const t = Date.now() - startTime;
            this.x = sx + xSpeed * t;
            this.y = sy + ySpeed * t;
            if (t > this.duration) {
              this.x = tx;
              this.y = ty;
              return;
            }
            requestAnimationFrame(_move);
          };
          _move();
        }
      }
      const particles = [];
      let text = "";
      const clear = () => {
        ctx == null ? void 0 : ctx.clearRect(0, 0, canvas.width, canvas.height);
      };
      const getPoints = () => {
        if (ctx) {
          const { width, height, data } = ctx.getImageData(
            0,
            0,
            canvas.width,
            canvas.height
          );
          const points = [];
          const gap = 4;
          for (let i = 0; i < width; i += gap) {
            for (let j = 0; j < height; j += gap) {
              const index = (i + j * width) * 4;
              const r = data[index];
              const g = data[index + 1];
              const b = data[index + 2];
              const a = data[index + 3];
              if (r === 0 && g === 0 && b === 0 && a === 255) {
                points.push([i, j]);
              }
            }
          }
          return points;
        }
      };
      const update = () => {
        const newText = getText();
        if (text !== newText) {
          clear();
          text = newText;
          if (ctx) {
            ctx.fillStyle = "#000";
            ctx.textBaseline = "middle";
            ctx.font = `${120 * devicePixelRatio}px DingTalkJinBuTi,sans-serif`;
            ctx.fillText(
              text,
              (canvas.width - ctx.measureText(text).width) / 2,
              canvas.height / 2
            );
            const points = getPoints();
            if (!(points == null ? void 0 : points.length))
              return;
            clear();
            for (let i = 0; i < (points == null ? void 0 : points.length); i++) {
              let p = particles[i];
              if (!p) {
                p = new Particle();
                particles.push(p);
              }
              const [x, y] = points[i];
              p.moveTo(x, y);
            }
            if ((points == null ? void 0 : points.length) < particles.length) {
              particles.splice(points.length);
            }
          }
        }
      };
      const draw = () => {
        clear();
        update();
        particles.forEach((p) => {
          p.draw();
        });
        requestAnimationFrame(draw);
      };
      if (!particles.length) {
        initCanvasSize();
        draw();
        console.log("启动");
      }
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$4, [
        createBaseVNode("canvas", {
          class: "canvas",
          ref_key: "canvasRef",
          ref: canvasRef
        }, null, 512)
      ]);
    };
  }
});
const index_vue_vue_type_style_index_0_scoped_5266e649_lang = "";
const demo = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["__scopeId", "data-v-5266e649"]]);
const _withScopeId$1 = (n) => (pushScopeId("data-v-aa5a3e8e"), n = n(), popScopeId(), n);
const _hoisted_1$3 = { class: "up" };
const _hoisted_2$2 = /* @__PURE__ */ _withScopeId$1(() => /* @__PURE__ */ createBaseVNode("div", { class: "shadow" }, null, -1));
const _hoisted_3$2 = { class: "number" };
const _hoisted_4$1 = { class: "down" };
const _hoisted_5$1 = /* @__PURE__ */ _withScopeId$1(() => /* @__PURE__ */ createBaseVNode("div", { class: "shadow" }, null, -1));
const _hoisted_6$2 = { class: "number" };
const _sfc_main$3 = /* @__PURE__ */ defineComponent({
  __name: "flipCard",
  props: {
    total: { default: 9 },
    current: { default: 0 },
    countdown: { type: Boolean, default: false }
  },
  setup(__props) {
    const props = __props;
    const { isDark } = useData();
    const active = computed(() => {
      if (props.countdown) {
        return props.current < 0 ? 0 : props.current;
      } else {
        return props.current > props.total ? props.total : props.current;
      }
    });
    const before = computed(() => {
      if (props.countdown) {
        return active.value < props.total ? active.value + 1 : 0;
      } else {
        return active.value ? active.value - 1 : props.total;
      }
    });
    const totalList = computed(() => {
      const list = Array.from({ length: props.total + 1 }, (_, i) => i);
      return props.countdown ? list.reverse() : list;
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("ul", {
        class: normalizeClass(["flip-card", { dark: unref(isDark) }])
      }, [
        (openBlock(true), createElementBlock(Fragment, null, renderList(totalList.value, (item, key) => {
          return openBlock(), createElementBlock("li", {
            class: normalizeClass(["item", { active: active.value === item, before: item === before.value }]),
            key: item
          }, [
            createBaseVNode("div", _hoisted_1$3, [
              _hoisted_2$2,
              createBaseVNode("div", _hoisted_3$2, toDisplayString(item), 1)
            ]),
            createBaseVNode("div", _hoisted_4$1, [
              _hoisted_5$1,
              createBaseVNode("div", _hoisted_6$2, toDisplayString(item), 1)
            ])
          ], 2);
        }), 128))
      ], 2);
    };
  }
});
const flipCard_vue_vue_type_style_index_0_scoped_aa5a3e8e_lang = "";
const flipCard = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["__scopeId", "data-v-aa5a3e8e"]]);
const _hoisted_1$2 = { class: "cardTest" };
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "cardTest",
  setup(__props) {
    const refCount = ref(0);
    const refCount2 = ref(8);
    const countChange = () => {
      if (refCount.value === 8) {
        refCount.value = 0;
      } else {
        refCount.value++;
      }
    };
    const countChange2 = () => {
      if (refCount2.value === 0) {
        refCount2.value = 8;
      } else {
        refCount2.value--;
      }
    };
    return (_ctx, _cache) => {
      const _component_el_button = lib.ElButton;
      return openBlock(), createElementBlock("div", _hoisted_1$2, [
        createVNode(_component_el_button, { onClick: countChange }, {
          default: withCtx(() => [
            createTextVNode("加一下")
          ]),
          _: 1
        }),
        createVNode(flipCard, {
          total: 8,
          current: refCount.value
        }, null, 8, ["current"]),
        createVNode(flipCard, {
          total: 8,
          current: refCount2.value,
          countdown: ""
        }, null, 8, ["current"]),
        createVNode(_component_el_button, { onClick: countChange2 }, {
          default: withCtx(() => [
            createTextVNode("减一下")
          ]),
          _: 1
        })
      ]);
    };
  }
});
const cardTest_vue_vue_type_style_index_0_scoped_80722339_lang = "";
const cardTest = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["__scopeId", "data-v-80722339"]]);
const getFestival = async (year) => {
  return new Promise((resolve, reject) => {
    fetch(
      `https://www.mxnzp.com/api/holiday/list/year/${year}/festival?app_id=xjrlpumueaxukyov&app_secret=Q2FoMFNub0FndmtJUGRUUElIWTRLQT09`,
      {
        method: "GET",
        headers: {
          "Content-Type": "application/json"
        }
      }
    ).then((response) => response.json()).then((res) => {
      const { code, data, msg } = res || {};
      if (code === 1) {
        resolve(data);
      } else {
        reject({ msg });
      }
    }).catch((err) => {
      reject({ err });
    });
  });
};
const _withScopeId = (n) => (pushScopeId("data-v-559ec89c"), n = n(), popScopeId(), n);
const _hoisted_1$1 = { class: "festivalCountdown" };
const _hoisted_2$1 = {
  key: 0,
  class: "title cor-tip"
};
const _hoisted_3$1 = { class: "cor-da" };
const _hoisted_4 = { class: "title cor-tip" };
const _hoisted_5 = { class: "cor-da" };
const _hoisted_6$1 = { class: "show-clock" };
const _hoisted_7 = { class: "day" };
const _hoisted_8$1 = /* @__PURE__ */ _withScopeId(() => /* @__PURE__ */ createBaseVNode("div", { class: "time-text" }, "天", -1));
const _hoisted_9 = { class: "clock" };
const _hoisted_10 = /* @__PURE__ */ _withScopeId(() => /* @__PURE__ */ createBaseVNode("div", { class: "time-text" }, ":", -1));
const _hoisted_11 = /* @__PURE__ */ _withScopeId(() => /* @__PURE__ */ createBaseVNode("div", { class: "time-text" }, ":", -1));
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "festivalCountdown",
  setup(__props) {
    const festivalText = ref("");
    const nowFestivalText = ref("");
    const loading = ref(false);
    const diffDayList = ref([0, 0, 0]);
    const diffTimeList = ref([0, 0, 0, 0, 0, 0]);
    let onLineTime = 0;
    const getRecentlyFestival = () => {
      loading.value = true;
      const nowDate = /* @__PURE__ */ new Date();
      getFestival(nowDate.getFullYear()).then((data) => {
        const festivalList = data.reduce((prev, month) => {
          return [...prev, ...month.days];
        }, []).filter((item) => {
          return diffDate(nowDate, new Date(item.date)).days <= 0;
        });
        let endDate;
        if (festivalList.length === 0) {
          endDate = /* @__PURE__ */ new Date(`${nowDate.getFullYear() + 1}-01-01`);
          festivalText.value = "元旦";
        } else {
          const firstFestival = festivalList[0];
          if (diffDate(nowDate, new Date(firstFestival.date)).days === 0) {
            const nowDes = firstFestival.typeDes;
            nowFestivalText.value = nowDes;
            for (let index = 1; index < festivalList.length; index++) {
              const element = festivalList[index];
              if (element.typeDes !== nowDes) {
                endDate = new Date(element.date);
                festivalText.value = element.typeDes;
                break;
              }
            }
            if (!endDate) {
              endDate = /* @__PURE__ */ new Date(`${nowDate.getFullYear() + 1}-01-01`);
              festivalText.value = "元旦";
            }
          } else {
            endDate = new Date(firstFestival.date);
            festivalText.value = firstFestival.typeDes;
          }
        }
        const diffDay = Math.abs(diffDate(nowDate, endDate).days) - 1;
        const diffDayStr = diffDay.toString();
        let diffDayStrLength = diffDayStr.length;
        for (let len = 3; len--; ) {
          diffDayList.value[len] = +diffDayStr[--diffDayStrLength] || 0;
        }
      }).catch(() => {
        onLineTime++;
        if (onLineTime < 4) {
          setTimeout(getRecentlyFestival, 1e3);
        }
      }).finally(() => {
        loading.value = false;
      });
    };
    const formatTime = (time) => {
      return time.toString().padStart(2, "0").split("").map((x) => +x);
    };
    const getTimeToEndDay = () => {
      const now = /* @__PURE__ */ new Date();
      const endDay = new Date(
        now.getFullYear(),
        now.getMonth(),
        now.getDate(),
        23,
        59,
        59
      ).getTime() + 1e3;
      const diffDay = endDay - now.getTime();
      const S = formatTime(Math.floor(diffDay / 1e3 % 60));
      const M = formatTime(Math.floor(diffDay / 1e3 / 60 % 60));
      const H = formatTime(Math.floor(diffDay / 1e3 / 60 / 60));
      diffTimeList.value = [...H, ...M, ...S];
    };
    let clock;
    onMounted(() => {
      getRecentlyFestival();
      clearInterval(clock);
      clock = setInterval(() => {
        getTimeToEndDay();
      }, 1e3);
    });
    onUnmounted(() => {
      clearInterval(clock);
    });
    return (_ctx, _cache) => {
      const _directive_loading = lib.ElLoadingDirective;
      return openBlock(), createElementBlock("div", _hoisted_1$1, [
        nowFestivalText.value ? (openBlock(), createElementBlock("div", _hoisted_2$1, [
          createTextVNode(" 现在正在 "),
          createBaseVNode("span", _hoisted_3$1, toDisplayString(nowFestivalText.value), 1),
          createTextVNode(" 小长假中 ")
        ])) : createCommentVNode("", true),
        createBaseVNode("div", _hoisted_4, [
          createTextVNode(" 距离下一个小长假 "),
          createBaseVNode("span", _hoisted_5, toDisplayString(festivalText.value), 1),
          createTextVNode(" 还有 ")
        ]),
        withDirectives((openBlock(), createElementBlock("div", _hoisted_6$1, [
          createBaseVNode("div", _hoisted_7, [
            createVNode(flipCard, {
              total: 9,
              current: diffDayList.value[0],
              countdown: ""
            }, null, 8, ["current"]),
            createVNode(flipCard, {
              total: 9,
              current: diffDayList.value[1],
              countdown: ""
            }, null, 8, ["current"]),
            createVNode(flipCard, {
              total: 9,
              current: diffDayList.value[2],
              countdown: ""
            }, null, 8, ["current"])
          ]),
          _hoisted_8$1,
          createBaseVNode("div", _hoisted_9, [
            createVNode(flipCard, {
              total: 2,
              current: diffTimeList.value[0],
              countdown: ""
            }, null, 8, ["current"]),
            createVNode(flipCard, {
              total: 9,
              current: diffTimeList.value[1],
              countdown: ""
            }, null, 8, ["current"]),
            _hoisted_10,
            createVNode(flipCard, {
              total: 5,
              current: diffTimeList.value[2],
              countdown: ""
            }, null, 8, ["current"]),
            createVNode(flipCard, {
              total: 9,
              current: diffTimeList.value[3],
              countdown: ""
            }, null, 8, ["current"]),
            _hoisted_11,
            createVNode(flipCard, {
              total: 5,
              current: diffTimeList.value[4],
              countdown: ""
            }, null, 8, ["current"]),
            createVNode(flipCard, {
              total: 9,
              current: diffTimeList.value[5],
              countdown: ""
            }, null, 8, ["current"])
          ])
        ])), [
          [_directive_loading, loading.value]
        ])
      ]);
    };
  }
});
const festivalCountdown_vue_vue_type_style_index_0_scoped_559ec89c_lang = "";
const festivalCountdown = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-559ec89c"]]);
const _hoisted_1 = /* @__PURE__ */ createBaseVNode("h1", {
  id: "卡片返转计时-粒子时钟",
  tabindex: "-1"
}, [
  /* @__PURE__ */ createTextVNode("卡片返转计时 + 粒子时钟 "),
  /* @__PURE__ */ createBaseVNode("a", {
    class: "header-anchor",
    href: "#卡片返转计时-粒子时钟",
    "aria-label": 'Permalink to "卡片返转计时 + 粒子时钟"'
  }, "​")
], -1);
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("h2", {
  id: "翻转卡片展示",
  tabindex: "-1"
}, [
  /* @__PURE__ */ createTextVNode("翻转卡片展示 "),
  /* @__PURE__ */ createBaseVNode("a", {
    class: "header-anchor",
    href: "#翻转卡片展示",
    "aria-label": 'Permalink to "翻转卡片展示"'
  }, "​")
], -1);
const _hoisted_3 = /* @__PURE__ */ createStaticVNode("", 3);
const _hoisted_6 = /* @__PURE__ */ createStaticVNode("", 2);
const _hoisted_8 = /* @__PURE__ */ createStaticVNode("", 2);
const __pageData = JSON.parse('{"title":"卡片返转计时 + 粒子时钟","description":"","frontmatter":{},"headers":[],"relativePath":"demo/particleClock/main.md","filePath":"demo/particleClock/main.md"}');
const __default__ = { name: "demo/particleClock/main.md" };
const _sfc_main = /* @__PURE__ */ Object.assign(__default__, {
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", null, [
        _hoisted_1,
        _hoisted_2,
        createVNode(cardTest),
        _hoisted_3,
        createVNode(festivalCountdown),
        _hoisted_6,
        createVNode(demo),
        _hoisted_8
      ]);
    };
  }
});
export {
  __pageData,
  _sfc_main as default
};
