import { _ as _export_sfc, H as resolveComponent, c as createElementBlock, k as createBaseVNode, a as createTextVNode, L as createVNode, w as withCtx, V as createStaticVNode, o as openBlock } from "./chunks/framework.2dcfa116.js";
const __pageData = JSON.parse('{"title":"toFixed 不准","description":"","frontmatter":{},"headers":[],"relativePath":"js/advancedWay/toFixed.md","filePath":"js/advancedWay/toFixed.md"}');
const _sfc_main = { name: "js/advancedWay/toFixed.md" };
const _hoisted_1 = /* @__PURE__ */ createStaticVNode("", 12);
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("p", null, "locales :"),
  /* @__PURE__ */ createBaseVNode("ul", null, [
    /* @__PURE__ */ createBaseVNode("li", null, [
      /* @__PURE__ */ createTextVNode("语言代码 "),
      /* @__PURE__ */ createBaseVNode("ul", null, [
        /* @__PURE__ */ createBaseVNode("li", null, [
          /* @__PURE__ */ createTextVNode("中国 -> "),
          /* @__PURE__ */ createBaseVNode("code", null, "zh")
        ]),
        /* @__PURE__ */ createBaseVNode("li", null, [
          /* @__PURE__ */ createTextVNode("英国 -> "),
          /* @__PURE__ */ createBaseVNode("code", null, "en")
        ])
      ])
    ])
  ])
], -1);
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("p", null, "options :", -1);
const _hoisted_15 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("code", null, "maximumFractionDigits"),
  /* @__PURE__ */ createTextVNode(" : 四舍五入最大位数")
], -1);
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("code", null, "minimumFractionDigits"),
  /* @__PURE__ */ createTextVNode(" : 四舍五入最小位数")
], -1);
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("code", null, "useGrouping", -1);
const _hoisted_18 = /* @__PURE__ */ createBaseVNode("code", null, ",", -1);
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("code", null, ".", -1);
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("code", null, null, -1);
const _hoisted_21 = /* @__PURE__ */ createBaseVNode("code", null, ' "auto"', -1);
const _hoisted_22 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("code", null, '"always"'),
  /* @__PURE__ */ createTextVNode(" 显示分组分隔符，即使语言环境不喜欢。")
], -1);
const _hoisted_23 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("code", null, "false"),
  /* @__PURE__ */ createTextVNode(" 不显示分隔符。")
], -1);
const _hoisted_24 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("code", null, "true"),
  /* @__PURE__ */ createTextVNode(" 同 "),
  /* @__PURE__ */ createBaseVNode("code", null, '"always"')
], -1);
const _hoisted_25 = /* @__PURE__ */ createBaseVNode("code", null, "style", -1);
const _hoisted_26 = /* @__PURE__ */ createBaseVNode("code", null, '"decimal"', -1);
const _hoisted_27 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("code", null, '"currency"'),
  /* @__PURE__ */ createTextVNode(" 用于货币格式 需要配置")
], -1);
const _hoisted_28 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("code", null, '"percent"'),
  /* @__PURE__ */ createTextVNode(" 用于百分比格式")
], -1);
const _hoisted_29 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("code", null, '"unit"'),
  /* @__PURE__ */ createTextVNode(" 用于货币格式")
], -1);
const _hoisted_30 = /* @__PURE__ */ createStaticVNode("", 2);
const _hoisted_32 = /* @__PURE__ */ createStaticVNode("", 4);
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_Badge = resolveComponent("Badge");
  return openBlock(), createElementBlock("div", null, [
    _hoisted_1,
    createBaseVNode("ul", null, [
      _hoisted_13,
      createBaseVNode("li", null, [
        _hoisted_14,
        createBaseVNode("ol", null, [
          _hoisted_15,
          _hoisted_16,
          createBaseVNode("li", null, [
            _hoisted_17,
            createTextVNode(" : 分组符号 根据语言来的大多数是 "),
            _hoisted_18,
            createTextVNode("、"),
            _hoisted_19,
            createTextVNode("和 "),
            _hoisted_20,
            createBaseVNode("ol", null, [
              createBaseVNode("li", null, [
                createVNode(_component_Badge, { type: "tip" }, {
                  default: withCtx(() => [
                    createTextVNode("default")
                  ]),
                  _: 1
                }),
                _hoisted_21,
                createTextVNode(" 根据区域设置偏好显示分组分隔符，这也可能取决于货币。")
              ]),
              _hoisted_22,
              _hoisted_23,
              _hoisted_24
            ])
          ]),
          createBaseVNode("li", null, [
            _hoisted_25,
            createTextVNode(" 格式化样式 "),
            createBaseVNode("ol", null, [
              createBaseVNode("li", null, [
                createVNode(_component_Badge, { type: "tip" }, {
                  default: withCtx(() => [
                    createTextVNode("default")
                  ]),
                  _: 1
                }),
                createTextVNode(),
                _hoisted_26,
                createTextVNode(" 用于纯数字格式")
              ]),
              _hoisted_27,
              _hoisted_28,
              _hoisted_29
            ])
          ]),
          _hoisted_30
        ])
      ])
    ]),
    _hoisted_32
  ]);
}
const toFixed = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  toFixed as default
};
