import { _ as _export_sfc, H as resolveComponent, c as createElementBlock, L as createVNode, k as createBaseVNode, a as createTextVNode, V as createStaticVNode, o as openBlock } from "./chunks/framework.2dcfa116.js";
const __pageData = JSON.parse('{"title":"CSS 属性计算过程","description":"","frontmatter":{},"headers":[],"relativePath":"css/attr/attrCalcProcess.md","filePath":"css/attr/attrCalcProcess.md"}');
const _sfc_main = { name: "css/attr/attrCalcProcess.md" };
const _hoisted_1 = /* @__PURE__ */ createBaseVNode("h1", {
  id: "css-属性计算过程",
  tabindex: "-1"
}, [
  /* @__PURE__ */ createTextVNode("CSS 属性计算过程 "),
  /* @__PURE__ */ createBaseVNode("a", {
    class: "header-anchor",
    href: "#css-属性计算过程",
    "aria-label": 'Permalink to "CSS 属性计算过程"'
  }, "​")
], -1);
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("blockquote", null, [
  /* @__PURE__ */ createBaseVNode("p", null, "我们所书写的任何一个 HTML 元素，实际上都有完整的一整套 CSS 样式"),
  /* @__PURE__ */ createBaseVNode("p", null, [
    /* @__PURE__ */ createTextVNode("这个可以从这边 chrome 控制台 element 随便选中一个元素 标签右边点击 "),
    /* @__PURE__ */ createBaseVNode("span", { class: "cor-tip" }, "computed")
  ]),
  /* @__PURE__ */ createBaseVNode("p", null, [
    /* @__PURE__ */ createTextVNode("选中 "),
    /* @__PURE__ */ createBaseVNode("code", null, "show all"),
    /* @__PURE__ */ createTextVNode(" 可以看到所有的计算好的属性")
  ])
], -1);
const _hoisted_3 = /* @__PURE__ */ createStaticVNode("", 7);
const _hoisted_10 = /* @__PURE__ */ createStaticVNode("", 6);
const _hoisted_16 = /* @__PURE__ */ createStaticVNode("", 4);
const _hoisted_20 = /* @__PURE__ */ createStaticVNode("", 4);
const _hoisted_24 = /* @__PURE__ */ createBaseVNode("p", null, "至此，样式声明中存在冲突的所有情况，就全部被解决了。", -1);
const _hoisted_25 = /* @__PURE__ */ createBaseVNode("h2", {
  id: "使用继承",
  tabindex: "-1"
}, [
  /* @__PURE__ */ createTextVNode("使用继承 "),
  /* @__PURE__ */ createBaseVNode("a", {
    class: "header-anchor",
    href: "#使用继承",
    "aria-label": 'Permalink to "使用继承"'
  }, "​")
], -1);
const _hoisted_26 = /* @__PURE__ */ createBaseVNode("blockquote", null, [
  /* @__PURE__ */ createBaseVNode("p", null, [
    /* @__PURE__ */ createTextVNode("层叠冲突这一步完成后，解决了相同元素被声明了多条样式规则究竟应用哪一条样式规则的问题。 那么如果没有声明的属性呢？此时就使用默认值么？ "),
    /* @__PURE__ */ createBaseVNode("em", null, "No、No、No"),
    /* @__PURE__ */ createTextVNode("，别急，此时还有第三个步骤，那就是使用继承而来的值。")
  ])
], -1);
const _hoisted_27 = /* @__PURE__ */ createBaseVNode("p", null, "在上面的代码中，我们针对 div 设置了 color 属性值为红色，而针对 p 元素我们没有声明任何的属性，但是由于 color 是可以继承的，因此 p 元素从最近的 div 身上继承到了 color 属性的值。", -1);
const _hoisted_28 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("这里有两个点需要注意一下。 首先第一个是我强调了是 "),
  /* @__PURE__ */ createBaseVNode("code", null, "最近的"),
  /* @__PURE__ */ createTextVNode(" div 元素，看下面的例子：")
], -1);
const _hoisted_29 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("因为这里并不涉及到选中 p 元素声明 color 值，而是从父元素上面继承到 color 对应的值，因此这里是 "),
  /* @__PURE__ */ createBaseVNode("span", { class: "cor-wa" }, "谁近就听谁"),
  /* @__PURE__ */ createTextVNode(" 的，初学者往往会产生混淆，又去比较权重，但是这里根本不会涉及到权重比较，因为压根儿就没有选中到 p 元素。 第二个就是哪些属性能够继承？ 关于这一点的话，大家可以在 MDN 上面很轻松的查阅到。例如我们以 text-align 为例，如下图所示：")
], -1);
const _hoisted_30 = /* @__PURE__ */ createStaticVNode("", 8);
const _hoisted_38 = /* @__PURE__ */ createBaseVNode("div", { class: "warning custom-block" }, [
  /* @__PURE__ */ createBaseVNode("p", { class: "custom-block-title" }, "答案解释"),
  /* @__PURE__ */ createBaseVNode("p", null, "实际上原因很简单，因为 a 元素在用户代理样式表中已经设置了 color 属性对应的值，因此会应用此声明值。而在 p 元素中无论是作者样式表还是用户代理样式表，都没有对此属性进行声明，然而由于 color 属性是可以继承的，因此最终 p 元素的 color 属性值通过继承来自于父元素。 你答对了么？-）")
], -1);
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_PicViewer = resolveComponent("PicViewer");
  return openBlock(), createElementBlock("div", null, [
    _hoisted_1,
    _hoisted_2,
    createVNode(_component_PicViewer, {
      title: "元素的所有属性",
      src: "/assets/css/computedStyle.jpg",
      alt: ""
    }),
    _hoisted_3,
    createVNode(_component_PicViewer, {
      title: "内置样式",
      src: "/assets/css/computedStyle-2.jpg",
      alt: ""
    }),
    _hoisted_10,
    createVNode(_component_PicViewer, {
      title: "作者样式表",
      src: "/assets/css/computedStyle-3.jpg",
      alt: ""
    }),
    _hoisted_16,
    createVNode(_component_PicViewer, {
      title: "比较优先级",
      src: "/assets/css/computedStyle-4.jpg",
      alt: ""
    }),
    _hoisted_20,
    createVNode(_component_PicViewer, {
      title: "比较次序",
      src: "/assets/css/computedStyle-5.jpg",
      alt: ""
    }),
    _hoisted_24,
    _hoisted_25,
    _hoisted_26,
    _hoisted_27,
    createVNode(_component_PicViewer, {
      title: "属性继承",
      src: "/assets/css/computedStyle-6.jpg",
      alt: ""
    }),
    _hoisted_28,
    createVNode(_component_PicViewer, {
      title: "最近的",
      src: "/assets/css/computedStyle-7.jpg",
      alt: ""
    }),
    _hoisted_29,
    createVNode(_component_PicViewer, {
      title: "是不是继承的",
      src: "/assets/css/computedStyle-8.jpg",
      alt: ""
    }),
    _hoisted_30,
    createVNode(_component_PicViewer, {
      title: "答案",
      src: "/assets/css/computedStyle-9.jpg",
      alt: ""
    }),
    _hoisted_38
  ]);
}
const attrCalcProcess = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  attrCalcProcess as default
};
