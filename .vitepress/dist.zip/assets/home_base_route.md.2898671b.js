import { _ as _export_sfc, c as createElementBlock, o as openBlock, V as createStaticVNode } from "./chunks/framework.2dcfa116.js";
const __pageData = JSON.parse('{"title":"路径的写法","description":"","frontmatter":{},"headers":[],"relativePath":"home/base/route.md","filePath":"home/base/route.md"}');
const _sfc_main = { name: "home/base/route.md" };
const _hoisted_1 = /* @__PURE__ */ createStaticVNode('<h1 id="路径的写法" tabindex="-1">路径的写法 <a class="header-anchor" href="#路径的写法" aria-label="Permalink to &quot;路径的写法&quot;">​</a></h1><h2 id="站内资源和站外资源" tabindex="-1">站内资源和站外资源 <a class="header-anchor" href="#站内资源和站外资源" aria-label="Permalink to &quot;站内资源和站外资源&quot;">​</a></h2><ul><li><p>站内资源：当前网站的资源</p></li><li><p>站外资源：非当前网站的资源</p></li></ul><h2 id="绝对路径和相对路径" tabindex="-1">绝对路径和相对路径 <a class="header-anchor" href="#绝对路径和相对路径" aria-label="Permalink to &quot;绝对路径和相对路径&quot;">​</a></h2><p>推荐写法</p><ul><li><p>站外资源：绝对路径</p></li><li><p>站内资源：相对路径</p></li></ul><h2 id="绝对路径" tabindex="-1">绝对路径 <a class="header-anchor" href="#绝对路径" aria-label="Permalink to &quot;绝对路径&quot;">​</a></h2><blockquote><p>绝对路径 可以理解成绝对地址</p></blockquote><p>url 地址：</p><div class="language-md"><button title="Copy Code" class="copy"></button><span class="lang">md</span><pre class="shiki material-theme-palenight"><code><span class="line"><span style="color:#A6ACCD;">协议名://主机名:端口号/路径</span></span>\n<span class="line"></span>\n<span class="line"><span style="color:#A6ACCD;">schema://host:port/path</span></span></code></pre></div><p>当跳转目标和当前页面的协议相同时，可以省略协议</p><h2 id="相对路径" tabindex="-1">相对路径 <a class="header-anchor" href="#相对路径" aria-label="Permalink to &quot;相对路径&quot;">​</a></h2><blockquote><p>相对路径是相对于当前文件位置的</p></blockquote><p>以<code>./</code>开头，<code>./</code>表示当前资源所在的目录</p><p>可以书写<code>../</code>表示返回上一级目录</p><p>相对路径中：<code>./</code>可以省略</p>', 16);
const _hoisted_17 = [
  _hoisted_1
];
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, _hoisted_17);
}
const route = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  route as default
};
