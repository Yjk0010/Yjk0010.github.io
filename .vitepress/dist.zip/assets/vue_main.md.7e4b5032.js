import { _ as _export_sfc, c as createElementBlock, o as openBlock, V as createStaticVNode } from "./chunks/framework.2dcfa116.js";
const __pageData = JSON.parse('{"title":"VUE","description":"","frontmatter":{},"headers":[],"relativePath":"vue/main.md","filePath":"vue/main.md"}');
const _sfc_main = { name: "vue/main.md" };
const _hoisted_1 = /* @__PURE__ */ createStaticVNode('<h1 id="vue" tabindex="-1">VUE <a class="header-anchor" href="#vue" aria-label="Permalink to &quot;VUE&quot;">​</a></h1><h2 id="简单介绍" tabindex="-1">简单介绍 <a class="header-anchor" href="#简单介绍" aria-label="Permalink to &quot;简单介绍&quot;">​</a></h2><p><span class="cor-tip">Vue.js</span>是一款非常流行的 <strong>JavaScript</strong> 前端框架,具有以下关键特点:</p><ol><li>采用组件化模型,增加代码复用性</li></ol><p>在<span class="cor-tip">Vue</span>中可以将页面拆分成不同的组件,每个组件是可复用的,这样可以大大提高开发效率。</p><ol start="2"><li>双向数据绑定</li></ol><p><span class="cor-tip">Vue</span>实现了<span class="cor-tip">MVVM</span>模型,可以通过简单的语法双向绑定 <strong>DOM</strong> 和数据。不需要手动操作 <strong>DOM</strong>,非常简洁。</p><ol start="3"><li>虚拟 DOM 和高效灵活的视图层</li></ol><p><span class="cor-tip">Vue</span>使用虚拟 <strong>DOM</strong> 实现高效的 <strong>DOM diff</strong> 算法,可以快速响应数据变化。同时提供模板、JSX 等灵活的视图层选项。</p><ol start="4"><li>组合式 <strong>API</strong></li></ol><p><span class="cor-tip">Vue3</span>提供了组合式 <strong>API</strong>,可以更灵活地组织逻辑复用代码。</p><ol start="5"><li>良好的生态系统</li></ol><p><span class="cor-tip">Vue</span>拥有强大的官方生态,包括<span class="cor-tip">Vue CLI</span>、<span class="cor-tip">Vue Router</span>、<span class="cor-tip">Vuex</span>状态管理等。</p><ol start="6"><li>轻量且高性能</li></ol><p><span class="cor-tip">Vue</span>非常轻量,压缩后只有 20 多 kb。同时运行效率很高。</p><p>总之,<span class="cor-tip">Vue</span>是一个易用、灵活且高效的前端框架,可以快速构建界面丰富的单页应用。它非常适合快速开发项目。</p><p>##<span class="cor-da">尤大大镇楼</span><a href="https://twitter.com/youyuxi" target="_blank" rel="noreferrer">twitter</a> <a href="https://github.com/yyx990803" target="_blank" rel="noreferrer">github</a></p>', 17);
const _hoisted_18 = [
  _hoisted_1
];
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, _hoisted_18);
}
const main = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  main as default
};
