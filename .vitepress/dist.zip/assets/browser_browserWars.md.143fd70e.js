import { _ as _export_sfc, H as resolveComponent, c as createElementBlock, k as createBaseVNode, a as createTextVNode, L as createVNode, w as withCtx, V as createStaticVNode, o as openBlock } from "./chunks/framework.2dcfa116.js";
const __pageData = JSON.parse('{"title":"浏览器大战","description":"","frontmatter":{},"headers":[],"relativePath":"browser/browserWars.md","filePath":"browser/browserWars.md"}');
const _sfc_main = { name: "browser/browserWars.md" };
const _hoisted_1 = /* @__PURE__ */ createBaseVNode("h1", {
  id: "浏览器大战",
  tabindex: "-1"
}, [
  /* @__PURE__ */ createTextVNode("浏览器大战 "),
  /* @__PURE__ */ createBaseVNode("a", {
    class: "header-anchor",
    href: "#浏览器大战",
    "aria-label": 'Permalink to "浏览器大战"'
  }, "​")
], -1);
const _hoisted_2 = {
  id: "www-的诞生-老祖宗",
  tabindex: "-1"
};
const _hoisted_3 = /* @__PURE__ */ createBaseVNode("a", {
  class: "header-anchor",
  href: "#www-的诞生-老祖宗",
  "aria-label": 'Permalink to "WWW 的诞生 <Badge type="tip">老祖宗</Badge>"'
}, "​", -1);
const _hoisted_4 = /* @__PURE__ */ createStaticVNode('<p><span class="cor-wa">1989 年</span> 仲夏之夜, <span class="cor-da">伯纳斯-李</span> 成功开发出世界上第一个<code>Web 服务器</code>和第一个 <code>Web 客户机</code>。</p><blockquote><p>虽然这个 Web 服务器简陋得只能说是 CERN 的电话号码簿, 它只是允许用户进入主机以查询每个研究人员的电话号码, 但它实实在在是一个所见即所得的超文本浏览编辑器。</p></blockquote><p><span class="cor-wa">1989 年 12 月</span> , <span class="cor-da">伯纳斯-李</span> 为他的发明正式定名为 <code>World Wide Web</code>, 即我们熟悉的 <code>WWW</code>。</p><p><span class="cor-wa">1991 年 5 月</span> , <code>WWW</code> 在 <code>Internet</code> 上首次露面, 立即引起轰动, 获得了极大的成功被广泛推广应用。</p>', 4);
const _hoisted_8 = {
  id: "第一次浏览器大战-微软-对-网景",
  tabindex: "-1"
};
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("a", {
  class: "header-anchor",
  href: "#第一次浏览器大战-微软-对-网景",
  "aria-label": 'Permalink to "第一次浏览器大战 <Badge type="tip">微软 对 网景</Badge>"'
}, "​", -1);
const _hoisted_10 = /* @__PURE__ */ createStaticVNode('<p><span class="cor-wa">1994 年</span> 网景 <code>Netscape Communication Corperation</code>, 推出第一款商用浏览器, 网景 浏览器<code>Netscape Navigator</code>.</p><p><span class="cor-wa">1995 年</span> 网景 公司打算在浏览器中加入网络操作系统, 影响到 微软 的利益, 引起了 微软 的注意<br> 同年, 微软 发布 <code>IE</code> 浏览器。<br> 之后 网景 在 <code>Navigator</code> 中搭载了第一款浏览器执行语言 <code>JavaScript</code> <a href="/js/main.html">JavaScript 发展</a><br><code>JavaScript</code> 语言推出之后, 网景 获得极大的竞争优势。<br> 微软 对 <code>JavaScript</code> 语言反编译, 借鉴 <code>JavaScript</code> 语言, 推出了 <code>JScript、VBScript</code></p><p><span class="cor-wa">1997 年</span> 第一次浏览器大战爆发<br> 网景 公司将 <code>javascript1.1</code> 版本提交给 <code>ECMA</code> (欧洲计算机制造协会) 想通过协会限制 <code>IE</code></p><div class="tip custom-block"><p class="custom-block-title">ES</p><p>ECMA 收录了 JavaScript, 并提交给 ISO, 成为了第一个 JS 的标准版本, 成为 <a href="/js/main.html">ECMAScript</a>, 简称 ES</p></div><p>然后 微软 放出大招将 <code>IE3</code> 发布, 并绑定 <code>windows</code> 操作系统。<br> 随着 微软 公司捆绑在 <code>Windows</code> 操作系统中, 浏览器市场的格局开始发生变化。<br> 微软 公司的市场份额不断增长, 而 网景 公司的市场份额则逐渐萎缩。</p><p><strong>1997 年 之前, <code>Navigator</code> 的市场份额超过 <code>80%</code> ,到 2002 年 之后, 已经降至不足 <code>1%</code>。</strong></p><p><span class="cor-wa">1998 年</span> 美国在线(AOL)收购 网景 。</p><p><span class="cor-wa">2003 年</span> 网景 公司停止了 <code>Navigator</code> 的开发和支持, 这标志着 网景 浏览器的终局。</p><p><span class="cor-wa">2017 年</span> AOL 宣布关闭 AOL Instant Messenger</p><p>这意味着 <code>Navigator</code> 浏览器的最后一个主要组件被关闭。<code>Navigator</code> <em>至此结束了它的历史</em>。</p><h2 id="第二次浏览器大战" tabindex="-1">第二次浏览器大战 <a class="header-anchor" href="#第二次浏览器大战" aria-label="Permalink to &quot;第二次浏览器大战&quot;">​</a></h2><p><span class="cor-wa">2000 年</span> 之后 <code>IE</code> 陆续推出了 <code>IE4、IE5、IE6 (windows xp)</code> 真正做到了天下大统</p><blockquote><p>微软甚至解散了浏览器的大部分员工, 只留下几个人象征性地维护顺便修补一下 bug.</p></blockquote><p><span class="cor-wa">1998 年 2 月</span> 网景 早期建立了 <code>Mozilla</code> 组织</p><p><span class="cor-wa">2002 年</span> 苹果公司开发出 <code>Webkit</code> 引擎</p><p><span class="cor-wa">2003 年</span> 苹果公司 推出 <code>Safari</code> 浏览器 并搭载 <code>Webkit</code> 依靠自己的设备优势占领 <code>mac</code> 市场。</p><p><span class="cor-wa">2004 年 11 月</span> 发布了 <code>Firefox</code> 的第一个正式版本 <code>Firefox1.0</code>, 即火狐浏览器。<br> 在随后的 4 年时间里, 尽管 IE 的份额依然领先<br><code>Firefox</code> 也稳扎稳打, 凭借几次大版本更新提升了浏览器的功能与先进性,<br> 又有 google 的神助攻, 它从 IE 手中夺下了两成多的市场份额。<br><code>firefox</code> 迅速成长, 成为了当时市场份额排名第二的浏览器。<br><code>Safari</code> 紧随其后</p><h2 id="第三次浏览器大战" tabindex="-1">第三次浏览器大战 <a class="header-anchor" href="#第三次浏览器大战" aria-label="Permalink to &quot;第三次浏览器大战&quot;">​</a></h2><p><span class="cor-wa">2005 年</span> <span class="cor-da">布兰登·艾奇 (Brendan Eich)</span>和<span class="cor-da">布雷克‧罗斯(Blake Ross)</span>, 带领团队成立 <code>Mozilla</code> <strong>基金会</strong>, 并决定, 将<code>Navigator</code> 开源。</p><blockquote><p>Navigator 开源之后 吸引了众多开发者的关注和贡献。</p><p>其中最为著名的是由 Mozilla 基金会开发的 Gecko 引擎。</p><p>Gecko 于 1998 年首次发布, 最初是为了 Mozilla 而开发的, 后来被 Firefox 等浏览器采用。</p><p>Gecko 引擎的开源, 推动了开源浏览器的发展, 例如 Firefox。</p></blockquote><p><span class="cor-wa">2006 年</span> 谷歌邀请 <span class="cor-da">拉斯·巴克（Lars Bak）</span> 领导 JavaScript 引擎开发。</p><p><span class="cor-wa">2008 年</span> 谷歌推出 chrome 浏览器 搭载 JS 执行引擎 V8 并将源码 开源</p><blockquote><p>V8 引擎, 可以将 JS 代码直接转换为字节码</p><p>理论上, JS 代码的执行速度已经接近汇编语言</p><p>JS 具备了编写大型应用程序的能力, 甚至服务器应用</p><p><strong>V8, 将 JS 的执行推向了一个新的台阶</strong></p></blockquote><p><span class="cor-wa">2012 年 3 月 </span> 谷歌 <code>Chrome</code> 浏览器的全球市场份额首次超过<code>IE</code>浏览器</p><p><span class="cor-wa">2015 年</span> 微软在 <code>Windows 10</code> 中内置了新开发的 <code>Microsoft Edge</code> 浏览器并逐步放弃 <code>IE</code></p><p><span class="cor-wa">2018 年</span> 微软下定决心放弃自家引擎, 转而采用更成熟、开源的 Chromium 内核。</p><p><span class="cor-wa">2020 年 1 月</span> , 微软发布了基于 Chromium 的新版 Microsoft Edge。</p><p><span class="cor-wa">2022 年 6 月</span> 全世界互联网用户的噩梦 —— <code>IE</code>, <em>正式宣告退出历史舞台</em> 。</p><p><span class="cor-wa">2023 年 1 月</span> 据 <code>Statcounter</code> 数据, 桌面浏览器市场占有率方面:</p><p><em>Chrome</em> 以 <strong>66.16%</strong> 排名第一</p><p><em>Edge</em> 以 <strong>10.99%</strong> 排名第二</p><p><em>Safari</em> 以 <strong>8.98%</strong> 排名第三</p><p><em>Firefox</em> 以 <strong>7.22%</strong> 排名第四</p><p><em>Opera</em> 以 <strong>3.29%</strong> 排名第五</p><h2 id="新开局" tabindex="-1">新开局 <a class="header-anchor" href="#新开局" aria-label="Permalink to &quot;新开局&quot;">​</a></h2><p><span class="cor-wa">2023 年</span> <code>openAI</code> 发布 <strong>大语言模型</strong> <code>chatGTP</code> 后 被 微软 收购</p><p><em>这可能是影响接下来用户网络访问入口的变革</em></p>', 37);
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_Badge = resolveComponent("Badge");
  return openBlock(), createElementBlock("div", null, [
    _hoisted_1,
    createBaseVNode("h2", _hoisted_2, [
      createTextVNode("WWW 的诞生 "),
      createVNode(_component_Badge, { type: "tip" }, {
        default: withCtx(() => [
          createTextVNode("老祖宗")
        ]),
        _: 1
      }),
      createTextVNode(),
      _hoisted_3
    ]),
    _hoisted_4,
    createBaseVNode("h2", _hoisted_8, [
      createTextVNode("第一次浏览器大战 "),
      createVNode(_component_Badge, { type: "tip" }, {
        default: withCtx(() => [
          createTextVNode("微软 对 网景")
        ]),
        _: 1
      }),
      createTextVNode(),
      _hoisted_9
    ]),
    _hoisted_10
  ]);
}
const browserWars = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  browserWars as default
};
