import { d as defineComponent, u as useData, h as ref, j as onMounted, a9 as onBeforeMount, o as openBlock, c as createElementBlock, I as Fragment, J as renderList, k as createBaseVNode, t as toDisplayString, n as normalizeClass, l as unref, _ as _export_sfc, L as createVNode, a as createTextVNode, V as createStaticVNode } from "./chunks/framework.2dcfa116.js";
const _hoisted_1$1 = { class: "inner" };
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "index",
  setup(__props) {
    const { isDark } = useData();
    const borderLight = ref();
    const cardsRef = ref();
    const cardsConfig = [
      "将鼠标",
      "移动到",
      "当前区域",
      "然后",
      "疯狂晃动",
      "观察边框变化"
    ];
    onMounted(() => {
      if (borderLight.value) {
        borderLight.value.onmousemove = (e) => {
          if (cardsRef.value) {
            for (const card of cardsRef.value) {
              const rect = card.getBoundingClientRect();
              const left = e.clientX - rect.left;
              const top = e.clientY - rect.top;
              card.style.setProperty("--left", `${left}px`);
              card.style.setProperty("--top", `${top}px`);
            }
          }
        };
      }
    });
    onBeforeMount(() => {
      if (borderLight.value) {
        borderLight.value.onmousemove = null;
      }
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: "borderLight",
        ref_key: "borderLight",
        ref: borderLight
      }, [
        (openBlock(), createElementBlock(Fragment, null, renderList(cardsConfig, (item, key) => {
          return createBaseVNode("div", {
            class: normalizeClass(["card", unref(isDark) ? "dark" : ""]),
            ref_for: true,
            ref_key: "cardsRef",
            ref: cardsRef,
            key
          }, [
            createBaseVNode("div", _hoisted_1$1, toDisplayString(item), 1)
          ], 2);
        }), 64))
      ], 512);
    };
  }
});
const index_vue_vue_type_style_index_0_scoped_4da050cd_lang = "";
const demo = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-4da050cd"]]);
const _hoisted_1 = /* @__PURE__ */ createBaseVNode("h1", {
  id: "闪光边框",
  tabindex: "-1"
}, [
  /* @__PURE__ */ createTextVNode("闪光边框 "),
  /* @__PURE__ */ createBaseVNode("a", {
    class: "header-anchor",
    href: "#闪光边框",
    "aria-label": 'Permalink to "闪光边框"'
  }, "​")
], -1);
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("h2", {
  id: "展示",
  tabindex: "-1"
}, [
  /* @__PURE__ */ createTextVNode("展示 "),
  /* @__PURE__ */ createBaseVNode("a", {
    class: "header-anchor",
    href: "#展示",
    "aria-label": 'Permalink to "展示"'
  }, "​")
], -1);
const _hoisted_3 = /* @__PURE__ */ createStaticVNode("", 3);
const __pageData = JSON.parse('{"title":"闪光边框","description":"","frontmatter":{},"headers":[],"relativePath":"demo/borderLight/main.md","filePath":"demo/borderLight/main.md"}');
const __default__ = { name: "demo/borderLight/main.md" };
const _sfc_main = /* @__PURE__ */ Object.assign(__default__, {
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", null, [
        _hoisted_1,
        _hoisted_2,
        createVNode(demo),
        _hoisted_3
      ]);
    };
  }
});
export {
  __pageData,
  _sfc_main as default
};
