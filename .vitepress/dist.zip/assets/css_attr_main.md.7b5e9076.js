import { _ as _export_sfc, c as createElementBlock, o as openBlock, V as createStaticVNode } from "./chunks/framework.2dcfa116.js";
const __pageData = JSON.parse('{"title":"属性值","description":"","frontmatter":{},"headers":[],"relativePath":"css/attr/main.md","filePath":"css/attr/main.md"}');
const _sfc_main = { name: "css/attr/main.md" };
const _hoisted_1 = /* @__PURE__ */ createStaticVNode('<h1 id="属性值" tabindex="-1">属性值 <a class="header-anchor" href="#属性值" aria-label="Permalink to &quot;属性值&quot;">​</a></h1><h2 id="大小值" tabindex="-1">大小值 <a class="header-anchor" href="#大小值" aria-label="Permalink to &quot;大小值&quot;">​</a></h2><ul><li>px: 像素 像素是最常用的单位之一</li><li>%: 百分比 百分比则是相对于父元素的宽度来计算的</li><li>vw: 视窗宽度 相对于浏览器窗口大小来计算</li><li>vh: 视窗高度 相对于浏览器窗口大小来计算</li><li>em: 相对于元素的字体大小。如果未设置字体大小，则相对于父元素的字体大小。</li><li>rem: 相对于根元素(html)的字体大小。如果未设置字体大小，则相对于浏览器的默认字体大小。</li><li>ex: 相对于元素的 x 字体高度（大约是字母 x 的高度）。</li><li>ch: 相对于元素的字体中的字符“0”的宽度。</li><li>vw: 相对于视口宽度的 1%。</li><li>vh: 相对于视口高度的 1%。</li><li>vmin: 相对于视口宽度和高度中较小值的 1%。</li><li>vmax: 相对于视口宽度和高度中较大值的 1%。</li><li>cm: 厘米。</li><li>mm: 毫米。</li><li>in: 英寸。</li><li>pt: 磅（1/72 英寸）。</li><li>pc: 十二点活字（1/6 英寸）。</li></ul><h2 id="颜色值" tabindex="-1">颜色值 <a class="header-anchor" href="#颜色值" aria-label="Permalink to &quot;颜色值&quot;">​</a></h2><ul><li>关键字</li></ul><blockquote><p>一些预定义的颜色名称，例如 red、green、blue、black、white 等。</p></blockquote><ul><li>HEX(HEXadecimal)</li></ul><blockquote><p>由三个或六个十六进制数字表示，每两个数字表示一个颜色分量，取值范围为 <code>00~FF</code>。例如，#FFFFFF 表示白色，#000000 表示黑色，#FF0000 表示红色。</p></blockquote><ul><li>RGB(Red Green Blue)</li></ul><blockquote><p>由三个颜色分量组成，每个颜色分量的取值范围为 <code>0~255</code>。例如，rgb(255, 255, 255)表示白色，rgb(0, 0, 0)表示黑色，rgb(255, 0, 0)表示红色。</p></blockquote><ul><li>RGBA(Red Green Blue Alpha)</li></ul><blockquote><p>由三个颜色分量和一个透明度分量组成，透明度的取值范围为 <code>0~1</code>。例如，rgba(255, 255, 255, 0.5)表示半透明的白色，rgba(0, 0, 0, 0)表示完全透明的黑色。</p></blockquote><ul><li>HSL(Hue Saturation Lightness)</li></ul><blockquote><p>由一个色相分量、一个饱和度分量和一个亮度分量组成，色相的取值范围为 <code>0~360</code>，饱和度和亮度的取值范围为 0100%。例如，hsl(0, 100%, 50%)表示红色，hsl(120, 100%, 50%)表示绿色，hsl(240, 100%, 50%)表示蓝色。</p></blockquote><ul><li>HSLA(Hue Saturation Lightness Alpha)</li></ul><blockquote><p>由一个色相分量、一个饱和度分量、一个亮度分量和一个透明度分量组成，透明度的取值范围为 <code>0~1</code>。例如，hsla(0, 100%, 50%, 0.5)表示半透明的红色，hsla(120, 100%, 50%, 0.5)表示半透明的绿色，hsla(240, 100%, 50%, 0.5)表示半透明的蓝色。</p></blockquote>', 16);
const _hoisted_17 = [
  _hoisted_1
];
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, _hoisted_17);
}
const main = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  main as default
};
