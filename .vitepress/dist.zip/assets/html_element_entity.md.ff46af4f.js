import { _ as _export_sfc, c as createElementBlock, o as openBlock, V as createStaticVNode } from "./chunks/framework.2dcfa116.js";
const __pageData = JSON.parse('{"title":"HTML 实体","description":"","frontmatter":{},"headers":[],"relativePath":"html/element/entity.md","filePath":"html/element/entity.md"}');
const _sfc_main = { name: "html/element/entity.md" };
const _hoisted_1 = /* @__PURE__ */ createStaticVNode('<h1 id="html-实体" tabindex="-1">HTML 实体 <a class="header-anchor" href="#html-实体" aria-label="Permalink to &quot;HTML 实体&quot;">​</a></h1><blockquote><p>实体字符， HTML Entity</p></blockquote><p>实体字符通常用于在页面中显示一些特殊符号。</p><h2 id="字符组成" tabindex="-1">字符组成 <a class="header-anchor" href="#字符组成" aria-label="Permalink to &quot;字符组成&quot;">​</a></h2><ul><li><code>&amp;+单词</code></li><li><code>&amp;#数字</code></li></ul><h2 id="常用实体字符" tabindex="-1">常用实体字符 <a class="header-anchor" href="#常用实体字符" aria-label="Permalink to &quot;常用实体字符&quot;">​</a></h2><ul><li>小于符号 <span class="cor-in">&lt;</span></li></ul><div class="language-html"><button title="Copy Code" class="copy"></button><span class="lang">html</span><pre class="shiki material-theme-palenight"><code><span class="line"><span style="color:#A6ACCD;">&amp;lt;</span></span></code></pre></div><ul><li>大于符号 <span class="cor-in">&gt;</span></li></ul><div class="language-html"><button title="Copy Code" class="copy"></button><span class="lang">html</span><pre class="shiki material-theme-palenight"><code><span class="line"><span style="color:#A6ACCD;">&amp;gt;</span></span></code></pre></div><ul><li>空格符号 <span class="cor-in"> </span></li></ul><div class="language-html"><button title="Copy Code" class="copy"></button><span class="lang">html</span><pre class="shiki material-theme-palenight"><code><span class="line"><span style="color:#A6ACCD;">&amp;nbsp;</span></span></code></pre></div><ul><li>版权符号 <span class="cor-in">©</span></li></ul><div class="language-html"><button title="Copy Code" class="copy"></button><span class="lang">html</span><pre class="shiki material-theme-palenight"><code><span class="line"><span style="color:#A6ACCD;">&amp;copy;</span></span></code></pre></div><ul><li>&amp;符号 <span class="cor-in">&amp;</span></li></ul><div class="language-html"><button title="Copy Code" class="copy"></button><span class="lang">html</span><pre class="shiki material-theme-palenight"><code><span class="line"><span style="color:#A6ACCD;">&amp;amp;</span></span></code></pre></div>', 16);
const _hoisted_17 = [
  _hoisted_1
];
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, _hoisted_17);
}
const entity = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  entity as default
};
