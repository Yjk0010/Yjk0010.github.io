import { _ as _export_sfc, c as createElementBlock, o as openBlock, k as createBaseVNode, a as createTextVNode } from "./chunks/framework.2dcfa116.js";
const __pageData = JSON.parse('{"title":"个人简介","description":"","frontmatter":{},"headers":[],"relativePath":"aboutMe/selfDesc.md","filePath":"aboutMe/selfDesc.md"}');
const _sfc_main = { name: "aboutMe/selfDesc.md" };
const _hoisted_1 = /* @__PURE__ */ createBaseVNode("h1", {
  id: "个人简介",
  tabindex: "-1"
}, [
  /* @__PURE__ */ createTextVNode("个人简介 "),
  /* @__PURE__ */ createBaseVNode("a", {
    class: "header-anchor",
    href: "#个人简介",
    "aria-label": 'Permalink to "个人简介"'
  }, "​")
], -1);
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("h2", {
  id: "_5-年前端开发",
  tabindex: "-1"
}, [
  /* @__PURE__ */ createTextVNode("5 年前端开发 "),
  /* @__PURE__ */ createBaseVNode("a", {
    class: "header-anchor",
    href: "#_5-年前端开发",
    "aria-label": 'Permalink to "5 年前端开发"'
  }, "​")
], -1);
const _hoisted_3 = [
  _hoisted_1,
  _hoisted_2
];
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, _hoisted_3);
}
const selfDesc = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  selfDesc as default
};
