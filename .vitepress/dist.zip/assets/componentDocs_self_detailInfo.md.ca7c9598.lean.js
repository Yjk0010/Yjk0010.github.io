import { l as lib } from "./chunks/base.36303bf0.js";
import "./chunks/button.fdf0e29d.js";
import { L as Line } from "./chunks/Line.05ecb785.js";
import { d as defineComponent, o as openBlock, c as createElementBlock, I as Fragment, J as renderList, b as createBlock, e as createCommentVNode, U as normalizeStyle, k as createBaseVNode, t as toDisplayString, n as normalizeClass, r as renderSlot, _ as _export_sfc, h as ref, a5 as reactive, L as createVNode, w as withCtx, a as createTextVNode, V as createStaticVNode } from "./chunks/framework.2dcfa116.js";
const badge = "";
const _hoisted_1$1 = { class: "detailInfo" };
const _hoisted_2$1 = {
  key: 0,
  style: { "flex": "1" }
};
const _hoisted_3$1 = ["title", "innerHTML"];
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "DetailInfo",
  props: {
    infoConfig: { default: () => [] },
    info: { default: () => {
    } },
    col: { default: 3 },
    labelWidth: { default: "80px" },
    colon: { type: Boolean, default: true }
  },
  setup(__props) {
    const props = __props;
    const show = (text, item, info) => {
      if (typeof item.show === "function") {
        return item.show(text, item, info);
      } else {
        return item.show === void 0 ? true : item.show;
      }
    };
    const valueCustomRender = (item) => {
      const { key, customRender } = item;
      return customRender ? customRender(props.info[key], item, props.info) : [null, void 0, ""].includes(props.info[key]) ? "--" : props.info[key];
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$1, [
        (openBlock(true), createElementBlock(Fragment, null, renderList(_ctx.infoConfig, (item) => {
          return openBlock(), createElementBlock(Fragment, null, [
            item.type === "line" ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
              show(_ctx.info[item.key], item, _ctx.info) ? (openBlock(), createBlock(Line, {
                style: { "width": "100%", "margin-bottom": "12px" },
                key: item.key,
                title: item.label,
                position: item.position
              }, null, 8, ["title", "position"])) : createCommentVNode("", true)
            ], 64)) : show(_ctx.info[item.key], item, _ctx.info) ? (openBlock(), createElementBlock("div", {
              key: item.key,
              class: "detail-info-item",
              style: normalizeStyle({ width: `${100 / (item.col || _ctx.col)}%` })
            }, [
              createBaseVNode("span", {
                style: normalizeStyle({ width: `${_ctx.labelWidth}` }),
                class: normalizeClass(["label", { colon: _ctx.colon }])
              }, toDisplayString(item.labelCustomRender ? item.labelCustomRender(item.label, _ctx.info[item.key], item, _ctx.info) : item.label), 7),
              item.slotName ? (openBlock(), createElementBlock("span", _hoisted_2$1, [
                renderSlot(_ctx.$slots, item.slotName, {
                  value: _ctx.info[item.key],
                  item,
                  info: _ctx.info
                }, void 0, true)
              ])) : (openBlock(), createElementBlock("span", {
                key: 1,
                class: normalizeClass(["value", "nowrap", { wrap: item.wrap }]),
                title: item.ellipsis ? valueCustomRender(item) : "",
                innerHTML: valueCustomRender(item)
              }, null, 10, _hoisted_3$1))
            ], 4)) : createCommentVNode("", true)
          ], 64);
        }), 256))
      ]);
    };
  }
});
const DetailInfo_vue_vue_type_style_index_0_scoped_c44aefa5_lang = "";
const DetailInfo = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["__scopeId", "data-v-c44aefa5"]]);
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "test",
  setup(__props) {
    const col = ref(2);
    const isShow = ref(true);
    const info = reactive({
      colon: "是否展示引号",
      labelWidth: "展示的title宽度",
      col: "全局在行中显示的列数 默认为3",
      infoConfig: "数组 内部是每个item的参数",
      info: "展示的内容对象",
      key: "当前读取的属性",
      label: "展示的title",
      type: "现在有两种类型 一种是 line 一种是 item",
      show: "控制展示 一种是 boolean 一种是函数",
      customRender: "自定义渲染函数 参数返回为 (当前值,传入的item,传入的info) ",
      labelCustomRender: "label自定义渲染函数 参数返回为 (当前值,传入的item,传入的info) ",
      slotName: "插槽名字 可以通过slot渲染",
      wrap: "结果是否可以换行 默认不换行",
      ellipsis: "是否对value 进行title提示",
      position: "type为line的时候label的显示位置 默认为左边",
      itemCol: "当前属性的在行中显示的列数 默认为 全局 col"
    });
    const infoConfig = [
      {
        label: "props介绍",
        key: "props",
        type: "line",
        position: "center"
      },
      {
        label: "info",
        key: "info"
      },
      {
        label: "col",
        key: "col",
        col: 1
      },
      {
        label: "labelWidth",
        key: "labelWidth"
      },
      {
        label: "colon",
        key: "colon"
      },
      {
        label: "infoConfig",
        key: "infoConfig",
        col: 1
      },
      {
        label: "infoConfig介绍",
        key: "infoConfig介绍",
        type: "line",
        position: "center"
      },
      {
        label: "key",
        key: "key"
      },
      {
        label: "label",
        key: "label"
      },
      {
        label: "type",
        key: "type",
        col: 1
      },
      {
        label: "show",
        key: "show",
        show: (value, item, info2) => {
          return isShow.value;
        },
        col: 1
      },
      {
        label: "customRender",
        key: "customRender",
        customRender: (value, item, info2) => {
          return info2[item[`key`]];
        },
        col: 1
      },
      {
        label: "labelCustomRender",
        key: "labelCustomRender",
        labelCustomRender: (label, value, item, info2) => {
          return label;
        },
        ellipsis: true,
        col: 1
      },
      {
        label: "slotName",
        key: "slotName",
        ellipsis: true,
        slotName: "slotName",
        col: 1
      },
      {
        label: "wrap",
        key: "wrap",
        wrap: true
      },
      {
        label: "ellipsis",
        key: "ellipsis",
        ellipsis: true
      },
      {
        label: "position",
        key: "position",
        ellipsis: true,
        col: 1
      },
      {
        label: "col",
        key: "itemCol",
        col: 1
      }
    ];
    const handleIsShow = () => {
      isShow.value = !isShow.value;
    };
    return (_ctx, _cache) => {
      const _component_el_button = lib.ElButton;
      const _component_el_badge = lib.ElBadge;
      return openBlock(), createElementBlock(Fragment, null, [
        createVNode(_component_el_badge, {
          value: +isShow.value,
          class: "item"
        }, {
          default: withCtx(() => [
            createVNode(_component_el_button, {
              type: "default",
              onClick: handleIsShow
            }, {
              default: withCtx(() => [
                createTextVNode(toDisplayString(isShow.value ? "show is show" : "show is hide"), 1)
              ]),
              _: 1
            })
          ]),
          _: 1
        }, 8, ["value"]),
        createVNode(DetailInfo, {
          info,
          labelWidth: "180px",
          col: col.value,
          infoConfig
        }, {
          slotName: withCtx(({ value, item, info: info2 }) => [
            createBaseVNode("span", null, toDisplayString(value), 1)
          ]),
          _: 1
        }, 8, ["info", "col"])
      ], 64);
    };
  }
});
const _hoisted_1 = /* @__PURE__ */ createBaseVNode("h1", {
  id: "展示详情组件",
  tabindex: "-1"
}, [
  /* @__PURE__ */ createTextVNode("展示详情组件 "),
  /* @__PURE__ */ createBaseVNode("a", {
    class: "header-anchor",
    href: "#展示详情组件",
    "aria-label": 'Permalink to "展示详情组件"'
  }, "​")
], -1);
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("blockquote", null, [
  /* @__PURE__ */ createBaseVNode("p", null, "用来展示详情信息")
], -1);
const _hoisted_3 = /* @__PURE__ */ createStaticVNode("", 2);
const __pageData = JSON.parse('{"title":"展示详情组件","description":"","frontmatter":{},"headers":[],"relativePath":"componentDocs/self/detailInfo.md","filePath":"componentDocs/self/detailInfo.md"}');
const __default__ = { name: "componentDocs/self/detailInfo.md" };
const _sfc_main = /* @__PURE__ */ Object.assign(__default__, {
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", null, [
        _hoisted_1,
        _hoisted_2,
        createVNode(_sfc_main$1),
        _hoisted_3
      ]);
    };
  }
});
export {
  __pageData,
  _sfc_main as default
};
