import { _ as _export_sfc, c as createElementBlock, o as openBlock, V as createStaticVNode } from "./chunks/framework.2dcfa116.js";
const __pageData = JSON.parse('{"title":"小知识点","description":"","frontmatter":{},"headers":[],"relativePath":"css/base/main.md","filePath":"css/base/main.md"}');
const _sfc_main = { name: "css/base/main.md" };
const _hoisted_1 = /* @__PURE__ */ createStaticVNode('<h1 id="小知识点" tabindex="-1">小知识点 <a class="header-anchor" href="#小知识点" aria-label="Permalink to &quot;小知识点&quot;">​</a></h1><h2 id="link-和-import-的区别" tabindex="-1">link 和@import 的区别 <a class="header-anchor" href="#link-和-import-的区别" aria-label="Permalink to &quot;link 和@import 的区别&quot;">​</a></h2><p>两者都是外部引用 CSS 的方式, 它们的区别如下：</p><ul><li><code>link</code> 是 XHTML 标签, 除了加载 CSS 外, 还可以定义 RSS 等其他事务</li><li><code>@import</code> 属于 CSS 范畴, 只能加载 CSS。 <ul><li><span class="cor-in">link 引用 CSS 时, 在页面载入时同时加载</span></li><li><span class="cor-wa">@import 需要页面网页完全载入以后加载。</span></li><li><span class="cor-in">link 是 XHTML 标签, 无兼容问题</span></li><li><span class="cor-wa">@import 是在 CSS 2.1 提出的, 低版本的浏览器不支持。</span></li><li><span class="cor-in">link 支持使用 Javascript 控制 DOM 去改变样式</span></li><li><span class="cor-wa">@import 不支持。</span></li></ul></li></ul>', 4);
const _hoisted_5 = [
  _hoisted_1
];
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, _hoisted_5);
}
const main = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  main as default
};
