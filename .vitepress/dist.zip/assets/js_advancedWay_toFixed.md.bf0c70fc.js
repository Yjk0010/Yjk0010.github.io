import { _ as _export_sfc, H as resolveComponent, c as createElementBlock, k as createBaseVNode, a as createTextVNode, L as createVNode, w as withCtx, V as createStaticVNode, o as openBlock } from "./chunks/framework.2dcfa116.js";
const __pageData = JSON.parse('{"title":"toFixed 不准","description":"","frontmatter":{},"headers":[],"relativePath":"js/advancedWay/toFixed.md","filePath":"js/advancedWay/toFixed.md"}');
const _sfc_main = { name: "js/advancedWay/toFixed.md" };
const _hoisted_1 = /* @__PURE__ */ createStaticVNode('<h1 id="tofixed-不准" tabindex="-1">toFixed 不准 <a class="header-anchor" href="#tofixed-不准" aria-label="Permalink to &quot;toFixed 不准&quot;">​</a></h1><h2 id="为啥-tofixed-不准" tabindex="-1">为啥 toFixed 不准 <a class="header-anchor" href="#为啥-tofixed-不准" aria-label="Permalink to &quot;为啥 toFixed 不准&quot;">​</a></h2><blockquote><p>toFixed 的原因是因为 计算机存储小数的精度问题</p></blockquote><p>这里要使用到一个函数 <span class="cor-wa">Number.prototype.toPrecision()</span> <a href="https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Number/toPrecision" target="_blank" rel="noreferrer">MDN toPrecision</a></p><blockquote><p>toPrecision(precision) 方法以指定的精度返回该数值对象的字符串表示。</p><p><span class="cor-wa">precision</span> 一个用来指定有效数个数的整数。</p></blockquote><p><span class="cor-tip">看一下例子</span></p><div class="language-javascript"><button title="Copy Code" class="copy"></button><span class="lang">javascript</span><pre class="shiki material-theme-palenight"><code><span class="line"><span style="color:#A6ACCD;">(</span><span style="color:#F78C6C;">2.55</span><span style="color:#A6ACCD;">)</span><span style="color:#89DDFF;">.</span><span style="color:#82AAFF;">toPrecision</span><span style="color:#A6ACCD;">(</span><span style="color:#F78C6C;">20</span><span style="color:#A6ACCD;">)</span><span style="color:#89DDFF;">;</span></span>\n<span class="line"><span style="color:#676E95;font-style:italic;">// &#39;2.5499999999999998224&#39;</span></span>\n<span class="line"><span style="color:#A6ACCD;">(</span><span style="color:#F78C6C;">2.55</span><span style="color:#A6ACCD;">)</span><span style="color:#89DDFF;">.</span><span style="color:#82AAFF;">toFixed</span><span style="color:#A6ACCD;">(</span><span style="color:#F78C6C;">1</span><span style="color:#A6ACCD;">)</span><span style="color:#89DDFF;">;</span></span>\n<span class="line"><span style="color:#676E95;font-style:italic;">// &#39;2.5&#39;</span></span>\n<span class="line"><span style="color:#A6ACCD;">(</span><span style="color:#F78C6C;">2.45</span><span style="color:#A6ACCD;">)</span><span style="color:#89DDFF;">.</span><span style="color:#82AAFF;">toPrecision</span><span style="color:#A6ACCD;">(</span><span style="color:#F78C6C;">20</span><span style="color:#A6ACCD;">)</span><span style="color:#89DDFF;">;</span></span>\n<span class="line"><span style="color:#676E95;font-style:italic;">// &#39;2.4500000000000001776&#39;</span></span>\n<span class="line"><span style="color:#A6ACCD;">(</span><span style="color:#F78C6C;">2.45</span><span style="color:#A6ACCD;">)</span><span style="color:#89DDFF;">.</span><span style="color:#82AAFF;">toFixed</span><span style="color:#A6ACCD;">(</span><span style="color:#F78C6C;">1</span><span style="color:#A6ACCD;">)</span><span style="color:#89DDFF;">;</span></span>\n<span class="line"><span style="color:#676E95;font-style:italic;">// &#39;2.5&#39;</span></span></code></pre></div><blockquote><p>所以用 <code>toFixed</code> 这玩意四舍五入就是坑 所以使用 <code>toLocaleString</code> 来实现相应功能</p></blockquote><h2 id="tolocalestring-介绍" tabindex="-1">toLocaleString 介绍 <a class="header-anchor" href="#tolocalestring-介绍" aria-label="Permalink to &quot;toLocaleString 介绍&quot;">​</a></h2><p><a href="https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Number/toLocaleString" target="_blank" rel="noreferrer">Number.prototype.toLocaleString()</a></p><div class="language-javascript"><button title="Copy Code" class="copy"></button><span class="lang">javascript</span><pre class="shiki material-theme-palenight"><code><span class="line"><span style="color:#A6ACCD;">(</span><span style="color:#F78C6C;">2.55</span><span style="color:#A6ACCD;">)</span><span style="color:#89DDFF;">.</span><span style="color:#82AAFF;">toLocaleString</span><span style="color:#A6ACCD;">(</span><span style="color:#89DDFF;">undefined,</span><span style="color:#A6ACCD;"> </span><span style="color:#89DDFF;">{</span></span>\n<span class="line"><span style="color:#A6ACCD;">  </span><span style="color:#F07178;">maximumFractionDigits</span><span style="color:#89DDFF;">:</span><span style="color:#A6ACCD;"> </span><span style="color:#F78C6C;">1</span><span style="color:#89DDFF;">,</span></span>\n<span class="line"><span style="color:#A6ACCD;">  </span><span style="color:#F07178;">minimumFractionDigits</span><span style="color:#89DDFF;">:</span><span style="color:#A6ACCD;"> </span><span style="color:#F78C6C;">1</span><span style="color:#89DDFF;">,</span></span>\n<span class="line"><span style="color:#A6ACCD;">  </span><span style="color:#F07178;">useGrouping</span><span style="color:#89DDFF;">:</span><span style="color:#A6ACCD;"> </span><span style="color:#FF9CAC;">false</span><span style="color:#89DDFF;">,</span></span>\n<span class="line"><span style="color:#89DDFF;">}</span><span style="color:#A6ACCD;">)</span><span style="color:#89DDFF;">;</span></span>\n<span class="line"><span style="color:#676E95;font-style:italic;">// &#39;2.6&#39;</span></span>\n<span class="line"><span style="color:#A6ACCD;">(</span><span style="color:#F78C6C;">2.45</span><span style="color:#A6ACCD;">)</span><span style="color:#89DDFF;">.</span><span style="color:#82AAFF;">toLocaleString</span><span style="color:#A6ACCD;">(</span><span style="color:#89DDFF;">undefined,</span><span style="color:#A6ACCD;"> </span><span style="color:#89DDFF;">{</span></span>\n<span class="line"><span style="color:#A6ACCD;">  </span><span style="color:#F07178;">maximumFractionDigits</span><span style="color:#89DDFF;">:</span><span style="color:#A6ACCD;"> </span><span style="color:#F78C6C;">1</span><span style="color:#89DDFF;">,</span></span>\n<span class="line"><span style="color:#A6ACCD;">  </span><span style="color:#F07178;">minimumFractionDigits</span><span style="color:#89DDFF;">:</span><span style="color:#A6ACCD;"> </span><span style="color:#F78C6C;">1</span><span style="color:#89DDFF;">,</span></span>\n<span class="line"><span style="color:#A6ACCD;">  </span><span style="color:#F07178;">useGrouping</span><span style="color:#89DDFF;">:</span><span style="color:#A6ACCD;"> </span><span style="color:#FF9CAC;">false</span><span style="color:#89DDFF;">,</span></span>\n<span class="line"><span style="color:#89DDFF;">}</span><span style="color:#A6ACCD;">)</span><span style="color:#89DDFF;">;</span></span>\n<span class="line"><span style="color:#676E95;font-style:italic;">// &#39;2.5&#39;</span></span></code></pre></div><p><span class="cor-wa">toLocaleString(locales, options)</span></p>', 12);
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("p", null, "locales :"),
  /* @__PURE__ */ createBaseVNode("ul", null, [
    /* @__PURE__ */ createBaseVNode("li", null, [
      /* @__PURE__ */ createTextVNode("语言代码 "),
      /* @__PURE__ */ createBaseVNode("ul", null, [
        /* @__PURE__ */ createBaseVNode("li", null, [
          /* @__PURE__ */ createTextVNode("中国 -> "),
          /* @__PURE__ */ createBaseVNode("code", null, "zh")
        ]),
        /* @__PURE__ */ createBaseVNode("li", null, [
          /* @__PURE__ */ createTextVNode("英国 -> "),
          /* @__PURE__ */ createBaseVNode("code", null, "en")
        ])
      ])
    ])
  ])
], -1);
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("p", null, "options :", -1);
const _hoisted_15 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("code", null, "maximumFractionDigits"),
  /* @__PURE__ */ createTextVNode(" : 四舍五入最大位数")
], -1);
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("code", null, "minimumFractionDigits"),
  /* @__PURE__ */ createTextVNode(" : 四舍五入最小位数")
], -1);
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("code", null, "useGrouping", -1);
const _hoisted_18 = /* @__PURE__ */ createBaseVNode("code", null, ",", -1);
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("code", null, ".", -1);
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("code", null, null, -1);
const _hoisted_21 = /* @__PURE__ */ createBaseVNode("code", null, ' "auto"', -1);
const _hoisted_22 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("code", null, '"always"'),
  /* @__PURE__ */ createTextVNode(" 显示分组分隔符，即使语言环境不喜欢。")
], -1);
const _hoisted_23 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("code", null, "false"),
  /* @__PURE__ */ createTextVNode(" 不显示分隔符。")
], -1);
const _hoisted_24 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("code", null, "true"),
  /* @__PURE__ */ createTextVNode(" 同 "),
  /* @__PURE__ */ createBaseVNode("code", null, '"always"')
], -1);
const _hoisted_25 = /* @__PURE__ */ createBaseVNode("code", null, "style", -1);
const _hoisted_26 = /* @__PURE__ */ createBaseVNode("code", null, '"decimal"', -1);
const _hoisted_27 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("code", null, '"currency"'),
  /* @__PURE__ */ createTextVNode(" 用于货币格式 需要配置")
], -1);
const _hoisted_28 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("code", null, '"percent"'),
  /* @__PURE__ */ createTextVNode(" 用于百分比格式")
], -1);
const _hoisted_29 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("code", null, '"unit"'),
  /* @__PURE__ */ createTextVNode(" 用于货币格式")
], -1);
const _hoisted_30 = /* @__PURE__ */ createStaticVNode('<li><code>currency</code> <span class="cor-tip">style</span> 属性为 <span class="cor-wa">currency</span> 时候必含 <a href="https://en.wikipedia.org/wiki/ISO_4217" target="_blank" rel="noreferrer">钱代码可选</a></li><li><code>unit</code> <span class="cor-tip">style</span> 属性为 <span class="cor-wa">unit</span> 时候必含 <a href="https://tc39.es/proposal-unified-intl-numberformat/section6/locales-currencies-tz_proposed_out.html#sec-issanctionedsimpleunitidentifier" target="_blank" rel="noreferrer">单位可选值</a></li>', 2);
const _hoisted_32 = /* @__PURE__ */ createStaticVNode('<div class="language-javascript"><button title="Copy Code" class="copy"></button><span class="lang">javascript</span><pre class="shiki material-theme-palenight"><code><span class="line"><span style="color:#A6ACCD;">(</span><span style="color:#F78C6C;">1232.45</span><span style="color:#A6ACCD;">)</span><span style="color:#89DDFF;">.</span><span style="color:#82AAFF;">toLocaleString</span><span style="color:#A6ACCD;">(</span><span style="color:#89DDFF;">&quot;</span><span style="color:#C3E88D;">zh</span><span style="color:#89DDFF;">&quot;</span><span style="color:#89DDFF;">,</span><span style="color:#A6ACCD;"> </span><span style="color:#89DDFF;">{</span></span>\n<span class="line"><span style="color:#A6ACCD;">  </span><span style="color:#F07178;">maximumFractionDigits</span><span style="color:#89DDFF;">:</span><span style="color:#A6ACCD;"> </span><span style="color:#F78C6C;">1</span><span style="color:#89DDFF;">,</span></span>\n<span class="line"><span style="color:#A6ACCD;">  </span><span style="color:#F07178;">minimumFractionDigits</span><span style="color:#89DDFF;">:</span><span style="color:#A6ACCD;"> </span><span style="color:#F78C6C;">1</span><span style="color:#89DDFF;">,</span></span>\n<span class="line"><span style="color:#A6ACCD;">  </span><span style="color:#F07178;">style</span><span style="color:#89DDFF;">:</span><span style="color:#A6ACCD;"> </span><span style="color:#89DDFF;">&quot;</span><span style="color:#C3E88D;">currency</span><span style="color:#89DDFF;">&quot;</span><span style="color:#89DDFF;">,</span></span>\n<span class="line"><span style="color:#A6ACCD;">  </span><span style="color:#F07178;">currency</span><span style="color:#89DDFF;">:</span><span style="color:#A6ACCD;"> </span><span style="color:#89DDFF;">&quot;</span><span style="color:#C3E88D;">CNY</span><span style="color:#89DDFF;">&quot;</span><span style="color:#89DDFF;">,</span></span>\n<span class="line"><span style="color:#89DDFF;">}</span><span style="color:#A6ACCD;">)</span><span style="color:#89DDFF;">;</span></span>\n<span class="line"><span style="color:#676E95;font-style:italic;">// &#39;¥1,232.5&#39;</span></span>\n<span class="line"><span style="color:#A6ACCD;">(</span><span style="color:#F78C6C;">1232.45</span><span style="color:#A6ACCD;">)</span><span style="color:#89DDFF;">.</span><span style="color:#82AAFF;">toLocaleString</span><span style="color:#A6ACCD;">(</span><span style="color:#89DDFF;">&quot;</span><span style="color:#C3E88D;">en-US</span><span style="color:#89DDFF;">&quot;</span><span style="color:#89DDFF;">,</span><span style="color:#A6ACCD;"> </span><span style="color:#89DDFF;">{</span></span>\n<span class="line"><span style="color:#A6ACCD;">  </span><span style="color:#F07178;">maximumFractionDigits</span><span style="color:#89DDFF;">:</span><span style="color:#A6ACCD;"> </span><span style="color:#F78C6C;">1</span><span style="color:#89DDFF;">,</span></span>\n<span class="line"><span style="color:#A6ACCD;">  </span><span style="color:#F07178;">minimumFractionDigits</span><span style="color:#89DDFF;">:</span><span style="color:#A6ACCD;"> </span><span style="color:#F78C6C;">1</span><span style="color:#89DDFF;">,</span></span>\n<span class="line"><span style="color:#A6ACCD;">  </span><span style="color:#F07178;">style</span><span style="color:#89DDFF;">:</span><span style="color:#A6ACCD;"> </span><span style="color:#89DDFF;">&quot;</span><span style="color:#C3E88D;">currency</span><span style="color:#89DDFF;">&quot;</span><span style="color:#89DDFF;">,</span></span>\n<span class="line"><span style="color:#A6ACCD;">  </span><span style="color:#F07178;">currency</span><span style="color:#89DDFF;">:</span><span style="color:#A6ACCD;"> </span><span style="color:#89DDFF;">&quot;</span><span style="color:#C3E88D;">USD</span><span style="color:#89DDFF;">&quot;</span><span style="color:#89DDFF;">,</span></span>\n<span class="line"><span style="color:#89DDFF;">}</span><span style="color:#A6ACCD;">)</span><span style="color:#89DDFF;">;</span></span>\n<span class="line"><span style="color:#676E95;font-style:italic;">// &#39;$1,232.5&#39;</span></span>\n<span class="line"><span style="color:#A6ACCD;">(</span><span style="color:#F78C6C;">1232.45</span><span style="color:#A6ACCD;">)</span><span style="color:#89DDFF;">.</span><span style="color:#82AAFF;">toLocaleString</span><span style="color:#A6ACCD;">(</span><span style="color:#89DDFF;">&quot;</span><span style="color:#C3E88D;">zh</span><span style="color:#89DDFF;">&quot;</span><span style="color:#89DDFF;">,</span><span style="color:#A6ACCD;"> </span><span style="color:#89DDFF;">{</span></span>\n<span class="line"><span style="color:#A6ACCD;">  </span><span style="color:#F07178;">maximumFractionDigits</span><span style="color:#89DDFF;">:</span><span style="color:#A6ACCD;"> </span><span style="color:#F78C6C;">1</span><span style="color:#89DDFF;">,</span></span>\n<span class="line"><span style="color:#A6ACCD;">  </span><span style="color:#F07178;">minimumFractionDigits</span><span style="color:#89DDFF;">:</span><span style="color:#A6ACCD;"> </span><span style="color:#F78C6C;">1</span><span style="color:#89DDFF;">,</span></span>\n<span class="line"><span style="color:#A6ACCD;">  </span><span style="color:#F07178;">style</span><span style="color:#89DDFF;">:</span><span style="color:#A6ACCD;"> </span><span style="color:#89DDFF;">&quot;</span><span style="color:#C3E88D;">unit</span><span style="color:#89DDFF;">&quot;</span><span style="color:#89DDFF;">,</span></span>\n<span class="line"><span style="color:#A6ACCD;">  </span><span style="color:#F07178;">unit</span><span style="color:#89DDFF;">:</span><span style="color:#A6ACCD;"> </span><span style="color:#89DDFF;">&quot;</span><span style="color:#C3E88D;">milliliter</span><span style="color:#89DDFF;">&quot;</span><span style="color:#89DDFF;">,</span></span>\n<span class="line"><span style="color:#89DDFF;">}</span><span style="color:#A6ACCD;">)</span><span style="color:#89DDFF;">;</span></span>\n<span class="line"><span style="color:#676E95;font-style:italic;">// &#39;1,232.5毫升&#39;</span></span></code></pre></div><h2 id="重写-tofixed-方法" tabindex="-1">重写 toFixed 方法 <a class="header-anchor" href="#重写-tofixed-方法" aria-label="Permalink to &quot;重写 toFixed 方法&quot;">​</a></h2><blockquote><p>这里不能使用箭头函数 因为要通过 <code>this</code> 拿到当前输入的值 <code>Number</code> <span class="cor-da">this</span></p></blockquote><div class="language-javascript"><button title="Copy Code" class="copy"></button><span class="lang">javascript</span><pre class="shiki material-theme-palenight"><code><span class="line"><span style="color:#FFCB6B;">Number</span><span style="color:#89DDFF;">.</span><span style="color:#A6ACCD;">prototype</span><span style="color:#89DDFF;">.</span><span style="color:#82AAFF;">toFixed</span><span style="color:#A6ACCD;"> </span><span style="color:#89DDFF;">=</span><span style="color:#A6ACCD;"> </span><span style="color:#C792EA;">function</span><span style="color:#A6ACCD;"> </span><span style="color:#89DDFF;">(</span><span style="color:#A6ACCD;font-style:italic;">digits</span><span style="color:#A6ACCD;"> </span><span style="color:#89DDFF;">=</span><span style="color:#A6ACCD;"> </span><span style="color:#F78C6C;">0</span><span style="color:#89DDFF;">)</span><span style="color:#A6ACCD;"> </span><span style="color:#89DDFF;">{</span></span>\n<span class="line"><span style="color:#F07178;">  </span><span style="color:#89DDFF;font-style:italic;">return</span><span style="color:#F07178;"> </span><span style="color:#89DDFF;">this.</span><span style="color:#82AAFF;">toLocaleString</span><span style="color:#F07178;">(</span><span style="color:#89DDFF;">undefined,</span><span style="color:#F07178;"> </span><span style="color:#89DDFF;">{</span></span>\n<span class="line"><span style="color:#F07178;">    maximumFractionDigits</span><span style="color:#89DDFF;">:</span><span style="color:#F07178;"> </span><span style="color:#A6ACCD;">digits</span><span style="color:#89DDFF;">,</span></span>\n<span class="line"><span style="color:#F07178;">    minimumFractionDigits</span><span style="color:#89DDFF;">:</span><span style="color:#F07178;"> </span><span style="color:#A6ACCD;">digits</span><span style="color:#89DDFF;">,</span></span>\n<span class="line"><span style="color:#89DDFF;">    </span><span style="color:#676E95;font-style:italic;">// 不使用分组符号</span></span>\n<span class="line"><span style="color:#F07178;">    useGrouping</span><span style="color:#89DDFF;">:</span><span style="color:#F07178;"> </span><span style="color:#FF9CAC;">false</span><span style="color:#89DDFF;">,</span></span>\n<span class="line"><span style="color:#F07178;">  </span><span style="color:#89DDFF;">}</span><span style="color:#F07178;">)</span><span style="color:#89DDFF;">;</span></span>\n<span class="line"><span style="color:#89DDFF;">};</span></span>\n<span class="line"></span>\n<span class="line"><span style="color:#A6ACCD;">(</span><span style="color:#F78C6C;">2.55</span><span style="color:#A6ACCD;">)</span><span style="color:#89DDFF;">.</span><span style="color:#82AAFF;">toFixed</span><span style="color:#A6ACCD;">(</span><span style="color:#F78C6C;">1</span><span style="color:#A6ACCD;">)</span><span style="color:#89DDFF;">;</span></span>\n<span class="line"><span style="color:#676E95;font-style:italic;">// &#39;2.6&#39;</span></span>\n<span class="line"><span style="color:#A6ACCD;">(</span><span style="color:#F78C6C;">2.45</span><span style="color:#A6ACCD;">)</span><span style="color:#89DDFF;">.</span><span style="color:#82AAFF;">toFixed</span><span style="color:#A6ACCD;">(</span><span style="color:#F78C6C;">1</span><span style="color:#A6ACCD;">)</span><span style="color:#89DDFF;">;</span></span>\n<span class="line"><span style="color:#676E95;font-style:italic;">// &#39;2.5&#39;</span></span></code></pre></div>', 4);
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_Badge = resolveComponent("Badge");
  return openBlock(), createElementBlock("div", null, [
    _hoisted_1,
    createBaseVNode("ul", null, [
      _hoisted_13,
      createBaseVNode("li", null, [
        _hoisted_14,
        createBaseVNode("ol", null, [
          _hoisted_15,
          _hoisted_16,
          createBaseVNode("li", null, [
            _hoisted_17,
            createTextVNode(" : 分组符号 根据语言来的大多数是 "),
            _hoisted_18,
            createTextVNode("、"),
            _hoisted_19,
            createTextVNode("和 "),
            _hoisted_20,
            createBaseVNode("ol", null, [
              createBaseVNode("li", null, [
                createVNode(_component_Badge, { type: "tip" }, {
                  default: withCtx(() => [
                    createTextVNode("default")
                  ]),
                  _: 1
                }),
                _hoisted_21,
                createTextVNode(" 根据区域设置偏好显示分组分隔符，这也可能取决于货币。")
              ]),
              _hoisted_22,
              _hoisted_23,
              _hoisted_24
            ])
          ]),
          createBaseVNode("li", null, [
            _hoisted_25,
            createTextVNode(" 格式化样式 "),
            createBaseVNode("ol", null, [
              createBaseVNode("li", null, [
                createVNode(_component_Badge, { type: "tip" }, {
                  default: withCtx(() => [
                    createTextVNode("default")
                  ]),
                  _: 1
                }),
                createTextVNode(),
                _hoisted_26,
                createTextVNode(" 用于纯数字格式")
              ]),
              _hoisted_27,
              _hoisted_28,
              _hoisted_29
            ])
          ]),
          _hoisted_30
        ])
      ])
    ]),
    _hoisted_32
  ]);
}
const toFixed = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  toFixed as default
};
