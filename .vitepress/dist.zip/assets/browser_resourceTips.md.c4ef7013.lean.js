import { _ as _export_sfc, H as resolveComponent, c as createElementBlock, L as createVNode, V as createStaticVNode, k as createBaseVNode, a as createTextVNode, o as openBlock } from "./chunks/framework.2dcfa116.js";
const __pageData = JSON.parse('{"title":"资源提示关键词","description":"","frontmatter":{},"headers":[],"relativePath":"browser/resourceTips.md","filePath":"browser/resourceTips.md"}');
const _sfc_main = { name: "browser/resourceTips.md" };
const _hoisted_1 = /* @__PURE__ */ createStaticVNode("", 6);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("浏览器一点一点地构建 "),
  /* @__PURE__ */ createBaseVNode("em", null, "DOM"),
  /* @__PURE__ */ createTextVNode("。一旦第一块代码进来，它就会开始解析 "),
  /* @__PURE__ */ createBaseVNode("em", null, "HTML"),
  /* @__PURE__ */ createTextVNode("，将节点添加到树结构中。")
], -1);
const _hoisted_8 = /* @__PURE__ */ createStaticVNode("", 2);
const _hoisted_10 = /* @__PURE__ */ createStaticVNode("", 2);
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("当浏览器正在构建 "),
  /* @__PURE__ */ createBaseVNode("em", null, "DOM"),
  /* @__PURE__ */ createTextVNode(" 时，如果它遇到 "),
  /* @__PURE__ */ createBaseVNode("em", null, "HTML"),
  /* @__PURE__ */ createTextVNode(" 中的 "),
  /* @__PURE__ */ createBaseVNode("code", null, "<script>...<\/script>"),
  /* @__PURE__ */ createTextVNode(" 标记，它必须立即执行它。如果脚本是外部的，则必须先下载脚本。")
], -1);
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("过去，为了执行脚本，必须暂停解析。解析会在 "),
  /* @__PURE__ */ createBaseVNode("em", null, "JavaScript"),
  /* @__PURE__ */ createTextVNode(" 引擎执行完脚本中的代码后再次启动。")
], -1);
const _hoisted_14 = /* @__PURE__ */ createStaticVNode("", 2);
const _hoisted_16 = /* @__PURE__ */ createStaticVNode("", 5);
const _hoisted_21 = /* @__PURE__ */ createStaticVNode("", 2);
const _hoisted_23 = /* @__PURE__ */ createStaticVNode("", 4);
const _hoisted_27 = /* @__PURE__ */ createStaticVNode("", 11);
const _hoisted_38 = /* @__PURE__ */ createStaticVNode("", 5);
const _hoisted_43 = /* @__PURE__ */ createStaticVNode("", 19);
const _hoisted_62 = /* @__PURE__ */ createStaticVNode("", 6);
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_PicViewer = resolveComponent("PicViewer");
  return openBlock(), createElementBlock("div", null, [
    _hoisted_1,
    createVNode(_component_PicViewer, {
      title: "解析器",
      src: "/assets/browser/resourceTips-1.jpg",
      alt: ""
    }),
    _hoisted_7,
    createVNode(_component_PicViewer, {
      title: "Dom对象构建",
      src: "/assets/browser/resourceTips-2.gif",
      alt: ""
    }),
    _hoisted_8,
    createVNode(_component_PicViewer, {
      title: "JS构建",
      src: "/assets/browser/resourceTips-3.gif",
      alt: ""
    }),
    _hoisted_10,
    createVNode(_component_PicViewer, {
      title: "CSSOM 构建",
      src: "/assets/browser/resourceTips-4.png",
      alt: ""
    }),
    _hoisted_12,
    _hoisted_13,
    createVNode(_component_PicViewer, {
      title: "解析停止",
      src: "/assets/browser/resourceTips-5.png",
      alt: ""
    }),
    _hoisted_14,
    createVNode(_component_PicViewer, {
      title: "js操作变更dom",
      src: "/assets/browser/resourceTips-6.gif",
      alt: ""
    }),
    _hoisted_16,
    createVNode(_component_PicViewer, {
      title: "JS操作对dom和cssom的影响",
      src: "/assets/browser/resourceTips-7.png",
      alt: ""
    }),
    _hoisted_21,
    createVNode(_component_PicViewer, {
      title: "遇到js要操作的css时等待css加载",
      src: "/assets/browser/resourceTips-8.png",
      alt: ""
    }),
    _hoisted_23,
    createVNode(_component_PicViewer, {
      title: "一个不舒服的加载页面过程",
      src: "/assets/browser/resourceTips-9.gif",
      alt: ""
    }),
    _hoisted_27,
    createVNode(_component_PicViewer, {
      title: "瀑布图",
      src: "/assets/browser/resourceTips-10.png",
      alt: ""
    }),
    _hoisted_38,
    createVNode(_component_PicViewer, {
      title: "预加载",
      src: "/assets/browser/resourceTips-11.png",
      alt: ""
    }),
    _hoisted_43,
    createVNode(_component_PicViewer, {
      title: "preconnect",
      src: "/assets/browser/resourceTips-12.png",
      alt: ""
    }),
    _hoisted_62
  ]);
}
const resourceTips = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  resourceTips as default
};
