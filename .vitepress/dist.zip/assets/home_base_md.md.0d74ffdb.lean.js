import { _ as _imports_0 } from "./chunks/logo.3ddce796.js";
import { _ as _export_sfc, H as resolveComponent, c as createElementBlock, k as createBaseVNode, a as createTextVNode, L as createVNode, w as withCtx, V as createStaticVNode, o as openBlock } from "./chunks/framework.2dcfa116.js";
const __pageData = JSON.parse('{"title":"markdown 语法","description":"","frontmatter":{},"headers":[],"relativePath":"home/base/md.md","filePath":"home/base/md.md"}');
const _sfc_main = { name: "home/base/md.md" };
const _hoisted_1 = /* @__PURE__ */ createStaticVNode("", 18);
const _hoisted_19 = {
  id: "infobadge",
  tabindex: "-1"
};
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("a", {
  class: "header-anchor",
  href: "#infobadge",
  "aria-label": 'Permalink to "info<Badge type="info">badge</Badge>"'
}, "​", -1);
const _hoisted_21 = /* @__PURE__ */ createStaticVNode("", 1);
const _hoisted_22 = {
  id: "tipbadge",
  tabindex: "-1"
};
const _hoisted_23 = /* @__PURE__ */ createBaseVNode("a", {
  class: "header-anchor",
  href: "#tipbadge",
  "aria-label": 'Permalink to "tip<Badge type="tip">badge</Badge>"'
}, "​", -1);
const _hoisted_24 = /* @__PURE__ */ createStaticVNode("", 1);
const _hoisted_25 = {
  id: "warningbadge",
  tabindex: "-1"
};
const _hoisted_26 = /* @__PURE__ */ createBaseVNode("a", {
  class: "header-anchor",
  href: "#warningbadge",
  "aria-label": 'Permalink to "warning<Badge type="warning">badge</Badge>"'
}, "​", -1);
const _hoisted_27 = /* @__PURE__ */ createStaticVNode("", 1);
const _hoisted_28 = {
  id: "dangerbadge",
  tabindex: "-1"
};
const _hoisted_29 = /* @__PURE__ */ createBaseVNode("a", {
  class: "header-anchor",
  href: "#dangerbadge",
  "aria-label": 'Permalink to "danger<Badge type="danger">badge</Badge>"'
}, "​", -1);
const _hoisted_30 = /* @__PURE__ */ createStaticVNode("", 26);
const _hoisted_56 = /* @__PURE__ */ createStaticVNode("", 34);
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_Badge = resolveComponent("Badge");
  const _component_PicViewer = resolveComponent("PicViewer");
  return openBlock(), createElementBlock("div", null, [
    _hoisted_1,
    createBaseVNode("h3", _hoisted_19, [
      createTextVNode("info"),
      createVNode(_component_Badge, { type: "info" }, {
        default: withCtx(() => [
          createTextVNode("badge")
        ]),
        _: 1
      }),
      createTextVNode(),
      _hoisted_20
    ]),
    _hoisted_21,
    createBaseVNode("h3", _hoisted_22, [
      createTextVNode("tip"),
      createVNode(_component_Badge, { type: "tip" }, {
        default: withCtx(() => [
          createTextVNode("badge")
        ]),
        _: 1
      }),
      createTextVNode(),
      _hoisted_23
    ]),
    _hoisted_24,
    createBaseVNode("h3", _hoisted_25, [
      createTextVNode("warning"),
      createVNode(_component_Badge, { type: "warning" }, {
        default: withCtx(() => [
          createTextVNode("badge")
        ]),
        _: 1
      }),
      createTextVNode(),
      _hoisted_26
    ]),
    _hoisted_27,
    createBaseVNode("h3", _hoisted_28, [
      createTextVNode("danger"),
      createVNode(_component_Badge, { type: "danger" }, {
        default: withCtx(() => [
          createTextVNode("badge")
        ]),
        _: 1
      }),
      createTextVNode(),
      _hoisted_29
    ]),
    _hoisted_30,
    createVNode(_component_PicViewer, {
      title: "这是头像",
      src: "/logo.png",
      alt: ""
    }),
    _hoisted_56
  ]);
}
const md = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  md as default
};
