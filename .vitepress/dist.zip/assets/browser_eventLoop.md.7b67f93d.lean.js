import { _ as _export_sfc, H as resolveComponent, c as createElementBlock, L as createVNode, V as createStaticVNode, k as createBaseVNode, a as createTextVNode, o as openBlock } from "./chunks/framework.2dcfa116.js";
const __pageData = JSON.parse('{"title":"事件循环","description":"","frontmatter":{},"headers":[],"relativePath":"browser/eventLoop.md","filePath":"browser/eventLoop.md"}');
const _sfc_main = { name: "browser/eventLoop.md" };
const _hoisted_1 = /* @__PURE__ */ createStaticVNode("", 13);
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("blockquote", null, [
  /* @__PURE__ */ createBaseVNode("p", null, "可以在浏览器的任务管理器中查看当前的所有进程")
], -1);
const _hoisted_15 = /* @__PURE__ */ createStaticVNode("", 10);
const _hoisted_25 = /* @__PURE__ */ createStaticVNode("", 8);
const _hoisted_33 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "渲染主线程承担着极其重要的工作，无论如何都不能阻塞！")
], -1);
const _hoisted_34 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("因此，浏览器选择"),
  /* @__PURE__ */ createBaseVNode("strong", null, "异步"),
  /* @__PURE__ */ createTextVNode("来解决这个问题")
], -1);
const _hoisted_35 = /* @__PURE__ */ createStaticVNode("", 24);
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_PicViewer = resolveComponent("PicViewer");
  return openBlock(), createElementBlock("div", null, [
    _hoisted_1,
    createVNode(_component_PicViewer, {
      title: "浏览器进程线程",
      src: "/assets/browser/eventLoop-1.jpg"
    }),
    _hoisted_14,
    createVNode(_component_PicViewer, {
      title: "控制台",
      src: "/assets/browser/eventLoop-2.jpg"
    }),
    _hoisted_15,
    createVNode(_component_PicViewer, {
      title: "任务队列排队",
      src: "/assets/browser/eventLoop-3.jpg",
      alt: ""
    }),
    _hoisted_25,
    createVNode(_component_PicViewer, {
      title: "阻塞情况展示",
      src: "/assets/browser/eventLoop-4.jpg",
      alt: ""
    }),
    _hoisted_33,
    _hoisted_34,
    createVNode(_component_PicViewer, {
      title: "异步处理",
      src: "/assets/browser/eventLoop-5.jpg",
      alt: ""
    }),
    _hoisted_35
  ]);
}
const eventLoop = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  eventLoop as default
};
