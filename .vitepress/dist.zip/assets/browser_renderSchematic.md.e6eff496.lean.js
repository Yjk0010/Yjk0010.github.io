import { _ as _export_sfc, H as resolveComponent, c as createElementBlock, L as createVNode, V as createStaticVNode, k as createBaseVNode, a as createTextVNode, o as openBlock } from "./chunks/framework.2dcfa116.js";
const __pageData = JSON.parse('{"title":"浏览器渲染原理","description":"","frontmatter":{},"headers":[],"relativePath":"browser/renderSchematic.md","filePath":"browser/renderSchematic.md"}');
const _sfc_main = { name: "browser/renderSchematic.md" };
const _hoisted_1 = /* @__PURE__ */ createStaticVNode("", 8);
const _hoisted_9 = /* @__PURE__ */ createStaticVNode("", 2);
const _hoisted_11 = /* @__PURE__ */ createStaticVNode("", 1);
const _hoisted_12 = /* @__PURE__ */ createStaticVNode("", 1);
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("h2", {
  id: "第二步-样式计算",
  tabindex: "-1"
}, [
  /* @__PURE__ */ createTextVNode("第二步 "),
  /* @__PURE__ */ createBaseVNode("strong", null, "样式计算"),
  /* @__PURE__ */ createTextVNode(),
  /* @__PURE__ */ createBaseVNode("a", {
    class: "header-anchor",
    href: "#第二步-样式计算",
    "aria-label": 'Permalink to "第二步 **样式计算**"'
  }, "​")
], -1);
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("blockquote", null, [
  /* @__PURE__ */ createBaseVNode("p", null, [
    /* @__PURE__ */ createTextVNode("完成后，会得到一棵带有样式的"),
    /* @__PURE__ */ createBaseVNode("code", null, "DOM"),
    /* @__PURE__ */ createTextVNode("树.")
  ])
], -1);
const _hoisted_15 = /* @__PURE__ */ createStaticVNode("", 4);
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("布局阶段会依次遍历"),
  /* @__PURE__ */ createBaseVNode("code", null, "DOM"),
  /* @__PURE__ */ createTextVNode("树的每一个节点，计算每个节点的几何信息. 例如节点的宽高、相对包含块的位置.")
], -1);
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("blockquote", null, [
  /* @__PURE__ */ createBaseVNode("p", null, [
    /* @__PURE__ */ createTextVNode("大部分时候，"),
    /* @__PURE__ */ createBaseVNode("code", null, "DOM"),
    /* @__PURE__ */ createTextVNode("树和布局树并非一一对应.")
  ])
], -1);
const _hoisted_21 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("code", null, "display:none"),
  /* @__PURE__ */ createTextVNode("的节点没有几何信息，因此不会生成到布局树")
], -1);
const _hoisted_22 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("使用了伪元素选择器，虽然"),
  /* @__PURE__ */ createBaseVNode("code", null, "DOM"),
  /* @__PURE__ */ createTextVNode("树中不存在这些伪元素节点，但它们拥有几何信息，所以会生成到布局树中.")
], -1);
const _hoisted_23 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("匿名行盒、匿名块盒等等都会导致"),
  /* @__PURE__ */ createBaseVNode("code", null, "DOM"),
  /* @__PURE__ */ createTextVNode("树和布局树无法一一对应.")
], -1);
const _hoisted_24 = /* @__PURE__ */ createBaseVNode("h2", {
  id: "第四步-分层",
  tabindex: "-1"
}, [
  /* @__PURE__ */ createTextVNode("第四步 "),
  /* @__PURE__ */ createBaseVNode("strong", null, "分层"),
  /* @__PURE__ */ createTextVNode(),
  /* @__PURE__ */ createBaseVNode("a", {
    class: "header-anchor",
    href: "#第四步-分层",
    "aria-label": 'Permalink to "第四步 **分层**"'
  }, "​")
], -1);
const _hoisted_25 = /* @__PURE__ */ createBaseVNode("blockquote", null, [
  /* @__PURE__ */ createBaseVNode("p", null, [
    /* @__PURE__ */ createTextVNode("这个在 chrome 控制台中 点击"),
    /* @__PURE__ */ createBaseVNode("span", { class: "cor-wa" }, "三个点 -> more tools -> Layers"),
    /* @__PURE__ */ createTextVNode("可以看到")
  ])
], -1);
const _hoisted_26 = /* @__PURE__ */ createStaticVNode("", 4);
const _hoisted_30 = /* @__PURE__ */ createBaseVNode("p", null, "主线程会为每个层单独产生绘制指令集，用于描述这一层的内容该如何画出来.", -1);
const _hoisted_31 = /* @__PURE__ */ createBaseVNode("p", null, "完成绘制后，主线程将每个图层的绘制信息提交给合成线程，剩余工作将由合成线程完成.", -1);
const _hoisted_32 = /* @__PURE__ */ createBaseVNode("h2", {
  id: "第六步-分块",
  tabindex: "-1"
}, [
  /* @__PURE__ */ createTextVNode("第六步 "),
  /* @__PURE__ */ createBaseVNode("strong", null, "分块"),
  /* @__PURE__ */ createTextVNode(),
  /* @__PURE__ */ createBaseVNode("a", {
    class: "header-anchor",
    href: "#第六步-分块",
    "aria-label": 'Permalink to "第六步 **分块**"'
  }, "​")
], -1);
const _hoisted_33 = /* @__PURE__ */ createBaseVNode("blockquote", null, [
  /* @__PURE__ */ createBaseVNode("p", null, "会优先绘制距离视口位置近(在视口内)的块")
], -1);
const _hoisted_34 = /* @__PURE__ */ createBaseVNode("p", null, "合成线程首先对每个图层进行分块，将其划分为更多的小区域.", -1);
const _hoisted_35 = /* @__PURE__ */ createBaseVNode("p", null, "它会从线程池中拿取多个线程来完成分块工作.", -1);
const _hoisted_36 = /* @__PURE__ */ createBaseVNode("h2", {
  id: "第七步-光栅化",
  tabindex: "-1"
}, [
  /* @__PURE__ */ createTextVNode("第七步 "),
  /* @__PURE__ */ createBaseVNode("strong", null, "光栅化"),
  /* @__PURE__ */ createTextVNode(),
  /* @__PURE__ */ createBaseVNode("a", {
    class: "header-anchor",
    href: "#第七步-光栅化",
    "aria-label": 'Permalink to "第七步 **光栅化**"'
  }, "​")
], -1);
const _hoisted_37 = /* @__PURE__ */ createBaseVNode("blockquote", null, [
  /* @__PURE__ */ createBaseVNode("p", null, "光栅化的结果，就是一块一块的位图")
], -1);
const _hoisted_38 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("合成线程会将块信息交给"),
  /* @__PURE__ */ createBaseVNode("code", null, "GPU"),
  /* @__PURE__ */ createTextVNode("进程，以极高的速度完成光栅化.")
], -1);
const _hoisted_39 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("code", null, "GPU"),
  /* @__PURE__ */ createTextVNode("进程会开启多个线程来完成光栅化，并且优先处理靠近视口区域的块.")
], -1);
const _hoisted_40 = /* @__PURE__ */ createBaseVNode("h2", {
  id: "第八步-画",
  tabindex: "-1"
}, [
  /* @__PURE__ */ createTextVNode("第八步 "),
  /* @__PURE__ */ createBaseVNode("strong", null, "画"),
  /* @__PURE__ */ createTextVNode(),
  /* @__PURE__ */ createBaseVNode("a", {
    class: "header-anchor",
    href: "#第八步-画",
    "aria-label": 'Permalink to "第八步 **画**"'
  }, "​")
], -1);
const _hoisted_41 = /* @__PURE__ */ createStaticVNode("", 6);
const _hoisted_47 = /* @__PURE__ */ createBaseVNode("h2", {
  id: "什么是-reflow",
  tabindex: "-1"
}, [
  /* @__PURE__ */ createTextVNode("什么是 reflow? "),
  /* @__PURE__ */ createBaseVNode("a", {
    class: "header-anchor",
    href: "#什么是-reflow",
    "aria-label": 'Permalink to "什么是 reflow?"'
  }, "​")
], -1);
const _hoisted_48 = /* @__PURE__ */ createBaseVNode("blockquote", null, [
  /* @__PURE__ */ createBaseVNode("p", null, "reflow 的本质就是重新计算 layout 树.")
], -1);
const _hoisted_49 = /* @__PURE__ */ createStaticVNode("", 6);
const _hoisted_55 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("当改动了可见样式后，就需要重新计算，会引发"),
  /* @__PURE__ */ createBaseVNode("code", null, "repaint"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_56 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("由于元素的布局信息也属于可见样式，所以"),
  /* @__PURE__ */ createBaseVNode("code", null, "reflow"),
  /* @__PURE__ */ createTextVNode("一定会引起"),
  /* @__PURE__ */ createBaseVNode("code", null, "repaint"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_57 = /* @__PURE__ */ createBaseVNode("h2", {
  id: "为什么-transform-的效率高",
  tabindex: "-1"
}, [
  /* @__PURE__ */ createTextVNode("为什么 transform 的效率高? "),
  /* @__PURE__ */ createBaseVNode("a", {
    class: "header-anchor",
    href: "#为什么-transform-的效率高",
    "aria-label": 'Permalink to "为什么 transform 的效率高?"'
  }, "​")
], -1);
const _hoisted_58 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("因为"),
  /* @__PURE__ */ createBaseVNode("code", null, "transform"),
  /* @__PURE__ */ createTextVNode("既不会影响布局也不会影响绘制指令，它影响的只是渲染流程的最后一个 "),
  /* @__PURE__ */ createBaseVNode("em", null, "draw"),
  /* @__PURE__ */ createTextVNode(" 阶段")
], -1);
const _hoisted_59 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("由于 draw 阶段在合成线程中，所以"),
  /* @__PURE__ */ createBaseVNode("code", null, "transform"),
  /* @__PURE__ */ createTextVNode("的变化几乎不会影响渲染主线程. 反之，渲染主线程无论如何忙碌，也不会影响"),
  /* @__PURE__ */ createBaseVNode("code", null, "transform"),
  /* @__PURE__ */ createTextVNode("的变化.")
], -1);
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_PicViewer = resolveComponent("PicViewer");
  return openBlock(), createElementBlock("div", null, [
    _hoisted_1,
    createVNode(_component_PicViewer, {
      title: "渲染流水线",
      src: "/assets/browser/render-1.jpg",
      alt: ""
    }),
    _hoisted_9,
    createVNode(_component_PicViewer, {
      title: "解析 HTML - Parse HTML",
      src: "/assets/browser/render-2.jpg",
      alt: "解析html"
    }),
    createVNode(_component_PicViewer, {
      title: "HTML 解析过程中遇到 CSS 代码怎么办? ",
      src: "/assets/browser/render-5.jpg",
      alt: "解析中遇到css"
    }),
    _hoisted_11,
    createVNode(_component_PicViewer, {
      title: "HTML 解析过程中遇到 JS 代码怎么办? ",
      src: "/assets/browser/render-6.jpg",
      alt: "解析过程中遇到 JS"
    }),
    _hoisted_12,
    createVNode(_component_PicViewer, {
      title: "解析 HTML | Document Object Model ",
      src: "/assets/browser/render-3.jpg",
      alt: ""
    }),
    createVNode(_component_PicViewer, {
      title: "解析 HTML | CSS Object Model ",
      src: "/assets/browser/render-4.jpg",
      alt: ""
    }),
    _hoisted_13,
    _hoisted_14,
    createVNode(_component_PicViewer, {
      title: "样式计算 - Recalculate Style",
      src: "/assets/browser/render-7.jpg",
      alt: ""
    }),
    _hoisted_15,
    createVNode(_component_PicViewer, {
      title: "布局 - Layout",
      src: "/assets/browser/render-8.jpg",
      alt: ""
    }),
    _hoisted_19,
    _hoisted_20,
    createVNode(_component_PicViewer, {
      title: "布局 | DOM 树 和 Layout 树",
      src: "/assets/browser/render-9.jpg",
      alt: "display:none"
    }),
    _hoisted_21,
    createVNode(_component_PicViewer, {
      title: "布局 | DOM 树 和 Layout 树",
      src: "/assets/browser/render-10.jpg",
      alt: "::before"
    }),
    _hoisted_22,
    createVNode(_component_PicViewer, {
      title: "布局 | DOM 树 和 Layout 树",
      src: "/assets/browser/render-11.jpg",
      alt: "匿名盒子"
    }),
    _hoisted_23,
    _hoisted_24,
    _hoisted_25,
    createVNode(_component_PicViewer, {
      title: "分层 - Layer",
      src: "/assets/browser/render-12.jpg",
      alt: ""
    }),
    _hoisted_26,
    createVNode(_component_PicViewer, {
      title: "绘制 - Paint",
      src: "/assets/browser/render-13.jpg",
      alt: ""
    }),
    _hoisted_30,
    createVNode(_component_PicViewer, {
      title: "绘制 | 合成线程",
      src: "/assets/browser/render-14.jpg",
      alt: ""
    }),
    _hoisted_31,
    _hoisted_32,
    _hoisted_33,
    createVNode(_component_PicViewer, {
      title: "分块 - Tiling",
      src: "/assets/browser/render-15.jpg",
      alt: ""
    }),
    _hoisted_34,
    createVNode(_component_PicViewer, {
      title: "分块 | 多个线程同时进⾏",
      src: "/assets/browser/render-16.jpg",
      alt: ""
    }),
    _hoisted_35,
    _hoisted_36,
    _hoisted_37,
    createVNode(_component_PicViewer, {
      title: "光栅化 - Raster",
      src: "/assets/browser/render-17.jpg",
      alt: ""
    }),
    _hoisted_38,
    createVNode(_component_PicViewer, {
      title: "光栅化 | GPU 加速",
      src: "/assets/browser/render-18.jpg",
      alt: ""
    }),
    _hoisted_39,
    _hoisted_40,
    createVNode(_component_PicViewer, {
      title: "画 - Draw",
      src: "/assets/browser/render-19.jpg",
      alt: ""
    }),
    _hoisted_41,
    createVNode(_component_PicViewer, {
      title: "完整过程",
      src: "/assets/browser/render-20.jpg",
      alt: ""
    }),
    _hoisted_47,
    _hoisted_48,
    createVNode(_component_PicViewer, {
      title: "什么是 reflow?",
      src: "/assets/browser/render-21.jpg",
      alt: ""
    }),
    _hoisted_49,
    createVNode(_component_PicViewer, {
      title: "什么是 repaint?",
      src: "/assets/browser/render-22.jpg",
      alt: ""
    }),
    _hoisted_55,
    _hoisted_56,
    _hoisted_57,
    createVNode(_component_PicViewer, {
      title: "为什么 transform 的效率高?",
      src: "/assets/browser/render-23.jpg",
      alt: ""
    }),
    _hoisted_58,
    createVNode(_component_PicViewer, {
      title: "draw 阶段",
      src: "/assets/browser/render-12.jpg",
      alt: ""
    }),
    _hoisted_59
  ]);
}
const renderSchematic = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  renderSchematic as default
};
