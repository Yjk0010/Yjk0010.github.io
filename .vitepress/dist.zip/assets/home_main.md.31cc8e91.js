import { _ as _export_sfc, c as createElementBlock, o as openBlock, V as createStaticVNode } from "./chunks/framework.2dcfa116.js";
const __pageData = JSON.parse('{"title":"(•̀ᴗ•́)و ̑̑","description":"","frontmatter":{},"headers":[],"relativePath":"home/main.md","filePath":"home/main.md"}');
const _sfc_main = { name: "home/main.md" };
const _hoisted_1 = /* @__PURE__ */ createStaticVNode('<h1 id="•ᴗ•-و" tabindex="-1">(•̀ᴗ•́)و ̑̑ <a class="header-anchor" href="#•ᴗ•-و" aria-label="Permalink to &quot;(•̀ᴗ•́)و ̑̑&quot;">​</a></h1><h2 id="欢迎同鞋" tabindex="-1">欢迎同鞋 <a class="header-anchor" href="#欢迎同鞋" aria-label="Permalink to &quot;欢迎同鞋&quot;">​</a></h2><p><code>欢迎来到我的博客！在这里，我会分享我对编程和技术的见解，并记录我在工作中遇到的问题和解决方案。我希望我的文章能够为那些刚入门的程序员提供一些启发和指导，同时也能够吸引那些有经验的开发者来分享他们的想法和经验。谢谢你的光临，希望你在这里能找到所需要的信息和灵感！</code></p><h2 id="该文档基于-vitepress-创建" tabindex="-1">该文档基于 vitepress 创建 <a class="header-anchor" href="#该文档基于-vitepress-创建" aria-label="Permalink to &quot;该文档基于 vitepress 创建&quot;">​</a></h2><ul><li><a href="https://vitepress.dev" target="_blank" rel="noreferrer">vitePress</a>文档</li></ul>', 5);
const _hoisted_6 = [
  _hoisted_1
];
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, _hoisted_6);
}
const main = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  main as default
};
