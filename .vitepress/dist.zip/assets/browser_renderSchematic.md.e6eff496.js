import { _ as _export_sfc, H as resolveComponent, c as createElementBlock, L as createVNode, V as createStaticVNode, k as createBaseVNode, a as createTextVNode, o as openBlock } from "./chunks/framework.2dcfa116.js";
const __pageData = JSON.parse('{"title":"浏览器渲染原理","description":"","frontmatter":{},"headers":[],"relativePath":"browser/renderSchematic.md","filePath":"browser/renderSchematic.md"}');
const _sfc_main = { name: "browser/renderSchematic.md" };
const _hoisted_1 = /* @__PURE__ */ createStaticVNode('<h1 id="浏览器渲染原理" tabindex="-1">浏览器渲染原理 <a class="header-anchor" href="#浏览器渲染原理" aria-label="Permalink to &quot;浏览器渲染原理&quot;">​</a></h1><h2 id="浏览器是如何渲染页面的" tabindex="-1">浏览器是如何渲染页面的? <a class="header-anchor" href="#浏览器是如何渲染页面的" aria-label="Permalink to &quot;浏览器是如何渲染页面的?&quot;">​</a></h2><p>当浏览器的<span class="cor-wa">网络线程</span>收到<code>HTML</code>文档后，会产生一个渲染任务，并将其传递给渲染主线程的消息队列.</p><p>在<span class="cor-tip">事件循环机制</span>的作用下，<span class="cor-tip">渲染主线程</span>取出<span class="cor-wa">消息队列</span>中的<span class="cor-in">渲染任务</span>，开启渲染流程.</p><p>整个渲染流程分为多个阶段</p><p>分别是：<span class="cor-da">HTML 解析、样式计算、布局、分层、绘制、分块、光栅化、画</span></p><p>每个阶段都有明确的输入输出，上一个阶段的输出会成为下一个阶段的输入.</p><p>这样，整个渲染流程就形成了一套组织严密的生产流水线.</p>', 8);
const _hoisted_9 = /* @__PURE__ */ createStaticVNode('<h2 id="第一步-解析-html" tabindex="-1">第一步 <strong>解析 HTML</strong> <a class="header-anchor" href="#第一步-解析-html" aria-label="Permalink to &quot;第一步 **解析 HTML**&quot;">​</a></h2><blockquote><p>完成后，会得到<code>DOM</code>树和<code>CSSOM</code>树，浏览器的<span class="cor-tip">默认样式</span>、<span class="cor-tip">内部样式</span>、<span class="cor-tip">外部样式</span>、<span class="cor-tip">行内样式</span>均会包含在 <em>CSSOM</em> 树中.</p></blockquote>', 2);
const _hoisted_11 = /* @__PURE__ */ createStaticVNode('<p><span class="cor-wa">解析过程中</span>遇到<code>CSS</code>解析<code>CSS</code>，遇到<code>JS</code>执行<code>JS</code>.<br> 为了提高解析效率，浏览器在<span class="cor-tip">开始解析前</span>，会启动一个<span class="cor-da">预解析的线程</span>，率先下载<code>HTML</code>中的外部<code>CSS</code>文件和 外部的<code>JS</code>文件.<br> 如果主线程解析到<code>link元素</code>位置，此时外部的<code>CSS</code>文件还没有下载解析好，主线程<span class="cor-da">不会等待</span>，<br> 继续解析后续的<code>HTML</code>. 这是因为下载和解析<code>CSS</code>的工作是在预解析线程中进行的. 这就是<code>CSS</code>不会阻塞<code>HTML</code>解析的根本原因.</p>', 1);
const _hoisted_12 = /* @__PURE__ */ createStaticVNode('<p>如果主线程解析到<code>script</code>位置，会停止解析<code>HTML</code>，转而等待<code>JS</code>文件下载好，并将全局代码解析执行完成后，才能继续解析<code>HTML</code>.<br> 这是因为 JS 代码的执行过程<span class="cor-wa">可能会</span>修改当前的<code>DOM</code>树，所以<code>DOM</code>树的生成<span class="cor-da">必须暂停</span>. 这就是<code>JS</code>会阻塞<code>HTML</code>解析的根本原因.</p>', 1);
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("h2", {
  id: "第二步-样式计算",
  tabindex: "-1"
}, [
  /* @__PURE__ */ createTextVNode("第二步 "),
  /* @__PURE__ */ createBaseVNode("strong", null, "样式计算"),
  /* @__PURE__ */ createTextVNode(),
  /* @__PURE__ */ createBaseVNode("a", {
    class: "header-anchor",
    href: "#第二步-样式计算",
    "aria-label": 'Permalink to "第二步 **样式计算**"'
  }, "​")
], -1);
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("blockquote", null, [
  /* @__PURE__ */ createBaseVNode("p", null, [
    /* @__PURE__ */ createTextVNode("完成后，会得到一棵带有样式的"),
    /* @__PURE__ */ createBaseVNode("code", null, "DOM"),
    /* @__PURE__ */ createTextVNode("树.")
  ])
], -1);
const _hoisted_15 = /* @__PURE__ */ createStaticVNode('<p>主线程会遍历得到的<code>DOM</code>树，依次为树中的每个节点计算出它最终的样式，称之为 <em>Computed Style</em>.</p><p>在这一过程中，很多预设值会变成绝对值，比如<code>red</code>会变成<code>rgb(255,0,0)</code>；相对单位会变成绝对单位，比如<code>em</code>会变成<code>px</code>.</p><h2 id="第三步-布局" tabindex="-1">第三步 <strong>布局</strong> <a class="header-anchor" href="#第三步-布局" aria-label="Permalink to &quot;第三步 **布局**&quot;">​</a></h2><blockquote><p>完成后得到布局树</p></blockquote>', 4);
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("布局阶段会依次遍历"),
  /* @__PURE__ */ createBaseVNode("code", null, "DOM"),
  /* @__PURE__ */ createTextVNode("树的每一个节点，计算每个节点的几何信息. 例如节点的宽高、相对包含块的位置.")
], -1);
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("blockquote", null, [
  /* @__PURE__ */ createBaseVNode("p", null, [
    /* @__PURE__ */ createTextVNode("大部分时候，"),
    /* @__PURE__ */ createBaseVNode("code", null, "DOM"),
    /* @__PURE__ */ createTextVNode("树和布局树并非一一对应.")
  ])
], -1);
const _hoisted_21 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("code", null, "display:none"),
  /* @__PURE__ */ createTextVNode("的节点没有几何信息，因此不会生成到布局树")
], -1);
const _hoisted_22 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("使用了伪元素选择器，虽然"),
  /* @__PURE__ */ createBaseVNode("code", null, "DOM"),
  /* @__PURE__ */ createTextVNode("树中不存在这些伪元素节点，但它们拥有几何信息，所以会生成到布局树中.")
], -1);
const _hoisted_23 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("匿名行盒、匿名块盒等等都会导致"),
  /* @__PURE__ */ createBaseVNode("code", null, "DOM"),
  /* @__PURE__ */ createTextVNode("树和布局树无法一一对应.")
], -1);
const _hoisted_24 = /* @__PURE__ */ createBaseVNode("h2", {
  id: "第四步-分层",
  tabindex: "-1"
}, [
  /* @__PURE__ */ createTextVNode("第四步 "),
  /* @__PURE__ */ createBaseVNode("strong", null, "分层"),
  /* @__PURE__ */ createTextVNode(),
  /* @__PURE__ */ createBaseVNode("a", {
    class: "header-anchor",
    href: "#第四步-分层",
    "aria-label": 'Permalink to "第四步 **分层**"'
  }, "​")
], -1);
const _hoisted_25 = /* @__PURE__ */ createBaseVNode("blockquote", null, [
  /* @__PURE__ */ createBaseVNode("p", null, [
    /* @__PURE__ */ createTextVNode("这个在 chrome 控制台中 点击"),
    /* @__PURE__ */ createBaseVNode("span", { class: "cor-wa" }, "三个点 -> more tools -> Layers"),
    /* @__PURE__ */ createTextVNode("可以看到")
  ])
], -1);
const _hoisted_26 = /* @__PURE__ */ createStaticVNode('<p>主线程会使用一套复杂的策略对整个布局树中进行分层.</p><p>分层的好处在于，将来某一个层改变后，仅会对该层进行后续处理，从而提升效率.</p><p><code>滚动条</code>、<code>堆叠上下文</code>、<code>transform</code>、<code>opacity</code>等样式都会或多或少的影响分层结果，也可以通过<code>will-change</code>属性更大程度的影响分层结果.</p><h2 id="第五步-绘制" tabindex="-1">第五步 <strong>绘制</strong> <a class="header-anchor" href="#第五步-绘制" aria-label="Permalink to &quot;第五步 **绘制**&quot;">​</a></h2>', 4);
const _hoisted_30 = /* @__PURE__ */ createBaseVNode("p", null, "主线程会为每个层单独产生绘制指令集，用于描述这一层的内容该如何画出来.", -1);
const _hoisted_31 = /* @__PURE__ */ createBaseVNode("p", null, "完成绘制后，主线程将每个图层的绘制信息提交给合成线程，剩余工作将由合成线程完成.", -1);
const _hoisted_32 = /* @__PURE__ */ createBaseVNode("h2", {
  id: "第六步-分块",
  tabindex: "-1"
}, [
  /* @__PURE__ */ createTextVNode("第六步 "),
  /* @__PURE__ */ createBaseVNode("strong", null, "分块"),
  /* @__PURE__ */ createTextVNode(),
  /* @__PURE__ */ createBaseVNode("a", {
    class: "header-anchor",
    href: "#第六步-分块",
    "aria-label": 'Permalink to "第六步 **分块**"'
  }, "​")
], -1);
const _hoisted_33 = /* @__PURE__ */ createBaseVNode("blockquote", null, [
  /* @__PURE__ */ createBaseVNode("p", null, "会优先绘制距离视口位置近(在视口内)的块")
], -1);
const _hoisted_34 = /* @__PURE__ */ createBaseVNode("p", null, "合成线程首先对每个图层进行分块，将其划分为更多的小区域.", -1);
const _hoisted_35 = /* @__PURE__ */ createBaseVNode("p", null, "它会从线程池中拿取多个线程来完成分块工作.", -1);
const _hoisted_36 = /* @__PURE__ */ createBaseVNode("h2", {
  id: "第七步-光栅化",
  tabindex: "-1"
}, [
  /* @__PURE__ */ createTextVNode("第七步 "),
  /* @__PURE__ */ createBaseVNode("strong", null, "光栅化"),
  /* @__PURE__ */ createTextVNode(),
  /* @__PURE__ */ createBaseVNode("a", {
    class: "header-anchor",
    href: "#第七步-光栅化",
    "aria-label": 'Permalink to "第七步 **光栅化**"'
  }, "​")
], -1);
const _hoisted_37 = /* @__PURE__ */ createBaseVNode("blockquote", null, [
  /* @__PURE__ */ createBaseVNode("p", null, "光栅化的结果，就是一块一块的位图")
], -1);
const _hoisted_38 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("合成线程会将块信息交给"),
  /* @__PURE__ */ createBaseVNode("code", null, "GPU"),
  /* @__PURE__ */ createTextVNode("进程，以极高的速度完成光栅化.")
], -1);
const _hoisted_39 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("code", null, "GPU"),
  /* @__PURE__ */ createTextVNode("进程会开启多个线程来完成光栅化，并且优先处理靠近视口区域的块.")
], -1);
const _hoisted_40 = /* @__PURE__ */ createBaseVNode("h2", {
  id: "第八步-画",
  tabindex: "-1"
}, [
  /* @__PURE__ */ createTextVNode("第八步 "),
  /* @__PURE__ */ createBaseVNode("strong", null, "画"),
  /* @__PURE__ */ createTextVNode(),
  /* @__PURE__ */ createBaseVNode("a", {
    class: "header-anchor",
    href: "#第八步-画",
    "aria-label": 'Permalink to "第八步 **画**"'
  }, "​")
], -1);
const _hoisted_41 = /* @__PURE__ */ createStaticVNode('<p>合成线程拿到每个层、每个块的位图后，生成一个个 <em>指引(quad)</em> 信息.</p><p>指引会标识出每个位图应该画到屏幕的哪个位置，以及会考虑到旋转、缩放等变形.</p><p>变形发生在合成线程，与渲染主线程无关，这就是<code>transform</code>效率高的本质原因.</p><p>合成线程会把<code>quad</code>提交给<code>GPU</code>进程，由<code>GPU</code>进程产生系统调用，提交给<code>GPU</code>硬件，完成最终的屏幕成像.</p><h2 id="完整过程" tabindex="-1">完整过程 <a class="header-anchor" href="#完整过程" aria-label="Permalink to &quot;完整过程&quot;">​</a></h2><blockquote><p>这个过程是一只在不停重复的 比如说滚动了一滚动条 会重新触发<code>paint</code>重新绘制</p></blockquote>', 6);
const _hoisted_47 = /* @__PURE__ */ createBaseVNode("h2", {
  id: "什么是-reflow",
  tabindex: "-1"
}, [
  /* @__PURE__ */ createTextVNode("什么是 reflow? "),
  /* @__PURE__ */ createBaseVNode("a", {
    class: "header-anchor",
    href: "#什么是-reflow",
    "aria-label": 'Permalink to "什么是 reflow?"'
  }, "​")
], -1);
const _hoisted_48 = /* @__PURE__ */ createBaseVNode("blockquote", null, [
  /* @__PURE__ */ createBaseVNode("p", null, "reflow 的本质就是重新计算 layout 树.")
], -1);
const _hoisted_49 = /* @__PURE__ */ createStaticVNode('<p>当进行了会影响布局树的操作后，需要重新计算布局树，会引发<code>layout</code>.</p><p>为了避免连续的多次操作导致布局树反复计算，浏览器会合并这些操作，当 JS 代码全部完成后再进行统一计算. 所以，改动属性造成的<code>reflow</code>是异步完成的.</p><p>也同样因为如此，当<code>JS</code>获取布局属性时，就可能造成无法获取到最新的布局信息.</p><p>浏览器在反复权衡下，最终决定获取属性立即<code>reflow</code>.</p><h2 id="什么是-repaint" tabindex="-1">什么是 repaint? <a class="header-anchor" href="#什么是-repaint" aria-label="Permalink to &quot;什么是 repaint?&quot;">​</a></h2><blockquote><p>repaint 的本质就是重新根据分层信息计算了绘制指令.</p></blockquote>', 6);
const _hoisted_55 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("当改动了可见样式后，就需要重新计算，会引发"),
  /* @__PURE__ */ createBaseVNode("code", null, "repaint"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_56 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("由于元素的布局信息也属于可见样式，所以"),
  /* @__PURE__ */ createBaseVNode("code", null, "reflow"),
  /* @__PURE__ */ createTextVNode("一定会引起"),
  /* @__PURE__ */ createBaseVNode("code", null, "repaint"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_57 = /* @__PURE__ */ createBaseVNode("h2", {
  id: "为什么-transform-的效率高",
  tabindex: "-1"
}, [
  /* @__PURE__ */ createTextVNode("为什么 transform 的效率高? "),
  /* @__PURE__ */ createBaseVNode("a", {
    class: "header-anchor",
    href: "#为什么-transform-的效率高",
    "aria-label": 'Permalink to "为什么 transform 的效率高?"'
  }, "​")
], -1);
const _hoisted_58 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("因为"),
  /* @__PURE__ */ createBaseVNode("code", null, "transform"),
  /* @__PURE__ */ createTextVNode("既不会影响布局也不会影响绘制指令，它影响的只是渲染流程的最后一个 "),
  /* @__PURE__ */ createBaseVNode("em", null, "draw"),
  /* @__PURE__ */ createTextVNode(" 阶段")
], -1);
const _hoisted_59 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("由于 draw 阶段在合成线程中，所以"),
  /* @__PURE__ */ createBaseVNode("code", null, "transform"),
  /* @__PURE__ */ createTextVNode("的变化几乎不会影响渲染主线程. 反之，渲染主线程无论如何忙碌，也不会影响"),
  /* @__PURE__ */ createBaseVNode("code", null, "transform"),
  /* @__PURE__ */ createTextVNode("的变化.")
], -1);
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_PicViewer = resolveComponent("PicViewer");
  return openBlock(), createElementBlock("div", null, [
    _hoisted_1,
    createVNode(_component_PicViewer, {
      title: "渲染流水线",
      src: "/assets/browser/render-1.jpg",
      alt: ""
    }),
    _hoisted_9,
    createVNode(_component_PicViewer, {
      title: "解析 HTML - Parse HTML",
      src: "/assets/browser/render-2.jpg",
      alt: "解析html"
    }),
    createVNode(_component_PicViewer, {
      title: "HTML 解析过程中遇到 CSS 代码怎么办? ",
      src: "/assets/browser/render-5.jpg",
      alt: "解析中遇到css"
    }),
    _hoisted_11,
    createVNode(_component_PicViewer, {
      title: "HTML 解析过程中遇到 JS 代码怎么办? ",
      src: "/assets/browser/render-6.jpg",
      alt: "解析过程中遇到 JS"
    }),
    _hoisted_12,
    createVNode(_component_PicViewer, {
      title: "解析 HTML | Document Object Model ",
      src: "/assets/browser/render-3.jpg",
      alt: ""
    }),
    createVNode(_component_PicViewer, {
      title: "解析 HTML | CSS Object Model ",
      src: "/assets/browser/render-4.jpg",
      alt: ""
    }),
    _hoisted_13,
    _hoisted_14,
    createVNode(_component_PicViewer, {
      title: "样式计算 - Recalculate Style",
      src: "/assets/browser/render-7.jpg",
      alt: ""
    }),
    _hoisted_15,
    createVNode(_component_PicViewer, {
      title: "布局 - Layout",
      src: "/assets/browser/render-8.jpg",
      alt: ""
    }),
    _hoisted_19,
    _hoisted_20,
    createVNode(_component_PicViewer, {
      title: "布局 | DOM 树 和 Layout 树",
      src: "/assets/browser/render-9.jpg",
      alt: "display:none"
    }),
    _hoisted_21,
    createVNode(_component_PicViewer, {
      title: "布局 | DOM 树 和 Layout 树",
      src: "/assets/browser/render-10.jpg",
      alt: "::before"
    }),
    _hoisted_22,
    createVNode(_component_PicViewer, {
      title: "布局 | DOM 树 和 Layout 树",
      src: "/assets/browser/render-11.jpg",
      alt: "匿名盒子"
    }),
    _hoisted_23,
    _hoisted_24,
    _hoisted_25,
    createVNode(_component_PicViewer, {
      title: "分层 - Layer",
      src: "/assets/browser/render-12.jpg",
      alt: ""
    }),
    _hoisted_26,
    createVNode(_component_PicViewer, {
      title: "绘制 - Paint",
      src: "/assets/browser/render-13.jpg",
      alt: ""
    }),
    _hoisted_30,
    createVNode(_component_PicViewer, {
      title: "绘制 | 合成线程",
      src: "/assets/browser/render-14.jpg",
      alt: ""
    }),
    _hoisted_31,
    _hoisted_32,
    _hoisted_33,
    createVNode(_component_PicViewer, {
      title: "分块 - Tiling",
      src: "/assets/browser/render-15.jpg",
      alt: ""
    }),
    _hoisted_34,
    createVNode(_component_PicViewer, {
      title: "分块 | 多个线程同时进⾏",
      src: "/assets/browser/render-16.jpg",
      alt: ""
    }),
    _hoisted_35,
    _hoisted_36,
    _hoisted_37,
    createVNode(_component_PicViewer, {
      title: "光栅化 - Raster",
      src: "/assets/browser/render-17.jpg",
      alt: ""
    }),
    _hoisted_38,
    createVNode(_component_PicViewer, {
      title: "光栅化 | GPU 加速",
      src: "/assets/browser/render-18.jpg",
      alt: ""
    }),
    _hoisted_39,
    _hoisted_40,
    createVNode(_component_PicViewer, {
      title: "画 - Draw",
      src: "/assets/browser/render-19.jpg",
      alt: ""
    }),
    _hoisted_41,
    createVNode(_component_PicViewer, {
      title: "完整过程",
      src: "/assets/browser/render-20.jpg",
      alt: ""
    }),
    _hoisted_47,
    _hoisted_48,
    createVNode(_component_PicViewer, {
      title: "什么是 reflow?",
      src: "/assets/browser/render-21.jpg",
      alt: ""
    }),
    _hoisted_49,
    createVNode(_component_PicViewer, {
      title: "什么是 repaint?",
      src: "/assets/browser/render-22.jpg",
      alt: ""
    }),
    _hoisted_55,
    _hoisted_56,
    _hoisted_57,
    createVNode(_component_PicViewer, {
      title: "为什么 transform 的效率高?",
      src: "/assets/browser/render-23.jpg",
      alt: ""
    }),
    _hoisted_58,
    createVNode(_component_PicViewer, {
      title: "draw 阶段",
      src: "/assets/browser/render-12.jpg",
      alt: ""
    }),
    _hoisted_59
  ]);
}
const renderSchematic = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  renderSchematic as default
};
