import { _ as _export_sfc, c as createElementBlock, o as openBlock, V as createStaticVNode } from "./chunks/framework.2dcfa116.js";
const __pageData = JSON.parse('{"title":"a 元素","description":"","frontmatter":{},"headers":[],"relativePath":"html/element/eleA.md","filePath":"html/element/eleA.md"}');
const _sfc_main = { name: "html/element/eleA.md" };
const _hoisted_1 = /* @__PURE__ */ createStaticVNode("", 21);
const _hoisted_22 = [
  _hoisted_1
];
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, _hoisted_22);
}
const eleA = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  eleA as default
};
