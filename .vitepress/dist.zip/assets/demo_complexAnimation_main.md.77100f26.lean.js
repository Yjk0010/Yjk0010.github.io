import { d as defineComponent, h as ref, g as computed, o as openBlock, c as createElementBlock, k as createBaseVNode, U as normalizeStyle, a7 as withDirectives, aa as vModelText, t as toDisplayString, p as pushScopeId, m as popScopeId, _ as _export_sfc, L as createVNode, a as createTextVNode, V as createStaticVNode } from "./chunks/framework.2dcfa116.js";
const _withScopeId = (n) => (pushScopeId("data-v-77bee32f"), n = n(), popScopeId(), n);
const _hoisted_1$1 = /* @__PURE__ */ _withScopeId(() => /* @__PURE__ */ createBaseVNode("div", { class: "block" }, null, -1));
const _hoisted_2$1 = /* @__PURE__ */ _withScopeId(() => /* @__PURE__ */ createBaseVNode("div", { class: "face" }, [
  /* @__PURE__ */ createBaseVNode("div", { class: "eye left animate" }),
  /* @__PURE__ */ createBaseVNode("div", { class: "eye right animate" }),
  /* @__PURE__ */ createBaseVNode("div", { class: "mouse animate" })
], -1));
const _hoisted_3$1 = /* @__PURE__ */ _withScopeId(() => /* @__PURE__ */ createBaseVNode("div", { class: "title" }, "来划一划试试", -1));
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "index",
  setup(__props) {
    const sliderValue = ref(0.5);
    const style = computed(() => {
      return {
        "--progress": sliderValue.value
      };
    });
    let prev = 0;
    const isAnimateReverse = ref(false);
    const rangeInput = (e) => {
      if (prev > sliderValue.value) {
        isAnimateReverse.value = true;
      } else {
        isAnimateReverse.value = false;
      }
      prev = sliderValue.value;
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: "complexAnimation",
        style: normalizeStyle(style.value)
      }, [
        _hoisted_1$1,
        createBaseVNode("div", {
          class: "ball animate",
          style: normalizeStyle({
            animationName: isAnimateReverse.value ? "ballMoveReverse" : "ballMove"
          })
        }, null, 4),
        _hoisted_2$1,
        withDirectives(createBaseVNode("input", {
          type: "range",
          class: "range",
          min: "0",
          max: "1",
          step: "0.01",
          "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => sliderValue.value = $event),
          onInput: rangeInput
        }, null, 544), [
          [vModelText, sliderValue.value]
        ]),
        _hoisted_3$1,
        createBaseVNode("div", null, toDisplayString(sliderValue.value), 1)
      ], 4);
    };
  }
});
const index_vue_vue_type_style_index_0_lang = "";
const index_vue_vue_type_style_index_1_scoped_77bee32f_lang = "";
const demo = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-77bee32f"]]);
const _hoisted_1 = /* @__PURE__ */ createBaseVNode("h1", {
  id: "复杂动画控制",
  tabindex: "-1"
}, [
  /* @__PURE__ */ createTextVNode("复杂动画控制 "),
  /* @__PURE__ */ createBaseVNode("a", {
    class: "header-anchor",
    href: "#复杂动画控制",
    "aria-label": 'Permalink to "复杂动画控制"'
  }, "​")
], -1);
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("h2", {
  id: "展示",
  tabindex: "-1"
}, [
  /* @__PURE__ */ createTextVNode("展示 "),
  /* @__PURE__ */ createBaseVNode("a", {
    class: "header-anchor",
    href: "#展示",
    "aria-label": 'Permalink to "展示"'
  }, "​")
], -1);
const _hoisted_3 = /* @__PURE__ */ createStaticVNode("", 3);
const __pageData = JSON.parse('{"title":"复杂动画控制","description":"","frontmatter":{},"headers":[],"relativePath":"demo/complexAnimation/main.md","filePath":"demo/complexAnimation/main.md"}');
const __default__ = { name: "demo/complexAnimation/main.md" };
const _sfc_main = /* @__PURE__ */ Object.assign(__default__, {
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", null, [
        _hoisted_1,
        _hoisted_2,
        createVNode(demo),
        _hoisted_3
      ]);
    };
  }
});
export {
  __pageData,
  _sfc_main as default
};
