import { _ as _export_sfc, H as resolveComponent, c as createElementBlock, k as createBaseVNode, L as createVNode, w as withCtx, a as createTextVNode, V as createStaticVNode, o as openBlock } from "./chunks/framework.2dcfa116.js";
const __pageData = JSON.parse('{"title":"JAVASCRIPT","description":"","frontmatter":{},"headers":[],"relativePath":"js/main.md","filePath":"js/main.md"}');
const _sfc_main = { name: "js/main.md" };
const _hoisted_1 = /* @__PURE__ */ createBaseVNode("h1", {
  id: "javascript",
  tabindex: "-1"
}, [
  /* @__PURE__ */ createTextVNode("JAVASCRIPT "),
  /* @__PURE__ */ createBaseVNode("a", {
    class: "header-anchor",
    href: "#javascript",
    "aria-label": 'Permalink to "JAVASCRIPT"'
  }, "​")
], -1);
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("h2", {
  id: "起源",
  tabindex: "-1"
}, [
  /* @__PURE__ */ createTextVNode("起源 "),
  /* @__PURE__ */ createBaseVNode("a", {
    class: "header-anchor",
    href: "#起源",
    "aria-label": 'Permalink to "起源"'
  }, "​")
], -1);
const _hoisted_3 = /* @__PURE__ */ createBaseVNode("span", { class: "cor-wa" }, "1994 年", -1);
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("em", null, "网景 (Netscape Communication Corperation)", -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("code", null, "网景浏览器 (Netscape Navigator)", -1);
const _hoisted_6 = /* @__PURE__ */ createStaticVNode("", 23);
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_Badge = resolveComponent("Badge");
  return openBlock(), createElementBlock("div", null, [
    _hoisted_1,
    _hoisted_2,
    createBaseVNode("p", null, [
      _hoisted_3,
      createVNode(_component_Badge, { type: "tip" }, {
        default: withCtx(() => [
          createTextVNode("跟我一样大")
        ]),
        _: 1
      }),
      createTextVNode(),
      _hoisted_4,
      createTextVNode(" 推出第一款商用浏览器, "),
      _hoisted_5
    ]),
    _hoisted_6
  ]);
}
const main = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  main as default
};
