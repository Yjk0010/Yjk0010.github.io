const scenery2 = "/assets/scenery-2.82390c47.jpg";
export {
  scenery2 as default
};
