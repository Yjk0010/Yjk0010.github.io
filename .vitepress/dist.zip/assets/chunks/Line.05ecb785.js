import { d as defineComponent, g as computed, o as openBlock, c as createElementBlock, t as toDisplayString, e as createCommentVNode, k as createBaseVNode, U as normalizeStyle, _ as _export_sfc } from "./framework.2dcfa116.js";
const _hoisted_1 = { class: "line" };
const _hoisted_2 = {
  key: 0,
  class: "line-text line-left"
};
const _hoisted_3 = {
  key: 1,
  class: "line-text line-center"
};
const _hoisted_4 = {
  key: 2,
  class: "line-text line-right"
};
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Line",
  props: {
    title: { default: "" },
    position: { default: "left" },
    lineWidth: { default: 1 },
    color: { default: "rgb(220, 220, 220)" },
    lineStyle: { default: "solid" }
  },
  setup(__props) {
    const props = __props;
    const computedLineStyle = computed(() => {
      return {
        flex: 1,
        borderTop: `${props.lineWidth}px ${props.lineStyle} ${props.color}`
      };
    });
    const isShow = (position) => {
      const positionArray = Array.isArray(props.position) ? props.position : [props.position];
      return positionArray.includes(position);
    };
    const viewTitle = (position) => {
      const titleArray = Array.isArray(props.title) ? props.title : [props.title];
      const positionArray = Array.isArray(props.position) ? props.position : [props.position];
      return titleArray[Math.min(titleArray.length - 1, positionArray.indexOf(position))];
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1, [
        isShow("left") ? (openBlock(), createElementBlock("div", _hoisted_2, toDisplayString(viewTitle("left")), 1)) : createCommentVNode("", true),
        createBaseVNode("div", {
          class: "line-online",
          style: normalizeStyle(computedLineStyle.value)
        }, null, 4),
        isShow("center") ? (openBlock(), createElementBlock("div", _hoisted_3, toDisplayString(viewTitle("center")), 1)) : createCommentVNode("", true),
        createBaseVNode("div", {
          class: "line-online",
          style: normalizeStyle(computedLineStyle.value)
        }, null, 4),
        isShow("right") ? (openBlock(), createElementBlock("div", _hoisted_4, toDisplayString(viewTitle("right")), 1)) : createCommentVNode("", true)
      ]);
    };
  }
});
const Line_vue_vue_type_style_index_0_scoped_06307de4_lang = "";
const Line = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-06307de4"]]);
export {
  Line as L
};
