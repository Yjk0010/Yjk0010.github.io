import { d as defineComponent, u as useData, h as ref, g as computed, j as onMounted, G as onUnmounted, o as openBlock, c as createElementBlock, b as createBlock, e as createCommentVNode, k as createBaseVNode, t as toDisplayString, a7 as withDirectives, a8 as vShow, U as normalizeStyle, a3 as withModifiers, E as nextTick, p as pushScopeId, m as popScopeId, a as createTextVNode, _ as _export_sfc } from "./framework.2dcfa116.js";
import { L as Line } from "./Line.05ecb785.js";
const _withScopeId = (n) => (pushScopeId("data-v-47ccc620"), n = n(), popScopeId(), n);
const _hoisted_1 = { class: "pic-viewer" };
const _hoisted_2 = ["src", "alt"];
const _hoisted_3 = { class: "pic-viewer-title" };
const _hoisted_4 = /* @__PURE__ */ _withScopeId(() => /* @__PURE__ */ createBaseVNode("div", { class: "pic-viewer-box-info" }, [
  /* @__PURE__ */ createTextVNode(" 鼠标滚轮可缩放 "),
  /* @__PURE__ */ createBaseVNode("br"),
  /* @__PURE__ */ createTextVNode(" 选中图片可拖拽 "),
  /* @__PURE__ */ createBaseVNode("br"),
  /* @__PURE__ */ createTextVNode(" 点击非图片区域(键盘Esc)关闭 ")
], -1));
const _hoisted_5 = ["src", "alt"];
const proportion = 0.75;
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "PicViewer",
  props: {
    title: { default: "" },
    src: { default: "" },
    darkSrc: { default: "" },
    alt: { default: "" }
  },
  setup(__props) {
    const props = __props;
    const { isDark } = useData();
    const isBoxShow = ref(false);
    const scale = ref(1);
    const left = ref(0);
    const top = ref(0);
    const image = ref(null);
    const viewerBox = ref(null);
    let multiple = 0;
    const imgSrc = computed(() => {
      return isDark.value ? props.darkSrc || props.src : props.src;
    });
    const handleShowBox = () => {
      isBoxShow.value = !isBoxShow.value;
    };
    const boxShow = () => {
      isBoxShow.value = true;
      scale.value = 1;
      nextTick(() => {
        var _a, _b;
        const { width: viewerBoxWidth, height: viewerBoxHeight } = ((_a = viewerBox.value) == null ? void 0 : _a.getBoundingClientRect()) || {
          width: 0,
          height: 0
        };
        const { width: imageWidth, height: imageHeight } = ((_b = image.value) == null ? void 0 : _b.getBoundingClientRect()) || {
          width: 0,
          height: 0
        };
        const scaleWithValue = viewerBoxWidth * proportion / imageWidth;
        const scaleHeightValue = viewerBoxHeight * proportion / imageHeight;
        multiple = +Math.min(scaleWithValue, scaleHeightValue).toFixed(2);
        scale.value = multiple;
        left.value = (viewerBoxWidth - imageWidth) / 2;
        top.value = (viewerBoxHeight - imageHeight) / 2;
      });
    };
    const handleScale = (wheel) => {
      if (wheel > 0) {
        scale.value = Math.max(0.2, scale.value - multiple / 5);
      } else {
        scale.value = Math.min(5, scale.value + multiple / 5);
      }
    };
    const handleBoxWheel = (e) => {
      e.preventDefault();
      handleScale(e.deltaY);
    };
    const handleWheel = (e) => {
      e.preventDefault();
      handleScale(e.deltaY);
    };
    const handleKeydown = (e) => {
      if (e.key === "Escape") {
        isBoxShow.value = false;
      }
    };
    onMounted(() => {
      window.addEventListener("keydown", handleKeydown);
    });
    onUnmounted(() => {
      window.removeEventListener("keydown", handleKeydown);
    });
    const useDragBox = () => {
      const isDragging2 = ref(false);
      const startPosition2 = { x: 0, y: 0 };
      const startOffset2 = { x: 0, y: 0 };
      let lastTimestamp = 0;
      const dragging2 = (event) => {
        if (!isDragging2.value)
          return;
        requestAnimationFrame((timestamp) => {
          if (timestamp - lastTimestamp < 16)
            return;
          lastTimestamp = timestamp;
          left.value = startOffset2.x + event.pageX - startPosition2.x;
          top.value = startOffset2.y + event.pageY - startPosition2.y;
        });
      };
      const stopDrag2 = () => {
        isDragging2.value = false;
      };
      return {
        isDragging: isDragging2,
        startPosition: startPosition2,
        startOffset: startOffset2,
        dragging: dragging2,
        stopDrag: stopDrag2
      };
    };
    const { isDragging, startPosition, startOffset, dragging, stopDrag } = useDragBox();
    onMounted(() => {
      document.addEventListener("mousemove", dragging);
      document.addEventListener("mouseup", stopDrag);
    });
    onUnmounted(() => {
      document.removeEventListener("mousemove", dragging);
      document.removeEventListener("mouseup", stopDrag);
    });
    const startDrag = (e) => {
      e.preventDefault();
      e.stopPropagation();
      isDragging.value = true;
      startPosition.x = e.pageX;
      startPosition.y = e.pageY;
      startOffset.x = left.value;
      startOffset.y = top.value;
      console.log(startPosition, startOffset);
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1, [
        _ctx.title ? (openBlock(), createBlock(Line, {
          key: 0,
          position: "center",
          title: _ctx.title
        }, null, 8, ["title"])) : createCommentVNode("", true),
        createBaseVNode("img", {
          class: "pic-viewer-img",
          onClick: boxShow,
          src: imgSrc.value,
          alt: _ctx.alt || `这张图片害羞了`
        }, null, 8, _hoisted_2),
        createBaseVNode("div", _hoisted_3, toDisplayString(_ctx.alt || _ctx.title), 1),
        withDirectives(createBaseVNode("div", {
          class: "pic-viewer-box",
          onClick: handleShowBox,
          onMousewheel: handleBoxWheel,
          ref_key: "viewerBox",
          ref: viewerBox
        }, [
          _hoisted_4,
          createBaseVNode("img", {
            class: "pic-viewer-box-img",
            ref_key: "image",
            ref: image,
            style: normalizeStyle({
              transform: `scale(${scale.value})`,
              left: `${left.value}px`,
              top: `${top.value}px`
            }),
            onClick: _cache[0] || (_cache[0] = withModifiers(() => {
            }, ["stop"])),
            onMousewheel: handleWheel,
            onMousedown: startDrag,
            src: imgSrc.value,
            alt: _ctx.alt
          }, null, 44, _hoisted_5)
        ], 544), [
          [vShow, isBoxShow.value]
        ])
      ]);
    };
  }
});
const PicViewer_vue_vue_type_style_index_0_scoped_47ccc620_lang = "";
const PicViewer = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-47ccc620"]]);
export {
  PicViewer as P
};
