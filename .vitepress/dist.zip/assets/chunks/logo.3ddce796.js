const _imports_0 = "/logo.png";
export {
  _imports_0 as _
};
