const getRandomNum = (min, max) => {
  return Math.floor(Math.random() * (max - min + 1) + min);
};
const diffDate = (prevDate, nextDate) => {
  const diffYears = prevDate.getFullYear() - nextDate.getFullYear();
  const diffMonths = prevDate.getMonth() - nextDate.getMonth() + diffYears * 12;
  let prevTime = prevDate.getTime();
  let nextTime = nextDate.getTime();
  const diffDays = Math.trunc((prevTime - nextTime) / 1e3 / 60 / 60 / 24);
  return {
    years: diffYears,
    months: diffMonths,
    days: diffDays
  };
};
export {
  diffDate as d,
  getRandomNum as g
};
