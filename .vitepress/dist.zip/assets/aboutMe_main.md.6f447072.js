import { _ as _export_sfc, c as createElementBlock, o as openBlock, V as createStaticVNode } from "./chunks/framework.2dcfa116.js";
const __pageData = JSON.parse('{"title":"关于我","description":"","frontmatter":{},"headers":[],"relativePath":"aboutMe/main.md","filePath":"aboutMe/main.md"}');
const _sfc_main = { name: "aboutMe/main.md" };
const _hoisted_1 = /* @__PURE__ */ createStaticVNode('<h1 id="关于我" tabindex="-1">关于我 <a class="header-anchor" href="#关于我" aria-label="Permalink to &quot;关于我&quot;">​</a></h1><details class="details custom-block"><summary>点开看吧</summary><h2 id="唱歌还不错的台球开光师" tabindex="-1"><span class="cor-tip">唱歌还不错</span>的<strong>台球开光师</strong> <a class="header-anchor" href="#唱歌还不错的台球开光师" aria-label="Permalink to &quot;&lt;span class=&quot;cor-tip&quot;&gt;唱歌还不错&lt;/span&gt;的**台球开光师**&quot;">​</a></h2><blockquote><p>用歌喉<span class="cor-wa">忽悠</span>到了<strong>媳妇</strong>。</p><p>一次中八台球比赛中<span class="cor-tip">第一场上场</span>对战的就是<strong>最终</strong>的冠军选手(差黑八，被清台) <span class="cor-da">一轮刷下</span>。</p></blockquote><h2 id="只会五首吉他曲的篮球助攻王" tabindex="-1"><span class="cor-wa">只会</span><span class="cor-tip">五首吉他曲</span>的<strong>篮球助攻王</strong> <a class="header-anchor" href="#只会五首吉他曲的篮球助攻王" aria-label="Permalink to &quot;&lt;span class=&quot;cor-wa&quot;&gt;只会&lt;/span&gt;&lt;span class=&quot;cor-tip&quot;&gt;五首吉他曲&lt;/span&gt;的**篮球助攻王**&quot;">​</a></h2><blockquote><p><span class="cor-tip">大学</span>为了<span class="cor-da">ZB</span>，投资<span class="cor-wa">一个月生活费</span>报了吉他班，由于<strong>手指太粗</strong> <code>F</code> <em>和弦</em>按不准，<br> 最终只学会了<span class="cor-tip">五</span> 首歌(<span class="cor-wa">其中</span>还有<strong>一首是儿歌</strong>)。</p><p>一场 85 比 67 的胜利篮球赛，上场 2 节半，没得一分。</p></blockquote><p><em>未完</em> ---- <strong>待续</strong>。。。</p></details>', 2);
const _hoisted_3 = [
  _hoisted_1
];
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, _hoisted_3);
}
const main = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  main as default
};
