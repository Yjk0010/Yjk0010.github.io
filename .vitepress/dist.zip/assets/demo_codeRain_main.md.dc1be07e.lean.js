import { l as lib } from "./chunks/base.36303bf0.js";
import "./chunks/button.fdf0e29d.js";
import { d as defineComponent, u as useData, h as ref, j as onMounted, G as onUnmounted, o as openBlock, c as createElementBlock, L as createVNode, w as withCtx, a as createTextVNode, k as createBaseVNode, _ as _export_sfc, V as createStaticVNode } from "./chunks/framework.2dcfa116.js";
const row = "";
const input = "";
const col = "";
const _hoisted_1$1 = { class: "container" };
const drawTime = 60;
const columnWidth = 20;
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "index",
  setup(__props) {
    const { isDark } = useData();
    const fontColors = [
      "#33B5E5",
      "#0099CC",
      "#AA66CC",
      "#9933CC",
      "#99CC00",
      "#669900",
      "#FFBB33",
      "#FF8800",
      "#FF4444",
      "#CC0000"
    ];
    const getRandomColor = () => {
      return fontColors[Math.floor(Math.random() * fontColors.length)];
    };
    const code = ref(`console.log("hello world")`);
    const showCode = ref(``);
    let columnCount = 0;
    let columnNextIndexes = [];
    let ctx = null;
    let width = 0;
    let height = 0;
    let intervalId = null;
    const getRandomChar = () => {
      return showCode.value[Math.floor(Math.random() * showCode.value.length)];
    };
    const handleClick = () => {
      showCode.value = code.value;
      if (intervalId) {
        clearInterval(intervalId);
        ctx == null ? void 0 : ctx.clearRect(0, 0, width, height);
        columnCount = Math.floor(width / columnWidth);
        columnNextIndexes = new Array(columnCount);
        columnNextIndexes.fill(1);
        intervalId = setInterval(draw, drawTime);
      }
    };
    const canvasRef = ref(null);
    onMounted(() => {
      showCode.value = code.value;
      if (canvasRef.value) {
        ctx = canvasRef.value.getContext("2d");
        canvasRef.value.width = 640;
        canvasRef.value.height = 640;
        width = canvasRef.value.clientHeight;
        height = canvasRef.value.height;
        columnCount = Math.floor(width / columnWidth);
        columnNextIndexes = new Array(columnCount);
        columnNextIndexes.fill(1);
      }
      intervalId = setInterval(draw, drawTime);
    });
    const draw = () => {
      if (ctx) {
        ctx.fillStyle = isDark.value ? "rgba(0, 0, 0, 0.1)" : "rgba(255, 255, 255, 0.1)";
        ctx.fillRect(0, 0, width, height);
        const fz = 20;
        ctx.fillStyle = getRandomColor();
        ctx.font = `${fz}px DingTalkJinBuTi`;
        for (let i = 0; i < columnCount; i++) {
          const x = i * columnWidth;
          const y = fz * columnNextIndexes[i];
          ctx.fillText(getRandomChar(), x, y);
          if (y > height && Math.random() > 0.99) {
            columnNextIndexes[i] = 0;
          } else {
            columnNextIndexes[i]++;
          }
        }
      }
    };
    onUnmounted(() => {
      if (intervalId) {
        clearInterval(intervalId);
      }
    });
    return (_ctx, _cache) => {
      const _component_el_col = lib.ElCol;
      const _component_el_input = lib.ElInput;
      const _component_el_button = lib.ElButton;
      const _component_el_row = lib.ElRow;
      return openBlock(), createElementBlock("div", _hoisted_1$1, [
        createVNode(_component_el_row, { style: { "align-items": "center" } }, {
          default: withCtx(() => [
            createVNode(_component_el_col, {
              span: 4,
              style: { "text-align": "right" }
            }, {
              default: withCtx(() => [
                createTextVNode("展示代码")
              ]),
              _: 1
            }),
            createVNode(_component_el_col, { span: 1 }),
            createVNode(_component_el_col, { span: 12 }, {
              default: withCtx(() => [
                createVNode(_component_el_input, {
                  type: "textarea",
                  modelValue: code.value,
                  "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => code.value = $event),
                  rows: 3
                }, null, 8, ["modelValue"])
              ]),
              _: 1
            }),
            createVNode(_component_el_col, { span: 1 }),
            createVNode(_component_el_col, { span: 3 }, {
              default: withCtx(() => [
                createVNode(_component_el_button, { onClick: handleClick }, {
                  default: withCtx(() => [
                    createTextVNode("重新来")
                  ]),
                  _: 1
                })
              ]),
              _: 1
            })
          ]),
          _: 1
        }),
        createBaseVNode("canvas", {
          class: "bg",
          ref_key: "canvasRef",
          ref: canvasRef
        }, null, 512)
      ]);
    };
  }
});
const index_vue_vue_type_style_index_0_scoped_96f0b884_lang = "";
const demo = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-96f0b884"]]);
const _hoisted_1 = /* @__PURE__ */ createBaseVNode("h1", {
  id: "代码雨",
  tabindex: "-1"
}, [
  /* @__PURE__ */ createTextVNode("代码雨 "),
  /* @__PURE__ */ createBaseVNode("a", {
    class: "header-anchor",
    href: "#代码雨",
    "aria-label": 'Permalink to "代码雨"'
  }, "​")
], -1);
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("h2", {
  id: "展示",
  tabindex: "-1"
}, [
  /* @__PURE__ */ createTextVNode("展示 "),
  /* @__PURE__ */ createBaseVNode("a", {
    class: "header-anchor",
    href: "#展示",
    "aria-label": 'Permalink to "展示"'
  }, "​")
], -1);
const _hoisted_3 = /* @__PURE__ */ createStaticVNode("", 3);
const __pageData = JSON.parse('{"title":"代码雨","description":"","frontmatter":{},"headers":[],"relativePath":"demo/codeRain/main.md","filePath":"demo/codeRain/main.md"}');
const __default__ = { name: "demo/codeRain/main.md" };
const _sfc_main = /* @__PURE__ */ Object.assign(__default__, {
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", null, [
        _hoisted_1,
        _hoisted_2,
        createVNode(demo),
        _hoisted_3
      ]);
    };
  }
});
export {
  __pageData,
  _sfc_main as default
};
