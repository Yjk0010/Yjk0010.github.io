import { _ as _export_sfc, H as resolveComponent, c as createElementBlock, k as createBaseVNode, a as createTextVNode, L as createVNode, w as withCtx, V as createStaticVNode, o as openBlock } from "./chunks/framework.2dcfa116.js";
const __pageData = JSON.parse('{"title":"基础知识","description":"","frontmatter":{},"headers":[],"relativePath":"vue/base/main.md","filePath":"vue/base/main.md"}');
const _sfc_main = { name: "vue/base/main.md" };
const _hoisted_1 = /* @__PURE__ */ createStaticVNode("", 5);
const _hoisted_6 = {
  id: "vue22-6-142-7-以后版本主要添加了关于-vue3-的部分写法支撑",
  tabindex: "-1"
};
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("a", {
  class: "header-anchor",
  href: "#vue22-6-142-7-以后版本主要添加了关于-vue3-的部分写法支撑",
  "aria-label": 'Permalink to "vue2<Badge type="tip">2.6.14</Badge><Badge type="info">2.7 以后版本主要添加了关于 vue3 的部分写法支撑</Badge>"'
}, "​", -1);
const _hoisted_8 = /* @__PURE__ */ createStaticVNode("", 6);
const _hoisted_14 = /* @__PURE__ */ createStaticVNode("", 8);
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_Badge = resolveComponent("Badge");
  return openBlock(), createElementBlock("div", null, [
    _hoisted_1,
    createBaseVNode("h3", _hoisted_6, [
      createTextVNode("vue2"),
      createVNode(_component_Badge, { type: "tip" }, {
        default: withCtx(() => [
          createTextVNode("2.6.14")
        ]),
        _: 1
      }),
      createVNode(_component_Badge, { type: "info" }, {
        default: withCtx(() => [
          createTextVNode("2.7 以后版本主要添加了关于 vue3 的部分写法支撑")
        ]),
        _: 1
      }),
      createTextVNode(),
      _hoisted_7
    ]),
    _hoisted_8,
    createBaseVNode("p", null, [
      createTextVNode("Vue3"),
      createVNode(_component_Badge, { type: "tip" }, {
        default: withCtx(() => [
          createTextVNode("3.3.4")
        ]),
        _: 1
      })
    ]),
    _hoisted_14
  ]);
}
const main = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  main as default
};
