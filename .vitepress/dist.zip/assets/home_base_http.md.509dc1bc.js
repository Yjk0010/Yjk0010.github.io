import { _ as _export_sfc, c as createElementBlock, o as openBlock, k as createBaseVNode, a as createTextVNode } from "./chunks/framework.2dcfa116.js";
const __pageData = JSON.parse('{"title":"HTTP","description":"","frontmatter":{},"headers":[],"relativePath":"home/base/http.md","filePath":"home/base/http.md"}');
const _sfc_main = { name: "home/base/http.md" };
const _hoisted_1 = /* @__PURE__ */ createBaseVNode("h1", {
  id: "http",
  tabindex: "-1"
}, [
  /* @__PURE__ */ createTextVNode("HTTP "),
  /* @__PURE__ */ createBaseVNode("a", {
    class: "header-anchor",
    href: "#http",
    "aria-label": 'Permalink to "HTTP"'
  }, "​")
], -1);
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("blockquote", null, [
  /* @__PURE__ */ createBaseVNode("p", null, "HTTP 英语全称 Hyper Text Transfer Protocol"),
  /* @__PURE__ */ createBaseVNode("p", null, '翻译成中⽂叫做 "超⽂本传输协议"')
], -1);
const _hoisted_3 = /* @__PURE__ */ createBaseVNode("h2", {
  id: "标记网络中的资源",
  tabindex: "-1"
}, [
  /* @__PURE__ */ createTextVNode("标记⽹络中的资源 "),
  /* @__PURE__ */ createBaseVNode("a", {
    class: "header-anchor",
    href: "#标记网络中的资源",
    "aria-label": 'Permalink to "标记⽹络中的资源"'
  }, "​")
], -1);
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("blockquote", null, [
  /* @__PURE__ */ createBaseVNode("p", null, "我们知道，通过 HTTP 协议，我们可以获取到⽹络中的各种资源。那么这些资源是如何进⾏标记的呢？ 这⾥我要为各位介绍 3 个名词，分别是 URI、URN 和 URL。")
], -1);
const _hoisted_5 = [
  _hoisted_1,
  _hoisted_2,
  _hoisted_3,
  _hoisted_4
];
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, _hoisted_5);
}
const http = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  http as default
};
