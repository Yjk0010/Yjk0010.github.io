import { _ as _export_sfc, c as createElementBlock, o as openBlock, V as createStaticVNode } from "./chunks/framework.2dcfa116.js";
const __pageData = JSON.parse('{"title":"其他元素","description":"","frontmatter":{},"headers":[],"relativePath":"html/element/eleOther.md","filePath":"html/element/eleOther.md"}');
const _sfc_main = { name: "html/element/eleOther.md" };
const _hoisted_1 = /* @__PURE__ */ createStaticVNode("", 39);
const _hoisted_40 = [
  _hoisted_1
];
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, _hoisted_40);
}
const eleOther = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  eleOther as default
};
