import { _ as _export_sfc, H as resolveComponent, c as createElementBlock, L as createVNode, V as createStaticVNode, k as createBaseVNode, a as createTextVNode, o as openBlock } from "./chunks/framework.2dcfa116.js";
const __pageData = JSON.parse('{"title":"盒模型","description":"","frontmatter":{},"headers":[],"relativePath":"css/terminology/boxModel.md","filePath":"css/terminology/boxModel.md"}');
const _sfc_main = { name: "css/terminology/boxModel.md" };
const _hoisted_1 = /* @__PURE__ */ createStaticVNode("", 9);
const _hoisted_10 = /* @__PURE__ */ createStaticVNode("", 6);
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("这边盒子的大小就是当前 "),
  /* @__PURE__ */ createBaseVNode("code", null, "content"),
  /* @__PURE__ */ createTextVNode(" 的大小")
], -1);
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("这边盒子的大小就是当前 "),
  /* @__PURE__ */ createBaseVNode("code", null, "content"),
  /* @__PURE__ */ createTextVNode(" + "),
  /* @__PURE__ */ createBaseVNode("code", null, "padding"),
  /* @__PURE__ */ createTextVNode(" + "),
  /* @__PURE__ */ createBaseVNode("code", null, "border"),
  /* @__PURE__ */ createTextVNode(" 的大小")
], -1);
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_PicViewer = resolveComponent("PicViewer");
  return openBlock(), createElementBlock("div", null, [
    _hoisted_1,
    createVNode(_component_PicViewer, {
      title: "盒模型",
      src: "/assets/css/box-0.jpg",
      alt: ""
    }),
    _hoisted_10,
    createVNode(_component_PicViewer, {
      title: "content-box 盒模型",
      src: "/assets/css/box-1.jpg",
      alt: ""
    }),
    _hoisted_16,
    createVNode(_component_PicViewer, {
      title: "border-box 盒模型",
      src: "/assets/css/box-2.jpg",
      alt: ""
    }),
    _hoisted_17
  ]);
}
const boxModel = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  boxModel as default
};
