import { _ as _export_sfc, c as createElementBlock, o as openBlock, V as createStaticVNode } from "./chunks/framework.2dcfa116.js";
const __pageData = JSON.parse('{"title":"优化","description":"","frontmatter":{},"headers":[],"relativePath":"css/base/optimize.md","filePath":"css/base/optimize.md"}');
const _sfc_main = { name: "css/base/optimize.md" };
const _hoisted_1 = /* @__PURE__ */ createStaticVNode("", 9);
const _hoisted_10 = [
  _hoisted_1
];
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, _hoisted_10);
}
const optimize = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  optimize as default
};
