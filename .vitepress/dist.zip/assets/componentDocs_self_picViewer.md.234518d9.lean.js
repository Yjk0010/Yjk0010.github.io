import { P as PicViewer } from "./chunks/PicViewer.ba60aeee.js";
import { d as defineComponent, o as openBlock, b as createBlock, l as unref, Z as __vitePreload, H as resolveComponent, c as createElementBlock, L as createVNode, V as createStaticVNode } from "./chunks/framework.2dcfa116.js";
import "./chunks/Line.05ecb785.js";
const _sfc_main$7 = /* @__PURE__ */ defineComponent({
  __name: "test1",
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createBlock(PicViewer, {
        title: "静态资源路径",
        src: "/assets/components/scenery-2.jpg",
        alt: "根地址路径"
      });
    };
  }
});
const _sfc_main$6 = /* @__PURE__ */ defineComponent({
  __name: "test2",
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createBlock(PicViewer, {
        title: "最简单的相对路径",
        src: "./assets/scenery-1.jpg"
      });
    };
  }
});
const _sfc_main$5 = /* @__PURE__ */ defineComponent({
  __name: "test3",
  setup(__props) {
    const imageUrl = new URL("/assets/scenery-1.01c7889c.jpg", self.location).href;
    return (_ctx, _cache) => {
      return openBlock(), createBlock(PicViewer, {
        title: "new URL(静态) 引入",
        src: unref(imageUrl)
      }, null, 8, ["src"]);
    };
  }
});
const _sfc_main$4 = /* @__PURE__ */ defineComponent({
  __name: "test4",
  setup(__props) {
    const newURLAll = /* @__PURE__ */ Object.assign({ "./assets/scenery-2.jpg": () => __vitePreload(() => import("./chunks/scenery-2.f7ceb2d8.js"), true ? [] : void 0) });
    const imageMap = /* @__PURE__ */ new Map();
    for (const path in newURLAll) {
      imageMap.set(path, new URL(`${path}`, import.meta.url).href);
    }
    return (_ctx, _cache) => {
      return openBlock(), createBlock(PicViewer, {
        title: "new URL(动态) 引入",
        src: unref(imageMap).get(`./assets/scenery-2.jpg`)
      }, null, 8, ["src"]);
    };
  }
});
const __vite_glob_0_0$1 = "/assets/logo.5d4bd31c.png";
const __vite_glob_0_1 = "/assets/scenery-1.01c7889c.jpg";
const __vite_glob_0_2 = "/assets/scenery-2.82390c47.jpg";
const __vite_glob_0_3 = "/assets/scenery-3.10c48381.jpg";
const __vite_glob_0_4 = "/assets/scenery-4.09613e69.jpg";
const __vite_glob_0_5 = "/assets/scenery-5.3a029080.jpg";
const _sfc_main$3 = /* @__PURE__ */ defineComponent({
  __name: "test5",
  setup(__props) {
    const imageUrl = (url) => {
      const obj = new URL((/* @__PURE__ */ Object.assign({ "./assets/logo.png": __vite_glob_0_0$1, "./assets/scenery-1.jpg": __vite_glob_0_1, "./assets/scenery-2.jpg": __vite_glob_0_2, "./assets/scenery-3.jpg": __vite_glob_0_3, "./assets/scenery-4.jpg": __vite_glob_0_4, "./assets/scenery-5.jpg": __vite_glob_0_5 }))[`./assets/${url}`], self.location);
      return obj.pathname;
    };
    return (_ctx, _cache) => {
      return openBlock(), createBlock(PicViewer, {
        title: "imgUrl方法",
        src: imageUrl("scenery-3.jpg")
      }, null, 8, ["src"]);
    };
  }
});
const image = "/assets/scenery-4.09613e69.jpg";
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "test6",
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createBlock(PicViewer, {
        title: "import引入",
        src: unref(image)
      }, null, 8, ["src"]);
    };
  }
});
const __vite_glob_0_0 = "/assets/scenery-5.3a029080.jpg";
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "test7",
  setup(__props) {
    const importMetaGlob = /* @__PURE__ */ Object.assign({
      "./assets/scenery-5.jpg": __vite_glob_0_0
    });
    return (_ctx, _cache) => {
      return openBlock(), createBlock(PicViewer, {
        title: "import.meta.glob 引入",
        src: unref(importMetaGlob)[`./assets/scenery-5.jpg`]
      }, null, 8, ["src"]);
    };
  }
});
const _hoisted_1 = /* @__PURE__ */ createStaticVNode("", 3);
const _hoisted_4 = /* @__PURE__ */ createStaticVNode("", 6);
const _hoisted_10 = /* @__PURE__ */ createStaticVNode("", 6);
const _hoisted_16 = /* @__PURE__ */ createStaticVNode("", 5);
const _hoisted_21 = /* @__PURE__ */ createStaticVNode("", 7);
const _hoisted_28 = /* @__PURE__ */ createStaticVNode("", 7);
const _hoisted_35 = /* @__PURE__ */ createStaticVNode("", 7);
const _hoisted_42 = /* @__PURE__ */ createStaticVNode("", 5);
const _hoisted_47 = /* @__PURE__ */ createStaticVNode("", 7);
const _hoisted_54 = /* @__PURE__ */ createStaticVNode("", 3);
const __pageData = JSON.parse('{"title":"图片组件","description":"","frontmatter":{},"headers":[],"relativePath":"componentDocs/self/picViewer.md","filePath":"componentDocs/self/picViewer.md"}');
const __default__ = { name: "componentDocs/self/picViewer.md" };
const _sfc_main = /* @__PURE__ */ Object.assign(__default__, {
  setup(__props) {
    return (_ctx, _cache) => {
      const _component_PicViewer = resolveComponent("PicViewer", true);
      return openBlock(), createElementBlock("div", null, [
        _hoisted_1,
        createVNode(_component_PicViewer, {
          title: "图片组件展示",
          src: "/assets/components/scenery-1.jpg"
        }),
        _hoisted_4,
        createVNode(_component_PicViewer, {
          title: "文件位置图",
          src: "/assets/components/fileImg-1.jpg",
          alt: "该位置位于public/assets文件目录下，该文件的资源将不会被增加文件指纹"
        }),
        createVNode(_component_PicViewer, {
          title: "文件位置图",
          src: "/assets/components/fileImg-2.jpg",
          alt: "该位置位于当前文件目录下，该文件的资源将会增加文件指纹"
        }),
        _hoisted_10,
        createVNode(_sfc_main$7),
        _hoisted_16,
        createVNode(_sfc_main$6),
        _hoisted_21,
        createVNode(_sfc_main$5),
        _hoisted_28,
        createVNode(_sfc_main$4),
        _hoisted_35,
        createVNode(_sfc_main$3),
        _hoisted_42,
        createVNode(_sfc_main$2),
        _hoisted_47,
        createVNode(_sfc_main$1),
        _hoisted_54
      ]);
    };
  }
});
export {
  __pageData,
  _sfc_main as default
};
