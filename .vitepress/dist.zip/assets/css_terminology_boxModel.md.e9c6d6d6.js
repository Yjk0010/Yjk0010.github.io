import { _ as _export_sfc, H as resolveComponent, c as createElementBlock, L as createVNode, V as createStaticVNode, k as createBaseVNode, a as createTextVNode, o as openBlock } from "./chunks/framework.2dcfa116.js";
const __pageData = JSON.parse('{"title":"盒模型","description":"","frontmatter":{},"headers":[],"relativePath":"css/terminology/boxModel.md","filePath":"css/terminology/boxModel.md"}');
const _sfc_main = { name: "css/terminology/boxModel.md" };
const _hoisted_1 = /* @__PURE__ */ createStaticVNode('<h1 id="盒模型" tabindex="-1">盒模型 <a class="header-anchor" href="#盒模型" aria-label="Permalink to &quot;盒模型&quot;">​</a></h1><blockquote><p>box：盒子, 每个元素在页面中都会生成一个矩形区域（盒子）</p></blockquote><h2 id="盒子类型" tabindex="-1">盒子类型 <a class="header-anchor" href="#盒子类型" aria-label="Permalink to &quot;盒子类型&quot;">​</a></h2><ol><li>行盒: <code>display</code> 等于 <code>inline</code> 的元素</li><li>块盒: <code>display</code> 等于 <code>block</code> 的元素</li></ol><p>行盒在页面中不换行、块盒独占一行</p><p>display 默认值为 inline</p><p>浏览器默认样式表设置的块盒：容器元素、h1~h6、p</p><p>常见的行盒：span、a、img、video、audio</p><h2 id="盒子的组成部分" tabindex="-1">盒子的组成部分 <a class="header-anchor" href="#盒子的组成部分" aria-label="Permalink to &quot;盒子的组成部分&quot;">​</a></h2>', 9);
const _hoisted_10 = /* @__PURE__ */ createStaticVNode('<blockquote><p>无论是行盒、还是块盒, 都由下面几个部分组成, 从内到外分别是：</p></blockquote><ul><li>内容 content</li><li>填充(内边距) padding</li><li>边框 border</li><li>外边距 margin</li></ul><h2 id="box-sizing-的两种设置" tabindex="-1">box-sizing 的两种设置 <a class="header-anchor" href="#box-sizing-的两种设置" aria-label="Permalink to &quot;box-sizing 的两种设置&quot;">​</a></h2><blockquote><p>现在主流浏览器有两种盒模型</p></blockquote><ol><li><code>content-box</code>(默认)</li><li><code>border-box</code>(MDN 推荐) <a href="https://developer.mozilla.org/zh-CN/docs/Web/CSS/box-sizing" target="_blank" rel="noreferrer">MDN box-sizing</a></li></ol><p>下面是他们的不同</p>', 6);
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("这边盒子的大小就是当前 "),
  /* @__PURE__ */ createBaseVNode("code", null, "content"),
  /* @__PURE__ */ createTextVNode(" 的大小")
], -1);
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("这边盒子的大小就是当前 "),
  /* @__PURE__ */ createBaseVNode("code", null, "content"),
  /* @__PURE__ */ createTextVNode(" + "),
  /* @__PURE__ */ createBaseVNode("code", null, "padding"),
  /* @__PURE__ */ createTextVNode(" + "),
  /* @__PURE__ */ createBaseVNode("code", null, "border"),
  /* @__PURE__ */ createTextVNode(" 的大小")
], -1);
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_PicViewer = resolveComponent("PicViewer");
  return openBlock(), createElementBlock("div", null, [
    _hoisted_1,
    createVNode(_component_PicViewer, {
      title: "盒模型",
      src: "/assets/css/box-0.jpg",
      alt: ""
    }),
    _hoisted_10,
    createVNode(_component_PicViewer, {
      title: "content-box 盒模型",
      src: "/assets/css/box-1.jpg",
      alt: ""
    }),
    _hoisted_16,
    createVNode(_component_PicViewer, {
      title: "border-box 盒模型",
      src: "/assets/css/box-2.jpg",
      alt: ""
    }),
    _hoisted_17
  ]);
}
const boxModel = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  boxModel as default
};
