import { _ as _export_sfc, H as resolveComponent, c as createElementBlock, k as createBaseVNode, a as createTextVNode, L as createVNode, w as withCtx, V as createStaticVNode, o as openBlock } from "./chunks/framework.2dcfa116.js";
const __pageData = JSON.parse('{"title":"浏览器大战","description":"","frontmatter":{},"headers":[],"relativePath":"browser/browserWars.md","filePath":"browser/browserWars.md"}');
const _sfc_main = { name: "browser/browserWars.md" };
const _hoisted_1 = /* @__PURE__ */ createBaseVNode("h1", {
  id: "浏览器大战",
  tabindex: "-1"
}, [
  /* @__PURE__ */ createTextVNode("浏览器大战 "),
  /* @__PURE__ */ createBaseVNode("a", {
    class: "header-anchor",
    href: "#浏览器大战",
    "aria-label": 'Permalink to "浏览器大战"'
  }, "​")
], -1);
const _hoisted_2 = {
  id: "www-的诞生-老祖宗",
  tabindex: "-1"
};
const _hoisted_3 = /* @__PURE__ */ createBaseVNode("a", {
  class: "header-anchor",
  href: "#www-的诞生-老祖宗",
  "aria-label": 'Permalink to "WWW 的诞生 <Badge type="tip">老祖宗</Badge>"'
}, "​", -1);
const _hoisted_4 = /* @__PURE__ */ createStaticVNode("", 4);
const _hoisted_8 = {
  id: "第一次浏览器大战-微软-对-网景",
  tabindex: "-1"
};
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("a", {
  class: "header-anchor",
  href: "#第一次浏览器大战-微软-对-网景",
  "aria-label": 'Permalink to "第一次浏览器大战 <Badge type="tip">微软 对 网景</Badge>"'
}, "​", -1);
const _hoisted_10 = /* @__PURE__ */ createStaticVNode("", 37);
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_Badge = resolveComponent("Badge");
  return openBlock(), createElementBlock("div", null, [
    _hoisted_1,
    createBaseVNode("h2", _hoisted_2, [
      createTextVNode("WWW 的诞生 "),
      createVNode(_component_Badge, { type: "tip" }, {
        default: withCtx(() => [
          createTextVNode("老祖宗")
        ]),
        _: 1
      }),
      createTextVNode(),
      _hoisted_3
    ]),
    _hoisted_4,
    createBaseVNode("h2", _hoisted_8, [
      createTextVNode("第一次浏览器大战 "),
      createVNode(_component_Badge, { type: "tip" }, {
        default: withCtx(() => [
          createTextVNode("微软 对 网景")
        ]),
        _: 1
      }),
      createTextVNode(),
      _hoisted_9
    ]),
    _hoisted_10
  ]);
}
const browserWars = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  browserWars as default
};
