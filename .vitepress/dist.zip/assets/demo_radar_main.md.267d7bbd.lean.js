import { l as lib } from "./chunks/base.36303bf0.js";
import "./chunks/button.fdf0e29d.js";
import { d as defineComponent, h as ref, A as watchEffect, G as onUnmounted, o as openBlock, c as createElementBlock, U as normalizeStyle, a5 as reactive, k as createBaseVNode, L as createVNode, w as withCtx, a as createTextVNode, I as Fragment, J as renderList, t as toDisplayString, _ as _export_sfc, V as createStaticVNode } from "./chunks/framework.2dcfa116.js";
const slider = "";
function useConfig(ctx, props) {
  const fontSize = 16;
  const fontFamily = "PingFangSC-Regular, sans-serif";
  ctx.font = `${fontSize}px ${fontFamily}`;
  const vGap = fontSize * 0.5;
  const maxTextWidth = props.scores.reduce((max, [text, score]) => {
    const textWidth = ctx.measureText(text).width;
    const scoreWidth = ctx.measureText(score.toString()).width;
    return Math.max(max, textWidth, scoreWidth);
  }, 0);
  const maxTextHeight = fontSize * 2 + vGap;
  const textSpace = Math.max(maxTextWidth, maxTextHeight);
  const textPadding = 8;
  const radius = ctx.canvas.width / 2 - textSpace - textPadding;
  const lineWidth = 1;
  const lineColor = "#e5e5e5";
  const bgColor = "#10b981";
  return {
    fontSize,
    fontFamily,
    radius,
    textPadding,
    lineWidth,
    lineColor,
    bgColor,
    vGap,
    maxTextHeight
  };
}
function drawHelper(radius, sides, callback) {
  const angle = 2 * Math.PI / sides;
  for (let i = 0; i < sides; i++) {
    const x = radius * Math.sin(angle * i);
    const y = -radius * Math.cos(angle * i);
    callback(x, y, i);
  }
}
function drawPolygon(ctx, props) {
  const config = useConfig(ctx, props);
  const { width, height } = ctx.canvas;
  ctx.translate(width / 2, height / 2);
  ctx.strokeStyle = config.lineColor;
  ctx.lineWidth = config.lineWidth;
  ctx.fillStyle = config.bgColor;
  ctx.font = `${config.fontSize}px ${config.fontFamily}`;
  ctx.textAlign = "center";
  ctx.textBaseline = "top";
  const { scores } = props;
  const sides = scores.length;
  ctx.beginPath();
  drawHelper(config.radius, sides, (x, y, i) => {
    const [_, score] = scores[i];
    const percent = score / props.maxScore;
    x = x * percent;
    y = y * percent;
    ctx.lineTo(x, y);
  });
  ctx.fill();
  ctx.beginPath();
  ctx.moveTo(0, -config.radius);
  drawHelper(config.radius, sides, (x, y) => {
    ctx.lineTo(x, y);
  });
  ctx.closePath();
  ctx.stroke();
  drawHelper(config.radius, sides, (x, y) => {
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(x, y);
    ctx.stroke();
  });
  drawHelper(config.radius + config.textPadding, sides, (x, y, i) => {
    const [text, score] = scores[i];
    const textWidth = ctx.measureText(text).width;
    const scoreWidth = ctx.measureText(score.toString()).width;
    const maxWidth = Math.max(textWidth, scoreWidth);
    const vGap = config.vGap;
    let firstLineX = x, firstLineY = y;
    let secondLineX = x, secondLineY = y;
    const allowError = 0.1;
    if (Math.abs(x) < allowError) {
      firstLineX = x;
    } else if (x > 0) {
      firstLineX = secondLineX = x + maxWidth / 2;
    } else if (x < 0) {
      firstLineX = secondLineX = x - maxWidth / 2;
    }
    secondLineX = firstLineX;
    if (Math.abs(y) < allowError) {
      firstLineY = y - config.fontSize - vGap / 2;
    } else if (y > 0) {
      firstLineY = y;
    } else {
      firstLineY = y - config.fontSize * 2 - vGap;
    }
    secondLineY = firstLineY + config.fontSize + vGap;
    ctx.fillText(text, firstLineX, firstLineY);
    ctx.fillText(score.toString(), secondLineX, secondLineY);
  });
}
function draw(cvs, props) {
  const ctx = cvs.getContext("2d");
  const { width, height } = cvs;
  ctx.save();
  ctx.clearRect(0, 0, width, height);
  drawPolygon(ctx, props);
  ctx.restore();
}
const _hoisted_1$2 = ["width", "height"];
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "PolygonScore",
  props: {
    size: { default: 300 },
    scores: {},
    maxScore: { default: 100 }
  },
  setup(__props) {
    const props = __props;
    const canvasRef = ref(null);
    const stop = watchEffect(() => {
      if (!canvasRef.value) {
        return;
      }
      draw(canvasRef.value, props);
    });
    onUnmounted(stop);
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("canvas", {
        ref_key: "canvasRef",
        ref: canvasRef,
        width: _ctx.size,
        height: _ctx.size,
        style: normalizeStyle({
          width: `${_ctx.size}px`,
          height: `${_ctx.size}px`
        })
      }, null, 12, _hoisted_1$2);
    };
  }
});
const _hoisted_1$1 = { class: "demo" };
const _hoisted_2$1 = { class: "controls" };
const _hoisted_3$1 = { class: "btn-box" };
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "index",
  setup(__props) {
    const size = ref(300);
    const maxScore = ref(100);
    const scores = reactive([]);
    for (let i = 0; i < 5; i++) {
      scores.push([`数据${i + 1}`, Math.floor(Math.random() * maxScore.value)]);
    }
    function add() {
      scores.push([
        `数据${scores.length + 1}`,
        Math.floor(Math.random() * maxScore.value)
      ]);
    }
    function remove() {
      scores.pop();
    }
    return (_ctx, _cache) => {
      const _component_el_button = lib.ElButton;
      const _component_el_slider = lib.ElSlider;
      return openBlock(), createElementBlock("div", _hoisted_1$1, [
        createBaseVNode("div", _hoisted_2$1, [
          createBaseVNode("div", _hoisted_3$1, [
            createVNode(_component_el_button, { onClick: add }, {
              default: withCtx(() => [
                createTextVNode("新增")
              ]),
              _: 1
            }),
            createVNode(_component_el_button, { onClick: remove }, {
              default: withCtx(() => [
                createTextVNode("删除")
              ]),
              _: 1
            })
          ]),
          (openBlock(true), createElementBlock(Fragment, null, renderList(scores, (score) => {
            return openBlock(), createElementBlock("div", {
              class: "item",
              key: score[0]
            }, [
              createBaseVNode("span", null, toDisplayString(score[0]) + "：", 1),
              createVNode(_component_el_slider, {
                class: "slider",
                min: 0,
                max: maxScore.value,
                modelValue: score[1],
                "onUpdate:modelValue": ($event) => score[1] = $event
              }, null, 8, ["max", "modelValue", "onUpdate:modelValue"]),
              createBaseVNode("span", null, toDisplayString(score[1]), 1)
            ]);
          }), 128))
        ]),
        createVNode(_sfc_main$2, {
          size: size.value,
          maxScore: maxScore.value,
          scores
        }, null, 8, ["size", "maxScore", "scores"])
      ]);
    };
  }
});
const index_vue_vue_type_style_index_0_scoped_64091fdf_lang = "";
const demo = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-64091fdf"]]);
const _hoisted_1 = /* @__PURE__ */ createBaseVNode("h1", {
  id: "雷达图",
  tabindex: "-1"
}, [
  /* @__PURE__ */ createTextVNode("雷达图 "),
  /* @__PURE__ */ createBaseVNode("a", {
    class: "header-anchor",
    href: "#雷达图",
    "aria-label": 'Permalink to "雷达图"'
  }, "​")
], -1);
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("h2", {
  id: "展示",
  tabindex: "-1"
}, [
  /* @__PURE__ */ createTextVNode("展示 "),
  /* @__PURE__ */ createBaseVNode("a", {
    class: "header-anchor",
    href: "#展示",
    "aria-label": 'Permalink to "展示"'
  }, "​")
], -1);
const _hoisted_3 = /* @__PURE__ */ createStaticVNode("", 5);
const __pageData = JSON.parse('{"title":"雷达图","description":"","frontmatter":{},"headers":[],"relativePath":"demo/radar/main.md","filePath":"demo/radar/main.md"}');
const __default__ = { name: "demo/radar/main.md" };
const _sfc_main = /* @__PURE__ */ Object.assign(__default__, {
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", null, [
        _hoisted_1,
        _hoisted_2,
        createVNode(demo),
        _hoisted_3
      ]);
    };
  }
});
export {
  __pageData,
  _sfc_main as default
};
