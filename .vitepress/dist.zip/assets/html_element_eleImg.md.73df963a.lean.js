import { c as createElementBlock, k as createBaseVNode, I as Fragment, J as renderList, V as createStaticVNode, o as openBlock } from "./chunks/framework.2dcfa116.js";
const _imports_0 = "/assets/no-img.jpg";
const _imports_1 = "/assets/html/solarSystem.jpg";
const _hoisted_1 = /* @__PURE__ */ createStaticVNode("", 16);
const _hoisted_17 = { name: "solarMap" };
const _hoisted_18 = ["shape", "coords", "href", "target", "data-title"];
const _hoisted_19 = /* @__PURE__ */ createStaticVNode("", 1);
const __pageData = JSON.parse('{"title":"img 元素","description":"","frontmatter":{},"headers":[],"relativePath":"html/element/eleImg.md","filePath":"html/element/eleImg.md"}');
const __default__ = { name: "html/element/eleImg.md" };
const _sfc_main = /* @__PURE__ */ Object.assign(__default__, {
  setup(__props) {
    const areaList = [
      {
        shape: "circle",
        coords: "282,660,56",
        href: "https://baike.baidu.com/item/%E6%9C%A8%E6%98%9F/222105",
        target: "_blank",
        title: "木星"
      },
      {
        shape: "circle",
        coords: "282,422,48",
        href: "https://baike.baidu.com/item/%E5%9C%9F%E6%98%9F/136354",
        target: "_blank",
        title: "土星"
      },
      {
        shape: "circle",
        coords: "282,336,22",
        href: "https://baike.baidu.com/item/%E5%A4%A9%E7%8E%8B%E6%98%9F/21805",
        target: "_blank",
        title: "天王星"
      },
      {
        shape: "circle",
        coords: "282,278,22",
        href: "https://baike.baidu.com/item/%E6%B5%B7%E7%8E%8B%E6%98%9F/30351",
        target: "_blank",
        title: "海王星"
      },
      {
        shape: "circle",
        coords: "282,794,10",
        href: "https://baike.baidu.com/item/%E7%81%AB%E6%98%9F/5627",
        target: "_blank",
        title: "火星"
      },
      {
        shape: "circle",
        coords: "282,822,14",
        href: "https://baike.baidu.com/item/%E5%9C%B0%E7%90%83/6431",
        target: "_blank",
        title: "地球"
      },
      {
        shape: "circle",
        coords: "282,850,12",
        href: "https://baike.baidu.com/item/%E9%87%91%E6%98%9F/19410",
        target: "_blank",
        title: "金星"
      },
      {
        shape: "circle",
        coords: "282,878,10",
        href: "https://baike.baidu.com/item/%E6%B0%B4%E6%98%9F/135917",
        target: "_blank",
        title: "水星"
      },
      {
        shape: "rect",
        coords: "128,930,440,1000",
        href: "https://baike.baidu.com/item/%E5%A4%AA%E9%98%B3/24010",
        target: "_blank",
        title: "太阳"
      },
      {
        shape: "poly",
        coords: "135,169,248,146,248,183,140,197",
        href: "https://baike.baidu.com/item/%E6%9F%AF%E4%BC%8A%E4%BC%AF%E5%B8%A6",
        target: "_blank",
        title: "柯伊伯带"
      },
      {
        shape: "poly",
        coords: "127,52,237,36,243,67,131,84",
        href: "https://baike.baidu.com/item/%E5%A5%A5%E5%B0%94%E7%89%B9%E4%BA%91",
        target: "_blank",
        title: "奥尔特云"
      },
      {
        shape: "poly",
        coords: "90,90,102,38,126,82,142,141,110,149",
        href: "https://baike.baidu.com/item/%E9%95%BF%E5%91%A8%E6%9C%9F%E5%BD%97%E6%98%9F",
        target: "_blank",
        title: "长周期彗星"
      }
    ];
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", null, [
        _hoisted_1,
        createBaseVNode("map", _hoisted_17, [
          (openBlock(), createElementBlock(Fragment, null, renderList(areaList, (item) => {
            return createBaseVNode("area", {
              shape: item.shape,
              coords: item.coords,
              href: item.href,
              target: item.target,
              "data-title": item.title
            }, null, 8, _hoisted_18);
          }), 64))
        ]),
        _hoisted_19
      ]);
    };
  }
});
export {
  __pageData,
  _sfc_main as default
};
