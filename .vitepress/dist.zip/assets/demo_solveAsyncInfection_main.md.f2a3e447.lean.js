import { l as lib } from "./chunks/base.36303bf0.js";
import "./chunks/loading.369786e8.js";
import { g as getRandomNum } from "./chunks/index.a789eca0.js";
import { d as defineComponent, h as ref, j as onMounted, H as resolveComponent, o as openBlock, c as createElementBlock, k as createBaseVNode, a7 as withDirectives, L as createVNode, a as createTextVNode, w as withCtx, l as unref, V as createStaticVNode } from "./chunks/framework.2dcfa116.js";
const _hoisted_1$1 = { class: "asyncInfection" };
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "index",
  setup(__props) {
    const imgUrl = ref("/assets/no-img.jpg");
    const loading = ref(false);
    const btnClick = async () => {
      await controlLoading();
    };
    const controlLoading = async () => {
      loading.value = true;
      imgUrl.value = await getImage();
      loading.value = false;
    };
    const getImage = async () => {
      return await fetch(
        `https://picsum.photos/200/200?r=${getRandomNum(0, 100)}`
      ).then(async (res) => URL.createObjectURL(await res.blob()));
    };
    onMounted(() => {
      btnClick();
    });
    return (_ctx, _cache) => {
      const _component_PicViewer = resolveComponent("PicViewer");
      const _directive_loading = lib.ElLoadingDirective;
      return openBlock(), createElementBlock("div", _hoisted_1$1, [
        createBaseVNode("span", {
          class: "cor-tip pointer",
          onClick: btnClick
        }, "点击将会更换图片"),
        withDirectives(createVNode(_component_PicViewer, {
          title: "图片展示",
          src: imgUrl.value
        }, null, 8, ["src"]), [
          [_directive_loading, loading.value]
        ])
      ]);
    };
  }
});
const timeLine = "/assets/timeLine.b3143254.jpg";
const timeLine_dark = "/assets/timeLine_dark.e41071ce.jpg";
const thinking = "/assets/thinking.4d06b57f.jpg";
const thinking_dark = "/assets/thinking_dark.a301ce33.jpg";
const _hoisted_1 = {
  id: "处理异步传染-听说好像是个字节面试题",
  tabindex: "-1"
};
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("a", {
  class: "header-anchor",
  href: "#处理异步传染-听说好像是个字节面试题",
  "aria-label": 'Permalink to "处理异步传染 <Badge type="tip">听说好像是个字节面试题</Badge>"'
}, "​", -1);
const _hoisted_3 = /* @__PURE__ */ createBaseVNode("h2", {
  id: "什么是异步传染",
  tabindex: "-1"
}, [
  /* @__PURE__ */ createTextVNode("什么是异步传染？ "),
  /* @__PURE__ */ createBaseVNode("a", {
    class: "header-anchor",
    href: "#什么是异步传染",
    "aria-label": 'Permalink to "什么是异步传染？"'
  }, "​")
], -1);
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("blockquote", null, [
  /* @__PURE__ */ createBaseVNode("p", null, [
    /* @__PURE__ */ createTextVNode("要消除"),
    /* @__PURE__ */ createBaseVNode("code", null, "异步传染性"),
    /* @__PURE__ */ createTextVNode("首先要了解什么是"),
    /* @__PURE__ */ createBaseVNode("code", null, "异步传染性")
  ])
], -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("p", null, "先展示一个异步代码，实现了点击之后将异步获取图片。", -1);
const _hoisted_6 = /* @__PURE__ */ createStaticVNode("", 12);
const _hoisted_18 = /* @__PURE__ */ createStaticVNode("", 6);
const _hoisted_24 = /* @__PURE__ */ createStaticVNode("", 5);
const __pageData = JSON.parse('{"title":"处理异步传染 听说好像是个字节面试题","description":"","frontmatter":{},"headers":[],"relativePath":"demo/solveAsyncInfection/main.md","filePath":"demo/solveAsyncInfection/main.md"}');
const __default__ = { name: "demo/solveAsyncInfection/main.md" };
const _sfc_main = /* @__PURE__ */ Object.assign(__default__, {
  setup(__props) {
    return (_ctx, _cache) => {
      const _component_Badge = resolveComponent("Badge");
      const _component_PicViewer = resolveComponent("PicViewer");
      return openBlock(), createElementBlock("div", null, [
        createBaseVNode("h1", _hoisted_1, [
          createTextVNode("处理异步传染 "),
          createVNode(_component_Badge, { type: "tip" }, {
            default: withCtx(() => [
              createTextVNode("听说好像是个字节面试题")
            ]),
            _: 1
          }),
          createTextVNode(),
          _hoisted_2
        ]),
        _hoisted_3,
        _hoisted_4,
        _hoisted_5,
        createVNode(_sfc_main$1),
        _hoisted_6,
        createVNode(_component_PicViewer, {
          title: "时间线调用",
          alt: " ",
          src: unref(timeLine),
          darkSrc: unref(timeLine_dark)
        }, null, 8, ["src", "darkSrc"]),
        _hoisted_18,
        createVNode(_component_PicViewer, {
          title: "思路流程",
          alt: " ",
          src: unref(thinking),
          darkSrc: unref(thinking_dark)
        }, null, 8, ["src", "darkSrc"]),
        _hoisted_24
      ]);
    };
  }
});
export {
  __pageData,
  _sfc_main as default
};
