import { _ as _export_sfc, c as createElementBlock, o as openBlock, V as createStaticVNode } from "./chunks/framework.2dcfa116.js";
const __pageData = JSON.parse('{"title":"","description":"","frontmatter":{},"headers":[],"relativePath":"interviewQuestion/main.md","filePath":"interviewQuestion/main.md"}');
const _sfc_main = { name: "interviewQuestion/main.md" };
const _hoisted_1 = /* @__PURE__ */ createStaticVNode('<h2 id="传送门" tabindex="-1">传送门 <a class="header-anchor" href="#传送门" aria-label="Permalink to &quot;传送门&quot;">​</a></h2><h3 id="主流浏览器内核" tabindex="-1"><a href="/browser/main.html#主流浏览器内核">主流浏览器内核</a> <a class="header-anchor" href="#主流浏览器内核" aria-label="Permalink to &quot;[主流浏览器内核](/browser/main#主流浏览器内核)&quot;">​</a></h3><h3 id="浏览器渲染原理" tabindex="-1"><a href="/browser/renderSchematic.html">浏览器渲染原理</a> <a class="header-anchor" href="#浏览器渲染原理" aria-label="Permalink to &quot;[浏览器渲染原理](/browser/renderSchematic)&quot;">​</a></h3>', 3);
const _hoisted_4 = [
  _hoisted_1
];
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, _hoisted_4);
}
const main = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  main as default
};
