import { _ as _export_sfc, H as resolveComponent, c as createElementBlock, L as createVNode, V as createStaticVNode, o as openBlock } from "./chunks/framework.2dcfa116.js";
const __pageData = JSON.parse('{"title":"小知识点","description":"","frontmatter":{},"headers":[],"relativePath":"html/base/littleCase.md","filePath":"html/base/littleCase.md"}');
const _sfc_main = { name: "html/base/littleCase.md" };
const _hoisted_1 = /* @__PURE__ */ createStaticVNode("", 9);
const _hoisted_10 = /* @__PURE__ */ createStaticVNode("", 18);
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_PicViewer = resolveComponent("PicViewer");
  return openBlock(), createElementBlock("div", null, [
    _hoisted_1,
    createVNode(_component_PicViewer, {
      title: "加载过程",
      src: "/assets/html/main-1.jpg",
      alt: ""
    }),
    _hoisted_10
  ]);
}
const littleCase = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  littleCase as default
};
